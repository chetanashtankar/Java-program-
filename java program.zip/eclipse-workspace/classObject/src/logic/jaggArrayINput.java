package logic;
import java.util.Scanner;
public class jaggArrayINput
{
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		
		int a[][]= new int[3][];
		int i,j;
	   System.out.println("enter size of i");
	   for(i=0;i<a.length;i++)
	   {
		   int size= sc.nextInt();
		   a[i]=new int[size];
	   }
	   System.out.println("enter array element");
	   for(i=0;i<a.length;i++)
	   { 
		   
		  for(j=0;j<a[i].length;j++)
		  {
			  a[i][j]=sc.nextInt();
		  }
	   }
		  System.out.println("array element");
		   for(i=0;i<a.length;i++)
		   {
			   for(j=0;j<a[i].length;j++)
			  {
				  System.out.print(a[i][j]);
			  }
			   System.out.println();
		   }
	   }
	   
	   
	

}

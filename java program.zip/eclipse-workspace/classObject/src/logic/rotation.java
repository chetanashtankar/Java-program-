package logic;
/*
 * Given an Array of size N and a values K, around which we need to right rotate the array. How to quickly print the right rotated array?
Examples : 

Input: Array[] = {1, 3, 5, 7, 9}, K = 2.
Output: 7 9 1 3 5
Explanation:
After 1st rotation - {9, 1, 3, 5, 7}
After 2nd rotation - {7, 9, 1, 3, 5}
 */
public class rotation
{
	int i;
	int j;
	int a[]= {1,3,5,7,9};
	int k=2;
	public void disp()
	{
		System.out.println("Original array is ");
		for(i=0;i<a.length;i++)
		{
			System.out.print(" "+a[i]);
		}
		
		for(j=0;j<k;j++)
		{
		
		int temp=a[a.length-1];
		for(i=a.length-1;i>0;i--)
		{
			a[i]=a[i-1];
			
		}
		a[i]=temp;
	}
		System.out.println("\nAfter rotating");
	for(i=0;i<a.length;i++)
	{
	System.out.print(" "+a[i]);	
	}
	}
	public static void main(String[] args) {
		rotation K=new rotation();
		K.disp();
	}
}






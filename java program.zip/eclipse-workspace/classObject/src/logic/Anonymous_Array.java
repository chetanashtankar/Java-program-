package logic;

public class Anonymous_Array 
{
	public void disp(int a[])
	{
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
	}
	public static void main(String[]args)
	{
		Anonymous_Array ob= new Anonymous_Array();
		ob.disp(new int [] {1,2,3,4,5});
	}

}

package logic;

public class indexshow 

  {
	int arr[],size;
   public void input()
   {
	  int  arr[] ={-7, 1, 5, 2, -4, 3, 0};
     int   arr_size = arr.length;
   }
	public int equilibrium_index()
	    {
	        int sum = 0;
	        int leftsum = 0;

	        for (int i = 0; i < arr.length; ++i)
	            sum += arr[i];

	        for (int i = 0; i < arr.length; ++i) {
	            sum -= arr[i];

	            if (leftsum == sum)
	                return i;

	            leftsum += arr[i];
	        }

	        return -1;
	    }

	    public static void main(String[] args)
	    {
	        
	    	indexshow ob= new indexshow();
	    }
	}



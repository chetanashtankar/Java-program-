package logic;

public class pattrn
{
	public static void main(String[]args)
	{
		 int n=5;
		 int i,j;
		 i=1;
		 while(i<=n)
		 
		 {
			  
			 j=5;
			 while(j>i)
		      
		      {
		    	  System.out.print(" ");
		    	  
		    	  j--;
		    	 
		      }
			 
			 
			 int k=1;
			 while(k<=i)
			 {
				 System.out.print(k+" ");
				 
		    	  
		    	  k++;
		    	 
			 }
			 System.out.println();
			 i++;
		      
		     
		 }
	
		 int i1=1;
		 while(i1<=n)
			 
		 {
			  
			 int j1=1;
			 while(j1<=i1)
		      
		      {
		    	  System.out.print(" ");
		    	  
		    	  j1++;
		    	 
		      }
			 
			 
			 int k1=1;
			 while(k1<=n-i1)
			 {
				 System.out.print(k1+" ");
				 
		    	  
		    	  k1++;
		    	 
			 }
			 System.out.println();
			 i1++;
		 }

}
}

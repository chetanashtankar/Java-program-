package logic;

import java.util.Comparator;

public class employe2 implements Comparator<employe>
{

	@Override
	public int compare(employe o1, employe o2) 
	{
		
		return o1.getId()-o2.getId();
	}

	
}

class emp2 implements Comparator<employe>
{

	@Override
	public int compare(employe o1, employe o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getSalary()-o2.getSalary());
	}
	
}

class emp3 implements Comparator<employe>
{

	@Override
	public int compare(employe o1, employe o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareToIgnoreCase(o2.getName());
	}
	
}

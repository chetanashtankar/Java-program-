package logic;
/* 
 * 12.Given an array and a value, find if there is a triplet in array whose sum is equal to the given value.
   If there is such a triplet present in array, then print the triplet and return true. Else return false.
   Examples: 
   Input: array = {12, 3, 4, 1, 6, 9}, sum = 24; 
   Output: 12, 3, 9
 * */
import java.util.Scanner;
 
public class TripletArray 
{

	  Scanner sc=new Scanner(System.in);
	  
	  public boolean  trplet(int a[])
	  {
		   for(int i=0;i<a.length;i++)
		  {
			  System.out.println(a[i]);
		  }
		   System.out.println("enter sum ");
		   int sum=sc.nextInt();
			
		  System.out.println("triplet element");
			int c=0;
		  for(int i=0;i<a.length;i++)
		  {
			  for(int j=i+1;j<a.length;j++)
			  {
				  for(int k=j+2;k<a.length;k++)
				  {
					  if(a[i]+a[j]+a[k]==sum)
					  {
						 System.out.println(a[i]+ " + "+ a[j] + " +" +a[k]+" = "+sum);
						 c++;
					  }
				  }
			  }
		  }
		  System.out.println("triplet present");
		  if(c>0)
		  {
		return true;
		  }
		  
		  else {
			  return false;
		  }
	  }
	  
	      
	     
	  public static void main(String[]args)
	  {
		  int a[]= {12, 3, 4, 1, 6, 9};
			
		  TripletArray ob = new TripletArray();
		 System.out.println( ob.trplet(a));;
	  }
}

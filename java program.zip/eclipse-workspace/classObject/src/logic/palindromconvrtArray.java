package logic;
 
import java.util.Arrays;
import java.util.Scanner;
/*
 * Check the given number is pallindrom or not if yes then
 *  convert into array and sort that array and if number is
 *   not pallindrom then convert into array and swap first
 *    element with last element

input 
121
output

1 1 2

input
6548

output

8 5 4 6
 */
public class palindromconvrtArray {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		int rem,rev=0;
		int i,c=0;
		int n1=n;
		int a[];
		while(n1!=0)
		{    c++;
			rem=n1%10;
			rev=(rev*10)+rem;
			n1=n1/10;
		}
		if(rev==n)
		{
			System.out.println("number is palindrome");
			 a=new int[c];
			int j=0;
			while(rev!=0)
			{
				rem=rev%10;
				
				a[j]=rem;
				j++;
				rev=rev/10;
			
			}
			System.out.println("palindrome convert in array");
			
			for(int k=0;k<a.length;k++)
			{
				System.out.println(a[k]);
			}
			Arrays.sort(a);
			
			System.out.println("swap two number");
			for(int k=0;k<a.length;k++)
			{
				System.out.println(a[k]);
			}
			 
			
			}
		
		else if(rev!=0) {
			System.out.println("number is not palindrome");
		 a=new int[c];
		int j=0;
		while(rev!=0)
		{
			rem=rev%10;
			a[j]=rem;
			j++;
             rev=rev/10;
		}
		System.out.println("convert into array");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
			
		}
		}
		
	}



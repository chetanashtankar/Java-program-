package logic;

/*
 * 8.Given an array air[] of n integers, 
find the maximum that maximizes the sum 
of the value of i*air[i] where i varies from 0 to n-1.
  Examples:  
  Input: air[] = {8, 3, 1, 2}
  Output: 29
  Explanation: Lets look at all the rotations,
 {8, 3, 1, 2} = 8*0 + 3*1 + 1*2 + 2*3 = 11
 {3, 1, 2, 8} = 3*0 + 1*1 + 2*2 + 8*3 = 29
 {1, 2, 8, 3} = 1*0 + 2*1 + 8*2 + 3*3 = 27
 {2, 8, 3, 1} = 2*0 + 8*1 + 3*2 + 1*3 = 17
 */
 
public class maximizeSum 
{
 	public static void main(String[] args)
	{
		int a[]= {8, 3, 1, 2};
		int i,temp,j,mul,sum=0,max=0;
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("Multiplying element by there index");
		temp=a[0];
		for(i=1;i<=4;i++)
		{
		  for(i=0;i<a.length-1;i++)
		  {
			a[i]=a[i+1];
		  }
		   a[a.length-1]=temp;
		    for(i=0;i<a.length;i++)
		     {
			  mul=a[i]*i;
			  sum=sum+mul;
			   if(sum>max)
			   {
			   	max=sum;
			   }
		   }
		}
	
		System.out.println("Multiplication and sum="+max);
	}
	
	

}

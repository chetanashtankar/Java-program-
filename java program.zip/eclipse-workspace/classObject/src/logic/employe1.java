package logic;
import java.util.ArrayList;
import java.util.Collections;
public class employe1 {

	public static void main(String[] args) 
	{
		ArrayList<employe>l=new ArrayList<employe>();
		l.add(new employe(1, "chetan", 120000));
		l.add(new employe(3, "vishal", 170000));
		l.add(new employe(2, "archana", 160000));
		
		
		Collections.sort(l,new employe2());
		System.out.println("sort by id");
		System.out.println(l);
		System.out.println();
		Collections.sort(l,new emp2());
		System.out.println("sort by salary");
		System.out.println(l);
		System.out.println();
		System.out.println("sort by name");
		Collections.sort(l,new emp3());
		System.out.println(l);
		
		System.out.println();
		
		
	}

}

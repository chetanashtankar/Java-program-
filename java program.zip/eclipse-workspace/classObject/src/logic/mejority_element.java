package logic;
/*
 * Find the majority element in the array. A majority element in an array A[] of size n is an element that appears more than n/2 times (and hence there is at most one such element). 

Examples : 

Input : A[]={3, 3, 4, 2, 4, 4, 2, 4, 4}
Output : 4
Explanation: The frequency of 4 is 5 which is greater than the half of the size of the array size. 

Input : A[] = {3, 3, 4, 2, 4, 4, 2, 4}
 */
public class mejority_element 
{
	public void majority()
	{
		int a[]={3, 3, 4, 2, 4, 4, 2, 4, 4};
		int n=a.length;
		int count=0;
		int maxcount=0;
		int index=-1;
		for(int i=0;i<n;i++)
		{
		System.out.println(a[i]);
		}
		for(int i=0;i<n;i++)
		{
		 for(int j=i+1;j<n;j++)
		 {
			 if(a[i]==a[j])
				 count++;
		 }
		 if(count > maxcount)
			{
				maxcount=count;
				index=i;
			}
		}
		   System.out.println("majority element :-");
		if(maxcount > n/2)
		{
			System.out.println(a[index]);
			
		}
	}
	public static void main(String[]args)
	{
		mejority_element ob= new mejority_element();
		ob.majority();
		
	}

}

package logic;
/*
 * Write a Java program to take input number from the user, reverse it and add
 it to itself.
  If the sum is not a palindrome 
 * then repeat the procedure until you get a palindrome.
 */
import java.util.Scanner;

public class palindrome123 

{

	public void pal(int n)
	{
		  int temp,rev,rem;
		  boolean ispalindrome=false;
		  while(!ispalindrome)
		  {
			  rev=0;
			  temp=n;
			  while(temp!=0)
			  {
				  rem=temp%10;
				  rev=rev*10+rem;
				  temp=temp/10;
			  }
			  if(n==rev)
			  {
				  ispalindrome=true;
				
			  }
			  else
			  {
				n=n+rev;
				
			  }
		  }
		  System.out.println(n);
		  
		}

 
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter the number");
		int n= sc.nextInt();
		palindrome123 ob= new palindrome123();
		ob.pal(n);
		
	}
}

package logic;
import java.util.Scanner;
public class originalArrayGreater {
	
	Scanner sc=new Scanner(System.in);
	
	
	int i;
	public int[] findOdd(int a[])
	{
		System.out.println("Enter a number x ");
		int x=sc.nextInt();
		int c=0;
		for(i=0;i<a.length;i++)
		{
			if(a[i]!=0)
			{
				c++;
			}
		}
		int odd[]=new int[c];
		  int p=0;
		  System.out.println("element grater than value");
			for(i=0;i<a.length;i++)
			{
				
				if(a[i]>x)
				{                                 
					odd[p]=a[i];
                   
					p++;
				}
				
				
			}
		
		return odd;
		
	}
	
	public static void main(String[] args)
	{
		int a[]= {1,2,3,4,5,7,9,10};
		int i;
		
		originalArrayGreater obj=new originalArrayGreater();
		int k[]=obj.findOdd(a);
		
		for(int m:k)
		{
				System.out.println(m);
		}
		
	}

}




package logic;

public class Array_return {
	//Write a program that takes in an array of integers and returns a new array with all the odd numbers from the original array.

 
		int i;
		public int[] findOdd(int a[])
		{
			int c=0;
			for(i=0;i<a.length;i++)
			{
				if(a[i]%2!=0)
				{
					c++;
				}
			}
			
			System.out.println("odd elements in an array is :-");
			int odd[]=new int[c];
			  int p=0;
				for(i=0;i<a.length;i++)
				{
					if(a[i]%2!=0)
					{
						odd[p]=a[i];
						p++;
					}
					
				}
			
			return odd;
			
		}
		
		public static void main(String[] args)
		{
			int a[]= {1,2,3,4,5,6,7,8,9,11};
			int i;
			Array_return obj=new Array_return();
			int k[]=obj.findOdd(a);
			
			for(int m:k)
			{
					System.out.println(m);
			}
			
		}

	}



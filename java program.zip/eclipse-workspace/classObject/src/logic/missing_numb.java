package logic;
import java.util.Scanner;
/*
 * Given an unsorted array of size n. Array elements are in the range of 1 to n. One number from set {1, 2, …n} is missing and one number occurs twice in the array. Find these two numbers.

Examples: 

Input: arr[] = {3, 1, 3}
Output: Missing = 2, Repeating = 3
Explanation: In the array, 2 is missing and 3 occurs twice 

Input: arr[] = {4, 3, 6, 2, 1, 1}
Output: Missing = 5, Repeating = 1




 */
public class missing_numb {
	
	
	int i,j;
	Scanner sc= new Scanner(System.in);
	public void input(int size,int a[])
	{
		System.out.println("enter array element");
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		
		
	 
		int temp=1;
		for(i=2;i<a.length+1;i++)
		{
		 temp=temp+i;
		 temp=temp-a[i-2];
		}
		
		
		
		System.out.println("missing number");
		for(i=0;i<a.length;i++)
		{
			 System.out.println(temp);
			 break;
		}
		System.out.println("repeating number");
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					System.out.println(a[i]);
				}
			}
			
		}
		
		
	}
	
	
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		missing_numb ob= new missing_numb();
		ob.input(size, a);
		
	}

}

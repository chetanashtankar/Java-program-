package logic;

public class employe 
{

	public employe(int id, String name, double salary) 
	{
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	private int id;
	private String name;
	private double salary;
	public int getId() 
	{
		return id;
	}
	public String getName() 
	{
		return name;
	}
	public double getSalary() 
	{
		return salary;
	}
	@Override
	public String toString() 
	{
		return "\nemploye [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
}

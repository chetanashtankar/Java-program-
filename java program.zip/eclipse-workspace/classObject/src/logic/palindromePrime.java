package logic;
/*
 * Q1.
check given number is palindrom prime number
eg . 313  = true

252 = false
 */
import java.util.Scanner;
public class palindromePrime {

	public static void main(String[] args)
	{
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n= sc.nextInt();
		
		int temp=n;
		int rem,rev=0;
		boolean c=true;
		while(temp!=0)
		{
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
			
		}
		
		if(rev==n)
		{
			
			System.out.println("number is palindrome");
			int j=2;
			int c1=0;
			while(j<n) {
			if(n%j==0)
			{
				c1++;
				
			}
			j++;
			}
			
			if(c1==0)
			{
				c= true;
				System.out.println(c);
			}
			else {
				
				c=false;
			
				System.out.println(c);
			}
		}
		
		else {
			
			c=false;
			System.out.println(c);
			
		}
		 
	}

	
	
}

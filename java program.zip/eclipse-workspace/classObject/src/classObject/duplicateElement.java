package classObject;

public class duplicateElement
{

	public void duplicateremov()
	
	{
		int a[]= {1,2,1,4,2,6,5,3,4,8};
	   int i,j;
	   System.out.println("Array Element is :-");
	   
	   for(i=0;i<a.length;i++)
	   {
		   System.out.print(a[i]+" ");
	   }
	   for(i=0;i<a.length;i++)
	   {
		   for(j=i+1;j<a.length;j++)
		   {
			   if(a[i]==a[j])
			   {
				   a[i]=0;
			   }
			   
		   }
	   }
	   System.out.println();
	   System.out.println("After removing duplicate element");
		
	   for(i=0;i<a.length;i++)
	   {
		  if(a[i]==0)
		  {
			  
			  continue;
			  
		  }
		  System.out.print(a[i]+" ");
	   }
  
	}
	public static void main(String[]args)
	{
		duplicateElement obj=new duplicateElement();
		obj.duplicateremov();
	}
}

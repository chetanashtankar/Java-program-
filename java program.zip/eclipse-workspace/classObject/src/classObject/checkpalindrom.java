package classObject;
import java.util.Scanner;
public class checkpalindrom 
{

	Scanner sc=new Scanner(System.in);
	
	public void palindrm()
	{
		System.out.println("enter number");
		
		int n=sc.nextInt();
		int rem,rev=0,f;
		f=n;
		
		while(f!=0)
		{
			rem=f%10;
			rev=rev*10+rem;
			f=f/10;
			
			
		}
		if(rev==n)
		{
			System.out.println("number is palindrom");
			
			
		}
		
		else
		{
		
		System.out.println("number is palindrom");
		
		
		}
		}
		
		public static void main(String[]args)
		{
			checkpalindrom obj = new checkpalindrom();
			obj.palindrm();
			
			
	  }
	}

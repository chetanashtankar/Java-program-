package classObject;

public class replacenegeative
{
	
	
		public void  replace()
		{
		int a[]={12,3,-19,29,5,-61,44,7,-9};
		
		int i;
		System.out.println(" ORIGINAL ARRAY ELEMENTS :-   ");
		for(i=0;i<a.length;i++)
		{
			System.out.print(a[i] +  " " );
		}
		System.out.println();
		System.out.println(" Replace all negative value with its previous elements square :- ");
		for(i=0;i<a.length;i++)
		{
			if(a[i]<0)
			{
				a[i]=a[i-1] * a[i-1];
			}
		}
		   for(i=0;i<a.length;i++)
		    {
		System.out.print(a[i]+  "  ");
			}
			System.out.println();
	}
		public static void main(String[] args)
		{
			replacenegeative r = new replacenegeative();
			r.replace();
		}
	}



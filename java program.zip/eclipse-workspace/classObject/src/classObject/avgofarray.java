package classObject;

public class avgofarray 
{
	public void avg()
	{
	int a[] ={4,5,6,8,9,8,1,2,3,4};
	int sum=0;
	int avg=0;
	int i;
	for(i=0;i<a.length;i++)
	{
		
		System.out.print(a[i]+" ");
		sum=sum+a[i];
		avg=sum/10;
	}
	System.out.println();
	System.out.println("sum of array:-"+sum);
	System.out.println("Avg  of array:-"+avg);
	
	
	
	
	}
	
	public static void main(String[]args)
	{
		avgofarray obj=new avgofarray();
		obj.avg();
	}

}

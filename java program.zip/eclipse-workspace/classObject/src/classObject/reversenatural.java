package classObject;

import java.util.Scanner;

public class reversenatural
{
	Scanner sc=new Scanner(System.in);	
	  
	public void natural()
	{
	int n = 1;
    int i = 20;
    while (i >= n)
    {
      System.out.print(n + " ");
      n++;
    }
  }

public static void main(String[]args)
{
	reversenatural obj= new reversenatural();
obj.natural();
}
}





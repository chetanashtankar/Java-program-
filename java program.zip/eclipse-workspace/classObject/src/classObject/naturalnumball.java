package classObject;
 //Q1. Write a program to print all natural numbers from 1 to n. - using while loop

import java.util.Scanner;
public class naturalnumball 
{
	Scanner sc=new Scanner(System.in);	
	  
	
	public void natural()
	{
		    int n = sc.nextInt();
		    int i = 1;
		    while (i <= n)
		    {
		      System.out.print(i + " ");
		      i++;
		    }
		  }
	    
	public static void main(String[]args)
	{
		naturalnumball obj= new naturalnumball();
		obj.natural();
	}
	}



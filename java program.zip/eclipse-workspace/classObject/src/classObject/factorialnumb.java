package classObject;
import java.util.Scanner;
public class factorialnumb
{
  Scanner sc=new Scanner(System.in);
  
  public void fact()
  {
	int  fact =1;
	 System.out.println("enter the number");
	 int n=sc.nextInt();
	 
	  for(int i=1;i<=n;i++)
	  {
		  fact=fact*i;
		  
	  }
	  System.out.println("factorial of that number is :"+fact);
  }
  
  public static void main(String[]args)
  {
	  factorialnumb ob=new factorialnumb();
	  ob.fact();
  }
  
  
}

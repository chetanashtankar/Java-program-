package classObject;

public class removeduplicate {
	
	
		public void disp()
		{

				int arr[] = {1,2,3,3,3,4,5,6,6,7,8,6};
				for(int i=0;i<arr.length;i++)
				{
					int count=0;
					for(int j=i+1;j<arr.length;j++)
					{
						if(arr[i]==arr[j])
						{
							count++;
						}
					}
					if(count==0 && count!=1)
					{
						System.out.println(arr[i]);
					}
				}
				
			}

		
		public static void main(String[] args) {
			
			removeduplicate ob=new removeduplicate();
			ob.disp();
		}

	}



package classObject;
//find remove duplicate from an array
import java.util.Scanner;

public class freqarray
{
   Scanner sc=new Scanner(System.in);
   int a[];
  
   public  void input()
   {
	   System.out.println("enter array element");
	   a=new int[6];
	  
	   for(int  i=0;i<a.length;i++)
	   {
		   a[i]=sc.nextInt();
	   }
   }
   
   public void freq()
   {
	   
	   for( int i=0;i<a.length;i++)
	   {
		   for(int j=i+1;j<a.length;j++)
		   {
			   if(a[i]==a[j])
			   {
				   a[i]=0;
			   }
		   }
	   }
	   System.out.print("After removing duplicate element  ");
		  
	   for(int i=0;i<a.length;i++)
	   {
		   if(a[i]==0)
		   {
			   continue;
		   }
		   System.out.print(a[i]+"  ");
	   }
		  
	   
	   
	   
   }
   
   public static void main(String[]args)
   {
	   freqarray ob= new freqarray();
	   ob.input();
	   ob.freq();
   }
  
}

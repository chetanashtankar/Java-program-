package classObject;
import java.util.Scanner;
public class printtable 
{
	Scanner sc=new Scanner(System.in);
	
	public void table()
	{
		System.out.println("enter number");
		
		
		int j=sc.nextInt();
		 
		for(int i=1;i<=10;i++)
		{
			System.out.println(j+ " * "+i+ " = "+j*i);
		}
	}
	
	public static void main(String[]args)
	{
		printtable ob= new printtable();
		ob.table();
	}

}

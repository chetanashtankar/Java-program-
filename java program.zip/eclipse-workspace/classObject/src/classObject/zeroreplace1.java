package classObject;

public class zeroreplace1
{
	/* Q3. WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
    54, 34, 10, 0, 34] 
*/


public static void main(String[]args)
{
	zeroreplace1 ob=new zeroreplace1();
	ob.replace();
}
	public void replace()
	{
   int a[]={26, 0, 67, 45, 0, 78,54, 34, 10, 0, 34};

   System.out.println("original array");

   for(int i=0;i<a.length;i++)
    {
     System.out.print(a[i]+"  "); 
   }
  System.out.println();

  System.out.println("after converting 0 element to 1 in  array");

   
    for(int i=0;i<a.length;i++)
    {
        if(a[i]==0)
         {
          a[i]=1;
         }
   } 
 for(int i=0;i<a.length;i++)
    {
     System.out.print(a[i]+"  "); 
   }
  
}
}



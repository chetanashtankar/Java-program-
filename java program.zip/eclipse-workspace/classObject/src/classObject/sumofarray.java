package classObject;
import java.util.Scanner;
public class sumofarray
{
	Scanner sc=new Scanner(System.in);
	public void sum()
	{
		int a[]= {1,2,3,4,5,6,7,8};
		int sum=0;
		
	   for(int i=0;i<a.length;i++)
	   {
		   System.out.print(a[i]+"  ");
		   
		   sum=sum+a[i];
	   }
	   System.out.println();
	   System.out.println("sum of array="+sum);
		   
	}
	public static void main(String[]args)
	{
		
		sumofarray obj=new sumofarray();
		obj.sum();
	}

}

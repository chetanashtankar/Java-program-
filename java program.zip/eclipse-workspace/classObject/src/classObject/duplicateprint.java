package classObject;

import java.util.Scanner;


public class duplicateprint
{
Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	
    	
    	System.out.println("enter Array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
}
    public void dupli()
    { int c=0;
    System.out.println(" duplicate element in array");

    	for(int i=0;i<a.length;i++)
    	{
    		for(int j=i+1;j<a.length;j++)
    		{
    			if(a[i]==a[j])
    			{
    				System.out.println(a[i]);
    				c++;
    		
    			}
    		}
    	}
    	System.out.println("count of duplicate element="+c);
    }



public static void main(String[]args)
{
	duplicateprint obj=new duplicateprint();
	   obj.input();
	   obj.dupli();
}

}






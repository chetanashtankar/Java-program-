package classObject;

import java.util.Scanner;

public class calculation {
	Scanner sc=new Scanner(System.in);
	  int id;
	   String name;
	    
	    public void add()
	    {
	    	
	    	 
	    	System.out.println("enter id ");
	    	
	    	  int a,b;
	    	  a=sc.nextInt();
	    	  b=sc.nextInt();
	    	  System.out.println(a+" "+b);
	    }

	    public void sub()
	    {
	    	
	    	 
	    	int c,d;
	    	System.out.println("enter 2 id");
	    	
	       c=sc.nextInt();
	       d=sc.nextInt();
	       System.out.println(c+" "+d);
	 	  
	    }
	     public static void main(String[]args)
	     {
	    	 calculation obj=new calculation();
	    	 obj.add();
	    	  obj.sub();
	    	
	    	 
	    	 
	    	 
	     }
}

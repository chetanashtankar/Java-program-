package classObject;
// find second largest in array no sorting
import java.util.Scanner;

public class Second_largest
{
	Scanner sc=new Scanner(System.in);
	
	int a[];
	int max;
	int sec_max;
	public void input()
	{
		
		 a=new int[5];
		 System.out.println("enter array elememnt");
			
		 for(int i=0;i<a.length;i++)
		 {
					
		a[i]=sc.nextInt();
	}
		 
		 
	}
	
	public void max()
	{
		max=a[0];
		sec_max=a[0];
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max)
			{
				sec_max=max;
				max=a[i];
			}
			else if(a[i]>sec_max && a[i]!=max)
			{
				sec_max=a[i];
			}
		}
		 System.out.println("max element ="+max);
		 System.out.println("second max element ="+sec_max);
		 
			
	}
	public static void main(String[]args)
	{
		Second_largest obj=new Second_largest();
		obj.input();
		obj.max();
	}
	 
}

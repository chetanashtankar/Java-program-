package classObject;
import java.util.Scanner;
public class zeroterminate
{
	Scanner sc=new Scanner(System.in);
	
	public void terminate()
	{
		System.out.println("enter the number");
		int n=1,sum=0;
		
		while(n!=0)
		{
		n=sc.nextInt();
		sum=sum+n;
	   }
		System.out.println("loop terminate");
		
		System.out.println("sum of number="+sum);
		
	}
	
	public static void main(String[]args)
	{
		zeroterminate ob=new zeroterminate();
		ob.terminate();
	}

}

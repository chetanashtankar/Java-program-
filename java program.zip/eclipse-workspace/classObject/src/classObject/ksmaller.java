package classObject;
/*
 * Q22.Write a program that takes in an array of integers and finds the kth smallest value in the array.

 */
public class ksmaller 
{
	
	public static void main(String args[])
	{
		ksmaller ob=new ksmaller();
		ob.ksmall();
	}
	
	public void ksmall()
	{
	int a []= {7, 10, 4, 3, 20, 15};
	int i, j, temp=0;
	int k=3;
		for(i=0;i<a.length;i++)
		{
		System.out.println(a[i]+" ");
		}
			
			for(i=0;i<a.length;i++)
			{
				for(j=i+1;j<a.length;j++)
				{
					if(a[i]>a[j])
					{
						temp= a[i];
						a[i] = a[j];
						a[j]= temp;
					}
				}
			
			if(i==(k-1))
			{
				System.out.println("Kth Smallest Element is "+a[i] + " At position "+k);
					break;
			}
			}
			
			for(i=0;i<a.length;i++)
			{
				System.out.println(a[i]+" ");
			}
			
			
			
		
	}
	}


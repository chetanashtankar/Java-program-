package classObject;
import java.util.Scanner;
public class evennewarraystore
{
	Scanner sc=new Scanner(System.in);
	
	public void evenArray()
	{
		System.out.println("enter array element");
		int i;
		int a[]=new int[4];
		int b[]=new int[4];
		int c[]=new int[a.length+b.length];
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter array element");
		
		for(i=0;i<b.length;i++)
		{
			b[i]=sc.nextInt();
		}
		for(i=0;i<a.length;i++)
		{
			c[i]=a[i]+b[i];
		}
	   

		System.out.println("even  array element");
		
		for(i=0;i<c.length;i++)
		{
			if(c[i]%2==0) {
				
				System.out.println(c[i]);
			}
		}
	}
		
		public static void main(String[]args)
		{
			evennewarraystore obj=new evennewarraystore();
			obj.evenArray();
			
		}
	
	

}

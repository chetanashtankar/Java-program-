package classObject;
import java.util.Scanner;
public class checkprime
{
	Scanner sc=new Scanner(System.in);
	
	public void prime()
	{
		int n=sc.nextInt();
		int c=0;
		while(n!=0)
		{
			int i=2;
			if(n%i==0)
			{
				c++;
				
			}
			 
			
			i++;
		}
		if(c==0)
		{
			System.out.println("prime number");
		}
		
		else {

			System.out.println("not prime number");
	
		}
		
		
		
	}
	public static void main(String[]args)
	{
		checkprime ob= new checkprime();
		ob.prime();
	}
	 

}

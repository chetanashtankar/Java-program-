package classObject;
//Write a program that takes in an array of integers and finds the maximum and minimum values in the array.
public class maxmin 
{
	public void max()
	{
		 int a[] = {3, 2, 1, 56, 10000, 167};
		 
		  for(int i=0;i<a.length;i++)
		   {
		   System.out.print(a[i]+"  ");

		   }
		       System.out.println();

		 
		    int max=a[0];
		     for(int i=0;i<a.length;i++)
		    {
		      for(int j=i+1;j<a.length;j++)
		        {

		            if(max < a[i])
		             {
		               max=a[i];  
		          }

		      }    

		   }
		     System.out.println("max number in array="+max);
		     
	}
	public void min()
	{
		 int a[] = {3, 2, 1, 56, 10000, 167};
			
		int min=a[0];
		     for(int i=0;i<a.length;i++)
		    {
		      for(int j=i+1;j<a.length;j++)
		        {

		            if(min > a[i])
		             {
		               min=a[i];  
		          }

		      }    

		   }
		      
		   
		        
		     System.out.println("min number in array="+min);


	}
	
	public static void main(String[]args)
	{
		
		maxmin obj=new maxmin();
		obj.max();
		obj.min();
	}
	
	
	
		  


		
		
		
	}



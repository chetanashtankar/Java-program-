package Comparable;
/*
 * Create a Person class and implement a Comparator to sort instances by their last names.

 */

import java.util.Comparator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

	class Person
	{
	    private String firstName;
	    private String lastName;

	    public Person(String firstName, String lastName) 
	    {
	        this.firstName = firstName;
	        this.lastName = lastName;
	    }

	    public String getFirstName() {
	        return firstName;
	    }

	    public String getLastName() {
	        return lastName;
	    }

	    @Override
	    public String toString() {
	        return firstName + " " + lastName;
	    }
	}

	class LastNameComparator implements Comparator<Person> {
	    @Override
	    public int compare(Person person1, Person person2) {
	        return person1.getLastName().compareTo(person2.getLastName());
	    }
	}

	public class personComparable 
	{
	    public static void main(String[] args) {
	        List<Person> people = new ArrayList<>();
	        people.add(new Person("Nehal", "Dafre"));
	        people.add(new Person("CHetan ", "Ashtankar"));
	        people.add(new Person("swarup", "pawar"));

	        System.out.println("Before sorting:");
	        for (Person person : people) 
	        {
	            System.out.println(person);
	        }

	        Collections.sort(people, new LastNameComparator());

	        System.out.println("\nAfter sorting by last name:");
	        for (Person person : people) {
	            System.out.println(person);
	        }
	    }
	


}

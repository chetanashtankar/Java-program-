package Comparable;

public class ComparablePerson  implements Comparable <ComparablePerson>{
	private String name;
	private int age;
	 	 
			@Override
			public int compareTo(ComparablePerson o) {
				 
			  return Integer.compare(this.age, o.age);
			}
			
	 
public ComparablePerson(String name, int age) {
				 
				this.name = name;
				this.age = age;
			}
	
 	public String getName() {
		return name;
	}




	public int getAge() {
		return age;
	}




	@Override
	public String toString() {
		return "\n name=" + name + ", age=" + age ;
	}




	public static void main(String[] args) {
	 
		ComparablePerson ob= new ComparablePerson("Nehal",24);
		ComparablePerson ob1= new ComparablePerson("chetan",25);
		
		 System.out.println(ob);
		System.out.println(ob1);
		
	System.out.println();
	    int result = ob.compareTo(ob1);

	    if (result < 0) {
	        System.out.println(ob.getName() + " is younger than " + ob1.getName());
	    } else if (result > 0) {
	        System.out.println(ob.getName() + " is older than " + ob1.getName());
	    } else {
	        System.out.println(ob.getName() + " and " + ob1.getName() + " are of the same age.");
	    }
	 
	
	 
		
	}


}

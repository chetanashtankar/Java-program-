import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Update_Data {

	public static void main(String[] args) {

try {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");

	String sql="update emp set Emplo_name=?, email=? where id=?";
	
	PreparedStatement ps=con.prepareStatement(sql);
	
	ps.setInt(1,101);
	ps.setString(2, "saurav");
	ps.setString(3,"saurav@gmail.com");
	
	int status =0;
	status =ps.executeUpdate();
	if(status>0)
	{
		
		System.out.println("your data has been updated");
		
	}
	
	else {
		System.out.println("something went wrong");
	}
	
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}

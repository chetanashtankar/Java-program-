import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
/*
 * Create a menu program 

Employee Management System 

1. Insert the employee data 
2. Search the employee data 
3. All Employee infromations 
4. Delete the employee informations 
5. Update the employee data 
6. Exit 


you have to design a method for each operations and call the methods on swtich case.

 */
public class Menu_program {

	
public void insert()
{
	

	try {
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
		String sql="insert into emp values(?,?,?)";
		
		PreparedStatement ps= con.prepareStatement(sql);
		
		ps.setInt(1, 20);
		
		ps.setString(2, "Pranay");
		ps.setString(3, "pranay@gmail.com");  
		 

				 ps.executeUpdate();

				 System.out.println(" data will be successfully Added");
				 
	}catch (Exception e) {
		 e.printStackTrace();
	}

}


public void search()
{
	

try {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/april","root","12345678");
	
	Scanner sc= new Scanner(System.in);
	System.out.println("enter employee id search the employee details");
	
	int id = sc.nextInt();
	
	String sql= "select * from emp where id ="+id;
	
	PreparedStatement ps= con.prepareStatement(sql);
	ResultSet rs= ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
	}
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
	

}

public void all_data()
{
	try {
		
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
	
		 String sql= "select  * from emp";
		 PreparedStatement ps= con.prepareStatement(sql);
		 
		 ResultSet rs= ps.executeQuery();
		 
		 System.out.println("fetch the table ");
		 
		 while(rs.next())
		 {
			 
			 System.out.println(rs.getInt(1)+"     " +rs.getString(2) +"    "+ rs.getString(3));
		 }
}catch (Exception e) {
e.printStackTrace();
}



}


public void delete()
{

try {
	
	
  Class.forName("com.mysql.cj.jdbc.Driver");
 Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/april","root","12345678");
 
Scanner sc= new Scanner(System.in);
System.out.println("enter employee id to delete the empl details");
int id=sc.nextInt();

 String sql="delete from emp where id= "+id;
  PreparedStatement ps= con.prepareStatement(sql);
  
int status =0;
status =ps.executeUpdate();

if(status>0)
{
	
System.out.println("your data has been deleted");

}
else {
	
	
	
	System.out.println("sorry this employee is not available");
}

} catch (Exception e) {
	e.printStackTrace();
}


}


public void update()
{
	



}
public void menu()
{
	System.out.println("######  MENU PROGRAM  ######");
	System.out.println("1.INSERT THE EMPLOYEE DATA");
	System.out.println("2.SEARCH THE EMPLOYEE DATA");
	System.out.println("3. ALL EMPLOYEE INFORMATION");
	System.out.println("4.DELETE THE EMPLOYEE DATA");
	System.out.println("5.UPDATE THE EMPLOYEE DATA");
	System.out.println("6.EXIT");

}


	public static void main(String[] args) {
      Scanner sc= new Scanner(System.in);
      char ch;

		do {
		
			Menu_program ob= new Menu_program();
			ob.menu();
			System.out.println();
			System.out.println("enter number u want to search");
			int n=sc.nextInt();
			
			if(n==1)
			 
				ob.insert();
			 
			if(n==2)
			 
				ob.search();
			 
			
			if(n==3)
			 
				ob.all_data();
			 
			if(n==4)
			
				ob.delete();;
		
			if(n==5)
			 	ob.update();
			 
			
			 
			System.out.println("DO YOU WANT TO CONTINUE, PLEASE PRESS Y");
			 ch=sc.next().charAt(0);
			
			
		}while(ch=='y');
	}

}

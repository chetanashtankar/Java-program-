import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

 
public class Collable_Statement {

	public static void main(String[] args) {
	 
		try {
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
			String sql=" call get allWorkere22";
			
		 CallableStatement cs=con.prepareCall(sql);
		  ResultSet rs=cs.executeQuery();
		  
		  while(rs.next())
		  {
			  System.out.println(rs.getInt(1) + " "+ rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getDate(5)+" "+rs.getString(6));
			  
		  }
		 
			
		
	}catch (Exception e) {
		// TODO: handle exception
	}

}
}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Fetch_DataINMYSQL {

	public static void main(String[] args) {
		 

		try {
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
		
			 String sql= "select  * from people";
			 PreparedStatement ps= con.prepareStatement(sql);
			 
			 ResultSet rs= ps.executeQuery();
			 
			 System.out.println("fetch the table ");
			 
			 while(rs.next())
			 {
				 
				 System.out.println(rs.getInt(1)+"     " +rs.getString(2) +"    "+ rs.getString(3)+"       "+rs.getDate(4));
			 }
	}catch (Exception e) {
	e.printStackTrace();
	}

}
}

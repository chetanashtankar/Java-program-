import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Delete_intable {

	public static void main(String[] args) {

try {
	
	
  Class.forName("com.mysql.cj.jdbc.Driver");
 Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/april","root","12345678");
 
Scanner sc= new Scanner(System.in);
System.out.println("enter employee id to delete the empl details");
int id=sc.nextInt();

 String sql="delete from emp where id= "+id;
  PreparedStatement ps= con.prepareStatement(sql);
  
int status =0;
status =ps.executeUpdate();

if(status>0)
{
	
System.out.println("your data has been deleted");

}
else {
	
	
	
	System.out.println("sorry this employee is not available");
}

} catch (Exception e) {
	// TODO: handle exception
}
	}

}

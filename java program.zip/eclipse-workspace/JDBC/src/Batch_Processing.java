import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Batch_Processing {

	public static void main(String[] args) {
		
	 try {
	 	Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
		String sql="insert into emp values(?,?,?)";
		
   PreparedStatement ps= con.prepareStatement(sql);
   

   while(true)
   {
	   
	   Scanner sc= new Scanner(System.in);
	    System.out.println("enter  id ");
		int id= sc.nextInt();
	 	System.out.println("enter name");
		String name=sc.next();
	 	System.out.println("enter email");
		String email=sc.next();
	 	
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, email);
		
		ps.addBatch();
		
		System.out.println("Do You want to insert more data if yes press Y if no then press n");
		
		char ch=sc.next().charAt(0);
		
		
		if(ch=='n')
			System.out.println("your data will be save");
			break;
   }
   
		ps.executeBatch();	
	   
   ps.executeBatch();
	 }catch (Exception e) {
		 
		 e.printStackTrace();
	}
	}

}

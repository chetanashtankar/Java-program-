import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Insertion_inputing {

	public static void main(String[] args) {
	try {
		
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
		String sql="insert into emp values(?,?,?)";
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter  id ");
		int id= sc.nextInt();
	 	System.out.println("enter name");
		String name=sc.next();
	 	System.out.println("enter email");
		String email=sc.next();
	 	PreparedStatement ps= con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, email);
		
		ps.executeUpdate();
		
		System.out.println("your data will be successfully added");
		
		
	
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	}

}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Connection_mysql {

	public static void main(String[] args) {
		 
		try {
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
			String sql="insert into emp values(?,?,?)";
			
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setInt(1, 20);
			
			ps.setString(2, "Pranay");
			ps.setString(3, "pranay@gmail.com");  
			 

					 ps.executeUpdate();

					 System.out.println(" data will be successfully Added");
					 
		}catch (Exception e) {
			 e.printStackTrace();
		}
	}
}

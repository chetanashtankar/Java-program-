import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Search_Data {

	public static void main(String[] args) {

try {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/april","root","12345678");
	
	Scanner sc= new Scanner(System.in);
	System.out.println("enter employee id search the employee details");
	
	int id = sc.nextInt();
	
	String sql= "select * from emp where id ="+id;
	
	PreparedStatement ps= con.prepareStatement(sql);
	ResultSet rs= ps.executeQuery();
	
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
	}
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
	}

}

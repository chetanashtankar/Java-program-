/*
 * // WAP to create a table employee232 with the attribute (id, name,email,position,salary,doj,city,country,zip_code)
           1. id should be auto_increment and primary key
           2. email would be unique
           3. check if employee age is greate than 18. 
           4. insert the data using jdbc
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Insertion_mysqlTable {

	public static void main(String[] args) {

		try {
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
			String sql="insert into employee22 values( id int Auto_increment Primary key,name varchar(30),,email varchar(30) unique, position varchar(40),salary int , doj Date,city varchar(30), country varchar(30),zip_code varchar(10), age int check (age > 18) )";
			
			PreparedStatement ps= con.prepareStatement(sql);
			 
			ps.setInt(1, 1);
			
			ps.setString(2, "Pranay");
			ps.setString(3, "pranay@1gmail.com");
			ps.setString(4,"HR");
           ps.setInt(5, 12000);
           ps.setDate(6,java.sql.Date.valueOf("2023-09-26"));
           ps.setNString(7, "Pune");
           ps.setNString(8, "INDIA");
           ps.setString(9, "411058");
           
           
          
           
	ps.executeUpdate();
		
		System.out.println("your data will be successfully added");
		
           
        	con.close(); 
			
	}catch (Exception e) {
		// TODO: handle exception
	}

}
}

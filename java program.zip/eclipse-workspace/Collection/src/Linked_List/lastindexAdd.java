package Linked_List;

import java.util.LinkedList;

public class lastindexAdd {

	public static void main(String[] args) {


	LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob);  
		  
		  ob.offerLast(96);
		  System.out.println("after inserting last index");
		  
		  System.out.println(ob);
	}

}

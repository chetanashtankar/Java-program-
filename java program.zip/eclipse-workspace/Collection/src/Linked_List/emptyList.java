package Linked_List;

import java.util.LinkedList;

/*
 * 25. Write a Java program to check if a linked list is empty or not.

 */
public class emptyList {

	public static void main(String[] args) {
		 
	 	LinkedList ob= new LinkedList();
		
	 	
	 	System.out.println("before insert element check the list is empty or not="+ob.isEmpty());
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob); 
		 System.out.println("after inserting element check the list is empty or not="+ob.isEmpty());
		  
	}

}

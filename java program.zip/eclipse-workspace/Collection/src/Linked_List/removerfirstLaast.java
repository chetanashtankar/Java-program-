package Linked_List;

import java.util.LinkedList;

/*
 * 13. Write a Java program to remove the first and last elements from a linked list.

 */
public class removerfirstLaast {

	public static void main(String[] args) {

LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		  
		  System.out.println("remove first and last element");
		  ob.removeFirst();
		  ob.removeLast();
		  System.out.println(ob);
	}

}

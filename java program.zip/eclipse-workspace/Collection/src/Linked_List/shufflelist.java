package Linked_List;
/*
 * 16. Write a Java program to shuffle elements in a linked list.


 */
import java.util.*;
public class shufflelist {

	public static void main(String[] args) {
		 
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		  System.out.println("shuffle elements ");
		 Collections.shuffle(ob);
		 
		 System.out.println(ob);
		 
		 
		 
	}

}

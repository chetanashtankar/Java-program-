package Linked_List;
/*
 * 20. Write a Java program to retrieve, but not remove, the first element of a linked list.


 */
import java.util.LinkedList;

public class Retrive_remove {

	public static void main(String[] args) {
		LinkedList <String>  ob = new LinkedList ();
		ob.add("Java");
		ob.add("C");
		ob.add("Cpp");
		ob.add("Python");
		ob.add("Php");
		System.out.println("Given linked list: " + ob); 
		String b = ob.peekFirst();
		System.out.println("First Element in the linked list : " + b);
		System.out.println("New linked list: " + ob);   
	}

}

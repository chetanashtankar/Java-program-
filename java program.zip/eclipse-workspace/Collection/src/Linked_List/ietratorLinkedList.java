package Linked_List;
/*
 * 2. Write a Java program to iterate through all elements in a linked list.


 */
import java.util.LinkedList;

public class ietratorLinkedList {

	public static void main(String[] args) {
		      LinkedList<String> ob = new LinkedList<String>();
		    
		      ob.add("Red");
		          ob.add("Green");
		          ob.add("Black");
		          ob.add("White");
		          ob.add("Pink");
		        
		          
		          for (String element : ob) {
		    System.out.println(element);
		    }
		 

	}

}

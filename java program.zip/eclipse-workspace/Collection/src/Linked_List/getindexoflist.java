package Linked_List;

import java.util.LinkedList;

/*
 * 11. Write a Java program to display elements and their positions in a linked list.


 */
public class getindexoflist {

	public static void main(String[] args) {
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob);
		  
		  for(int i = 0; i < ob.size(); i++)
			{
				System.out.println("Element at index "+i+" : "+ob.get(i));
			} 
		 
	}

}

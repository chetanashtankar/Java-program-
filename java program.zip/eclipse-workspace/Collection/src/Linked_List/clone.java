package Linked_List;
/*
 * 18. Write a Java program to copy a linked list to another linked list.

 */
import java.util.LinkedList;

public class clone {
	public static void main(String[] args) {
		 
		
		LinkedList ob= new LinkedList();
				
				ob.add(1);
				ob.add(2);
				ob.add(5);
				
				ob.add(3);
				ob.add(4);
				ob.add(8);
				
	
				System.out.println(ob);
	
LinkedList ob1= new LinkedList();
				
				 ob1=(LinkedList)ob.clone();
				 
				 System.out.println("copy one list into another");
				 System.out.println(ob1);
				
				
				
	
	
	}
	
	

}

package Linked_List;

import java.util.Collections;
import java.util.LinkedList;

/*
 * 15. Write a Java program that swaps two elements in a linked list.

 */
public class SwapTwonumb {

	public static void main(String[] args) {
		 
		
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		 
		  Collections.swap(ob, 0, 2);
		  
		  System.out.println("swap two number");
		  
			
		  System.out.println(ob);
	}

}

package Linked_List;

import java.util.LinkedList;

/*
 * 26. Write a Java program to replace an element in a linked list.
 */
public class chengeElement {

	public static void main(String[] args) {

LinkedList ob= new LinkedList();
		
	 	
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob); 
		  
		  ob.set(2, 10);
		  System.out.println("after replacing element");
		  System.out.println(ob);
		
	}

}

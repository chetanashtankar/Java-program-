package Linked_List;
import java.util.ArrayList;
import java.util.LinkedList;
/*
 * 1. Write a Java program to append the specified element to the end of a linked list.



 */
public class demo {

	public static void main(String[] args) {


		LinkedList ob= new LinkedList<>();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		System.out.println(ob);
		ob.addLast(9);
		System.out.println("After adding last index");
		System.out.println(ob);
		
	}

}

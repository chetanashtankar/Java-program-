package Linked_List;

import java.util.LinkedList;

/*
 * 9. Write a Java program to insert some elements at the specified position into a linked list.


 */
public class insertSomeEle {

	public static void main(String[] args) {
		
		
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob);  
		  
		 
		  LinkedList ob1= new LinkedList();
			
			ob1.add(11);
			ob1.add(12);
			ob1.add(15);
			
			 
			System.out.println("second list="+ob1);
			
			
			ob.addAll(1, ob1);
			
			System.out.println("inserting element at the position of 1");
			System.out.println(ob);
		
		  
		 
		
		
	}

}

package Linked_List;
/*
 * 21. Write a Java program to retrieve, but not remove, the last element of a linked list.
 */
import java.util.LinkedList;

public class peekLast {

	public static void main(String[] args) {
		LinkedList <String>  ob = new LinkedList ();
		ob.add("Java");
		ob.add("C");
		ob.add("Cpp");
		ob.add("Python");
		ob.add("Php");
		System.out.println("Given linked list: " + ob); 
		String b = ob.peekLast();
		System.out.println("Last Element in the linked list : " + b);
		System.out.println("New linked list: " + ob); 
	}

}

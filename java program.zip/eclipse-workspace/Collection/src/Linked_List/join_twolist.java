package Linked_List;

import java.util.LinkedList;

/*
 * 
17. Write a Java program to join two linked lists.

 */
public class join_twolist {

	public static void main(String[] args) {
		 
		
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		  
		
		  LinkedList ob1= new LinkedList();
			
			ob1.add(11);
			ob1.add(12);
			ob1.add(15);
			
			ob1.add(13);
			ob1.add(14);
			ob1.add(18);
			
			  System.out.println(ob1);
			  
			  System.out.println("join two list");
			  ob.addAll(ob1);
			  System.out.println(ob);
			  
			
		
	}

}

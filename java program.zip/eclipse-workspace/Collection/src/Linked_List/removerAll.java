package Linked_List;

import java.util.LinkedList;
/*
 * 14. Write a Java program to remove all elements from a linked list.

 */
public class removerAll {

	public static void main(String[] args) {
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		  ob.removeAll(ob);
		  System.out.println(ob);
	}

}

package Linked_List;

import java.util.LinkedList;

/*
 * 
7. Write a Java program to insert the specified element at the front of a linked list.

 */
public class insertfront {

	public static void main(String[] args) {
		 
		LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob);  
		  
	ob.offerLast(65);
	System.out.println("after inserting element at the end ");
	System.out.println(ob);
	
	}

}

package Linked_List;
/*
 * 23. Write a Java program to convert a linked list to an array list.

 */
import java.util.ArrayList;
 import java.util.LinkedList;
 import java.util.List;
public class linkedToArray {

	public static void main(String[] args) {
	 
	 

     LinkedList<String> l = new LinkedList<String>();
      l.add("Orange");
      l.add("Apple");
      l.add("Peach");
      l.add("Guava");
      l.add("Pear");
      List<String> aRRList = new ArrayList<String>(l);
      System.out.println("The ArrayList elements are: ");
    for (Object i : aRRList) {
         System.out.println(i);
      }
	}
}
package Linked_List;

import java.util.Collections;
import java.util.LinkedList;

 import java.util.*;
/*
 * 4. Write a Java program to iterate a linked list in reverse order.

 */
public class reversedLinked {

	public static void main(String[] args) {
		LinkedList ob= new LinkedList<>();
	
	ob.add(1);
	ob.add(2);
	ob.add(5);
	
	ob.add(3);
	ob.add(4);
	ob.add(8);
	
	  System.out.println("Original linked list:" + ob);  
	 
	    Iterator it = ob.descendingIterator();

	       System.out.println("Elements in Reverse Order:");
	     while (it.hasNext()) {
	        System.out.println(it.next());
	     }

	}

}

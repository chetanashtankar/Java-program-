package Linked_List;

import java.util.LinkedList;

/*
 * 
10. Write a Java program to get the first and last occurrence of the specified elements in a linked list.

 */
public class getfirstandLast {

	public static void main(String[] args) {
		 
		
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println("Original linked list:" + ob);  
		  
		  
		  System.out.println("first Occurance="+ob.getFirst());
		  
		  System.out.println("Last occurance="+ob.getLast());
		 
	}

}

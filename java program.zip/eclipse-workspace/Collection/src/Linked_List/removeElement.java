package Linked_List;

import java.util.LinkedList;
/*
 * 12. Write a Java program to remove a specified element from a linked list.


 */
public class removeElement {

	public static void main(String[] args) {
LinkedList ob= new LinkedList();
		
		ob.add(1);
		ob.add(2);
		ob.add(5);
		
		ob.add(3);
		ob.add(4);
		ob.add(8);
		
		  System.out.println(ob);
		  ob.remove(2);
		  
		  System.out.println("remove element 2 index");
		  System.out.println(ob);
	}

}

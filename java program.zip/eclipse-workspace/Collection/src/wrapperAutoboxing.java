
public class wrapperAutoboxing {

	public static void main(String[] args) {


	   float f1=20.0f;
	   float f2=30.5f;
	   
	   Float f=Float.valueOf(f1);
	   
	 System.out.println(f);
	 
	 System.out.println(f.TYPE);
	 System.out.println(f.MAX_VALUE);
	 System.out.println(f.MIN_VALUE);
	 System.out.println(f.max(f1, f2));
	 System.out.println(f.min(f1, f2));
	 
	 System.out.println();
	 
	 int a=10;
	 int b=20;
	 
	 Integer i=Integer.valueOf(a);
	 
	 System.out.println(i);
	 
	 System.out.println(i.MAX_VALUE);
	 System.out.println(i.MIN_VALUE);
	 System.out.println(i.max(a, b));
	 System.out.println(i.min(a, b));
	 
	 
	}

}

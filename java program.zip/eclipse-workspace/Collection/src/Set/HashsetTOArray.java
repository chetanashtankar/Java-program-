package Set;

import java.util.HashSet;

public class HashsetTOArray {

	public static void main(String[] args) {
		 
		HashSet<Integer> ob=new HashSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	System.out.println(ob);
	
	
	 Integer[] a = new Integer[ob.size()];
     ob.toArray(a);

    
     System.out.println("convert  hashtable to Array");
     
     System.out.println("Array elements: ");
    
     for(Integer ab : a)
     {
       System.out.println(ab);
	}

}
}

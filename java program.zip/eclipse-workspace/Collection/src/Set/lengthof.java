package Set;

import java.util.HashSet;

public class lengthof {

	public static void main(String[] args) {
		HashSet<Integer> ob=new HashSet<Integer>();
		System.out.println(ob.isEmpty());
		
 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	System.out.println(ob);
	System.out.println("number  of  element in the hashset");
	System.out.println(ob.size());
	}

}

package Set;
import java.util.*;
public class hashset {

	public static void main(String[] args) {
	 
		HashSet ob=new HashSet();
		
		System.out.println(ob);
		System.out.println("hashset is empty ="+ob.isEmpty());
		  
		
		 
	}

}

package Set;

import java.util.HashSet;
import java.util.LinkedList;

/*
 * 6. Write a Java program to clone a hash set to another hash set.

 */
public class clonehashset {

	public static void main(String[] args) {
		 
		HashSet<Integer> ob=new HashSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	System.out.println(ob);
	
	HashSet<Integer> ob1=new HashSet<Integer>();
	
	 ob1=(HashSet)ob.clone();
 	 
 	 System.out.println("clone hashset to another hashset");
	System.out.println(ob1);
	
	}

}

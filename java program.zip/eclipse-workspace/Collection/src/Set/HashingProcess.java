package Set;
import java.util.*;
public class HashingProcess {

	public static void main(String[] args) {

	HashSet ob=new HashSet();
		

	ob.add("Dog");
	
	ob.add("Apple");
	ob.add("Cat");
	
	
	System.out.println(ob);
		
	}

}

package Set;

import java.util.HashSet;
import java.util.Iterator;
/*
 * 2. Write a Java program to iterate through all elements in a hash list.

 */
public class Iterate {

	public static void main(String[] args) {


		HashSet<Integer> ob=new HashSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	
	
	System.out.println("Hashset="+ob);
	
	 
	System.out.println("iterate all elements");
	   for (int element : ob) {
		    System.out.println(element);
		    }
}

	 
	}



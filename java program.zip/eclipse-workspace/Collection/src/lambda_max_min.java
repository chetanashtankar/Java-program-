 import java.util.ArrayList;
			import java.util.List;
			

interface demo1
{
	public void  disp();


}
public class lambda_max_min {

	public static void main(String[] args) {
		 
		
		demo1 ob= ()->
		{
			ArrayList<Integer> o = new ArrayList<>();
			        o.add(5);
			        o.add(12);
			        o.add(3);
			        o.add(8);
			        o.add(1);
			        
			        System.out.println(o);
			        System.out.println("using lambda Expression");
					
			        int max = Integer.MIN_VALUE;
			        int min = Integer.MAX_VALUE;
			        
			        for (int num : o) 
			        {
			            if (num > max)
			            {
			                max = num;
			            }
			            if (num < min) 
			            {
			                min = num;
			            }
			        }
			        
			        System.out.println("Maximum value: " + max);
			        System.out.println("Minimum value: " + min);
			  
		};
		
		
		ob.disp();
	}

}

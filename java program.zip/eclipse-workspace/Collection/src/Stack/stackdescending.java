package Stack;

import java.util.Collections;
import java.util.Stack;

public class stackdescending {

	public static void main(String[] args) {



		Stack ob=new Stack();
		ob.add(10);
		ob.add(3);
		ob.add(5);
		ob.add(4);
		ob.add(9);
		System.out.println( "stack :"+ob);
		System.out.println(" stack inAscending order ");
		
		
	
	  
	
	}
 
}

package Stack;

import java.util.HashSet;
import java.util.Stack;
/*
 * 1. Write a Java program that implements a stack and finds common elements between two stacks.


 */
public class ComparetwoStack {

	public static void main(String[] args) {

	 
		Stack ob=new Stack();
		ob.add(1);
		ob.add(3);
		ob.add(5);
		ob.add(7);
		ob.add(9);
		System.out.println("first stack :"+ob);
		Stack ob1=new Stack();
		ob1.add(1);
		ob1.add(3);
		ob1.add(5);
		ob1.add(7);
		ob1.add(8);
		System.out.println("second stack :"+ob1);
		
		
		System.out.println("common From two stack :");
		int c=0;
		int i;
		for ( i = 0; i < ob.size(); i++) {
			
			for (int j = i; j <ob1.size(); j++) {
				if(ob.get(i)==ob1.get(j))
				{   c++;
					System.out.println(ob.get(i));
				}
				
				
			}
			
		}
		 
}

}

package Stack;
import java.util.*;
/*
 * 18. Write a Java program to merge two stacks into one.


 */
public class mergetwoStack {

	public static void main(String[] args) {



		Stack m=new Stack();
		m.add(10);
		m.add(20);
		m.add(40);
		System.out.println(m);
			Stack ob=new Stack();
		ob.add(50);
		ob.add(60);
		ob.add(70);
		System.out.println(ob);
		
		System.out.println("merge two stack in one");
		
		m.add(ob);
		System.out.println(m);
	}

}

package Stack;

import java.util.HashSet;

public class CompareTwohash {

	public static void main(String[] args) {


	HashSet<Integer> ob=new HashSet<Integer>();
	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	System.out.println(ob);
	
	
	HashSet<Integer> ob1=new HashSet<Integer>();
	ob1.add(81);
	ob1.add(66);
	ob1.add(61);
	ob1.add(98);
	ob1.add(45);
	ob1.add(25);
	
	System.out.println(ob1);
	System.out.println(ob.equals(ob1));
	
	
	

	}

}

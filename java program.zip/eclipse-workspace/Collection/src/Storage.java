
import java.util.*;
public class Storage {

	public static void main(String[] args) {
		 
		
		ArrayList <pojoclass>ob= new ArrayList();
			ob.add(new pojoclass(141,"Nehal",15000,"nagpur"));
	 	ob.add(new pojoclass(131,"swarup",18000,"mumbai"));
		ob.add(new pojoclass(151,"chetan",11000,"pune"));
		ob.add(new pojoclass(131,"prakash",10000,"nashik"));
		
		System.out.println(ob);
		Collections.sort(ob);
		System.out.println();
		System.out.println("by using comparable interface");
		
		System.out.println(ob);
		
	}

}

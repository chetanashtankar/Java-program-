package Que;

import java.util.LinkedList;
import java.util.Queue;

public class FIFO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Queue ob= new LinkedList();
			ob.offer(12);
			ob.offer(98);
			ob.offer(52);
			ob.offer(17);
			ob.offer(788);
			ob.offer(546);
			
			System.out.println("  FIFO order in queue");
			System.out.println(ob);
			
			System.out.println(ob.poll());
			System.out.println(ob.poll());
			System.out.println(ob.poll());
			System.out.println(ob.poll());
			System.out.println(ob.poll());
			System.out.println(ob.poll());
			
			

	}

}

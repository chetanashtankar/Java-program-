package Que;
import java.util.*;
public class DequeMehtods {
	public static void main(String[] args) {
		
		
		Deque ob= new ArrayDeque();
		
		ob.addFirst(12);

		ob.addFirst(11);
		
		ob.addLast(45);
		ob.addLast(63);
		
		System.out.println(ob);
		
		
		
		
	System.out.println(ob.getFirst());	
	
	
	System.out.println(ob.getLast());
	System.out.println(ob);
	
	
	
	System.out.println(ob.removeFirst());
	
	System.out.println(ob);
	
	System.out.println(ob.removeLast());
	
	System.out.println(ob);
		
		
		
		
		
		
		
		
		
		
	}

}

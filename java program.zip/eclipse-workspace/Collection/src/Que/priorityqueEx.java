package Que;

import java.util.*;

public class priorityqueEx {

	public static void main(String[] args) {


		PriorityQueue ob= new PriorityQueue ();
		
		ob.offer(54);
		ob.offer(14);
		ob.offer(64);
		ob.offer(664);
		ob.offer(44);
		ob.offer(84);
		
		System.out.println(ob);
		
	}

}

import java.util.*;
public class pojoclass  implements  Comparable<pojoclass>
{

	
	private int id;
	private String name;
	private int salary;
	private String City;
	
	
	
	 
	public int compareTo(pojoclass o) {


		return this.City.compareTo(o.City);
	}


 

	public pojoclass(int id, String name, int salary, String city) {
		 
		this.id = id;
		this.name = name;
		this.salary = salary;
		City = city;
	}




	public int getId() {
		return id;
	}




	public String getName() {
		return name;
	}




	public int getSalary() {
		return salary;
	}




	public String getCity() {
		return City;
	}


	public String toString() {
		
		
		return "\nid=" + id + ", name=" + name + ", salary=" + salary + ", city=" + City;
		}


	public static void main(String[] args) {

		

		
		
	}

}

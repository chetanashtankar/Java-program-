package ArrayListc;
import java.util.*;
public class compareTOSet {

	public static void main(String[] args) {
		HashSet ob=new HashSet();
		ob.add(10);
		ob.add(20);
		ob.add(30);
		ob.add(40);
		ob.add(50);
		ob.add(60);
		
		HashSet ob1=new HashSet();
		ob1.add(10);
		ob1.add(20);
		ob1.add(30);
		ob1.add(40);
		ob1.add(50);
		ob1.add(60);
		
		System.out.println(ob);
		System.out.println(ob1);
		
		boolean eq=ob.equals(ob1);
		if(eq) {
			System.out.println("are Equal");
		}
		else {
			System.out.println("are not equal");
		}
	}

	
}

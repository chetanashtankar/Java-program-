package ArrayListc;
import java.util.*;
public class RemoveDuplicate {

	public static void main(String[] args) {

		ArrayList ob=new ArrayList();
		ob.add(18);
		ob.add(15);
		ob.add(15);
		ob.add(16);
		ob.add(18);
		ob.add(19);
		int c=0;
		System.out.println(ob);
		System.out.println("after remove duplicates :");
		
		for (int i = 0; i < ob.size(); i++) {
			
			for (int j = i+1; j < ob.size(); j++) {
				
				if(ob.get(i)==ob.get(j))
				{
					ob.remove(j);
				}
				
			}
			
			System.out.println(ob.get(i));
			
		}
	}
	
	}



package ArrayListc;

import java.util.ArrayList;

/*
 * 4. Write a Java program to retrieve an element (at a specified index) from a given array list.
 */
public class retrieveDataindex {

	public static void main(String[] args) 
	{
	 
ArrayList ob= new ArrayList();
		
		ob.add(12);
		ob.add(6);
		ob.add(13);;
		ob.add(7);
		ob.add(1);
		ob.add(8);
		
		System.out.println(ob);
		System.out.println("to get index element ");
		
		System.out.println(ob.get(0));
		
		System.out.println(ob.get(2));

	}

}

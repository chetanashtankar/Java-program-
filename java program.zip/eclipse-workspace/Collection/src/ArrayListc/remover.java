package ArrayListc;

import java.util.ArrayList;

public class remover {

	public static void main(String[] args) {
	 
		
ArrayList ob= new ArrayList();
		
		ob.add(12);
		ob.add("nihal");
		ob.add("apple");
		ob.add("chetan");
		ob.add(1);
		ob.add(8);
		
		System.out.println(ob);
		
		System.out.println(ob.remove(2));
		System.out.println(ob);
		
	}

}

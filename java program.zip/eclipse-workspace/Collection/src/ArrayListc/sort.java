 package ArrayListc;
import java.util.*;
public class sort {

	public static void main(String[] args) {
  
		ArrayList ob= new ArrayList();
		
		ob.add(12);
		ob.add(6);
		ob.add(3);
		ob.add(7);
		ob.add(1);
		ob.add(8);
		
		System.out.println(ob);
		Collections.sort(ob);
		System.out.println("after sorting");
		System.out.println(ob);

	}

}

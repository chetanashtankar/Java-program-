package ArrayListc;

import java.util.Collections;
import java.util.ArrayList;

public class DescendingArraylist {

	public static void main(String[] args) {
		ArrayList ob=new ArrayList();
		ob.add(80);
		ob.add(20);
		ob.add(40);
		ob.add(30);
		ob.add(70);
		ob.add(60);
		
		System.out.println(ob);
		Collections.sort(ob);
		System.out.println("Arraylist in Ascending");
		System.out.println(ob);
		Collections.reverse(ob);
		System.out.println("Arraylist in Descending");
		System.out.println(ob);
		
		
	}

}

package ArrayListc;

import java.util.ArrayList;

/*
 * 6. Write a Java program to remove the third element from an array list.

 
 */
public class replaceindex {

	public static void main(String[] args) {



		ArrayList ob= new ArrayList();
			
			ob.add(1);
			ob.add(2);
			ob.add(3);
			ob.add(4);
			ob.add(5);
			ob.add(6);
			
			System.out.println(ob);
			System.out.println("After removing third element");
			ob.remove(3);
			System.out.println(ob);
		
		
		
		
		
	}

}

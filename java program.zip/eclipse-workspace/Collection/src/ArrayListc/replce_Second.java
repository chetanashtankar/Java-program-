package ArrayListc;

import java.util.ArrayList;

public class replce_Second
{
	public static void main(String[] args) {
		
ArrayList ob= new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		ob.add(6);
		
		
		System.out.println(ob);
		
		System.out.println("after replacing third element");
		ob.set(3, 9);
		
		System.out.println(ob);
		
	}

}

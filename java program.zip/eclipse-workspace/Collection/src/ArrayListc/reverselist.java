package ArrayListc;
/*
 * 11. Write a Java program to reverse elements in an array list.

 */
import java.util.ArrayList;
import java.util.Collections;

public class reverselist {

	public static void main(String[] args) {
		 
		
		ArrayList ob= new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		ob.add(6);
		
		System.out.println(ob);
		Collections.reverse(ob);
		
		System.out.println("reverse element in array list");
		System.out.println(ob);
	}
 
}

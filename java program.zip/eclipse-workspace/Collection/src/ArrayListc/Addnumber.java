package ArrayListc;

import java.util.ArrayList;

public class Addnumber {

	public static void main(String[] args) {


	ArrayList ob= new ArrayList();
		
		ob.add(12);
		ob.add(6);
		ob.add(3);
		ob.add(7);
		ob.add(1);
		ob.add(8);
		
		System.out.println(ob);
		ob.add(0, 13);
		System.out.println("after adding first position  ");
		
		System.out.println(ob);
	}

}

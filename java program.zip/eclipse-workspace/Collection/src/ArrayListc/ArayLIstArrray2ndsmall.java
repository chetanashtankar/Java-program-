package ArrayListc;

import java.util.ArrayList;
import java.util.Collections;

public class ArayLIstArrray2ndsmall {

	public static void main(String[] args) {
		ArrayList ob=new ArrayList();
		ob.add(80);
		ob.add(20);
		ob.add(40);
		ob.add(30);
		ob.add(70);
		ob.add(60);
		
		System.out.println(ob);
		
		 Integer[] a = new Integer[ob.size()];
	     ob.toArray(a);

	    
	     System.out.println("convert  hashtable to Array");
	     
	     System.out.println("Array elements: ");
	    
	     for(Integer ab : a)
	     {
	       System.out.println(ab);
		}
	     
	     
	     int min=Integer.MAX_VALUE;
	        int sec_min = Integer.MAX_VALUE;
	        
	        for (int i = 0; i < a.length; i++)
	        {
	        	if(a[i]<min)
				{
	        		sec_min=min;
	        		min=a[i];
				}
				
			}
	     
	     
	}

}

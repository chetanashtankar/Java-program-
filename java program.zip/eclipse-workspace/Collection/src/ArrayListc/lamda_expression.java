package ArrayListc;


interface demo
{
	public String  disp(String s);


}
public class lamda_expression {

	
	
	public static void main(String[] args) {


		demo ob= (s)->
		{
			 
			char a[]=s.toCharArray();
			
			for(int i=0;i<a.length;i++)
			{
				 System.out.print(a[i]+" ");
			}
			System.out.println();
			int b[]=new int[a.length];
			int x=0;
			
			System.out.println("using lambda expression");
			for(int i=a.length-1;i>=0;i--)
			{
				b[x++]=a[i];
			}
			 
			int count=0;
			
			for(int i=0;i<a.length;i++)
			{
				if(a[i]==b[i])
				{
					count=1;
					break;
				}
				else {
					count=0;
					break;
				} 
			}
			
			
			if(count==1)
			{
				 
				System.out.println("String is   palindrome");
				
				return s;
			}
			else {
				
				System.out.println("String is not palindrome");
				
				return s;
			}
			 
		};
		
		System.out.println(ob.disp("madam"));
		
	}

}

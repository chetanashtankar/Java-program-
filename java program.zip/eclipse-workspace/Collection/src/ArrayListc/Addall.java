package ArrayListc;

import java.util.ArrayList;

public class Addall {

	public static void main(String[] args) {
		 
		
ArrayList ob= new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		ob.add(6);
		
		System.out.println(ob);
ArrayList ob1= new ArrayList();
		
		ob1.add(7);
		ob1.add(8);
	   ob1.add(9);
	   ob1.add(10);
	   ob1.add(11);
	   System.out.println(ob1);
	  
	   System.out.println("join two list");
	   ob.addAll(ob1);
	   System.out.println(ob);
		
		
	}

}

package ArrayListc;

import java.util.*;
public class retainAll {

	public static void main(String[] args) {


		ArrayList ob=new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		
		System.out.println(ob);
		
ArrayList ob1=new ArrayList();
		
		ob1.add(1);
		ob1.add(2);
		ob1.add(8);
		ob1.add(3);
		ob1.add(9);
		
		System.out.println(ob1);
		System.out.println("duplicate ");
		ob.retainAll(ob1);
		System.out.println(ob);
		
		
	}

}

package ArrayListc;
/*
 * 7. Write a Java program to search for an element in an array list.

 */
import java.util.*;
public class SearchElement {

	public static void main(String[] args) {
	 
		ArrayList ob= new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		ob.add(6);
		
		System.out.println("search element 3 in arraylist");
		
		System.out.println(ob);
		
		if(ob.contains(3))
		{
			
			System.out.println("element found");
		}
		else {
			System.out.println("element not found");
		}
		
		

	}

}

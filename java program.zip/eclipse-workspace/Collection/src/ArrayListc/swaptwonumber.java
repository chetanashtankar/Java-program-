package ArrayListc;
/*
 * 14. Write a Java program that swaps two elements in an array list.

 */
import java.util.*;
public class swaptwonumber {

	public static void main(String[] args) {
	 
		
		ArrayList ob= new ArrayList();
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(4);
		ob.add(5);
		ob.add(6);
		
		System.out.println(ob);

		
		
		  Collections.swap(ob, 0, 2);
		  System.out.println("swap two number");
		  
		  System.out.println(ob);
	
	
	}

}

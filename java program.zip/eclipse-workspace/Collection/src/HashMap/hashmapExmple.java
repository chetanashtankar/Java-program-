package HashMap;

import java.util.HashMap;

public class hashmapExmple
{
	public static void main(String[] args) {
		
 HashMap ob = new HashMap();
		 
		 ob.put(12, "orange");
		 ob.put(40,"apple");
		 ob.put(45,"banana");
		 
		 System.out.println(ob);
		 
		 
		 System.out.println("after removing 2nd key"+ob.remove(40));
		 System.out.println(ob);
		
		
	} 

}

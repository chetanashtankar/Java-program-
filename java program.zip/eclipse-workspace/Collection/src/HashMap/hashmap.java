package HashMap;

import java.util.HashMap;

public class hashmap {

	public static void main(String[] args) {


		 HashMap ob = new HashMap();
		 
		 ob.put("Nehal", 155);
		 ob.put("Chetan", 60);
		 ob.put("shubham",55);
		 
		 System.out.println("1st Hashmap="+ob);
 HashMap ob1 = new HashMap();
		 
		 ob1.put("prakash", 165);
		 ob1.put("deepak", 78);
		 ob1.put("css",45);
		 System.out.println("2nd hashmap="+ob1);
		 ob.putAll(ob1);
		 
		 System.out.println("merge two hashmap=");
		 
		 System.out.println(ob);
		 
	}

}

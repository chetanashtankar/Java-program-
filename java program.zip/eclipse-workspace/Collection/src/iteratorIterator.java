import java.util.Iterator;
import java.util.LinkedList;

public class iteratorIterator {

	public static void main(String[] args) {
		  LinkedList<String> ob = new LinkedList<String>();
		    
	      ob.add("Red");
	          ob.add("Green");
	          ob.add("Black");
	          ob.add("White");
	          ob.add("Pink");
	        
	          
	          Iterator b= ob.listIterator(3);
	          while (b.hasNext()) 
	          {
	    System.out.println(b.next());
	    }
	}

}

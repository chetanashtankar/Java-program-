package TreeMap;

import java.util.LinkedList;
import java.util.TreeMap;

public class SearchKey {
 
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
		
		ob.put(1, "Apple");
		ob.put(6, "Orange");
		ob.put(2, "grapes");
		ob.put(5, "mango");
		ob.put(4, "guava");
		
		System.out.println(ob);
		
		if(ob.containsKey(2))
		{
			
			System.out.println("the tree map contains key 2");
		}
		
		else {
			System.out.println("the tree map not  contains key 2");
			
			
			
		}
		
		
	}

}

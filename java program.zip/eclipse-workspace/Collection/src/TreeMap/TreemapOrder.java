package TreeMap;
import java.util.*;
public class TreemapOrder {

	 

	public static void main(String[] args) {


		TreeMap ob= new TreeMap();
		
		ob.put(1, "Apple");
		ob.put(6, "Orange");
		ob.put(2, "grapes");
		ob.put(5, "mango");
		ob.put(4, "guava");
		
		System.out.println(ob);
		
		System.out.println("Size of Treemap:"+ob.size());
		/*System.out.println("Treemap in Descending");
		
		System.out.println(ob.descendingMap());
		*/
		
		
		
	}

}

package TreeMap;

import java.util.Iterator;
 
import java.util.*;

public class copy {

	 
	

	public static void main(String[] args) {



		TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
		
		ob.put(1, "Apple");
		ob.put(6, "Orange");
		ob.put(2, "grapes");
		ob.put(5, "mango");
		ob.put(4, "guava");
		
		System.out.println(ob);
		Scanner sc= new Scanner(System.in);
		System.out.println("enter u want to search value in treemap:");
		String s=sc.nextLine();
		if(ob.containsValue(s))
		{
			
			System.out.println("value is present in treemap");
		}
		  
	}

}

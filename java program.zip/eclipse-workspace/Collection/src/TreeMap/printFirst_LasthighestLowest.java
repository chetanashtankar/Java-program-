package TreeMap;
/*
 * 9. Write a Java program to get the first (lowest) key and the last (highest) key currently in a map.

 */

import java.util.TreeMap;

public class printFirst_LasthighestLowest {
	 

	public static void main(String[] args) {
		 
		TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
		
		ob.put(1, "Apple");
		ob.put(6, "Orange");
		ob.put(2, "grapes");
		ob.put(5, "mango");
		ob.put(4, "guava");
		
		System.out.println(ob);
		System.out.println("first lowest key :="+ob.firstKey());
		
		System.out.println("lAst highest key:="+ob.lastKey());
		
	}

}

package TreeMap;
/*
 * 5. Write a Java program to get all keys from a Tree Map.
 */
import java.util.*;

public class get_keys {

	public static void main(String[] args) {
		
		TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
				
				ob.put(1, "Apple");
				ob.put(6, "Orange");
				ob.put(2, "grapes");
				ob.put(5, "mango");
				ob.put(4, "guava");
				
				System.out.println(ob);
				
				System.out.println("All keys in treemap ");
				Set<Integer> keys = ob.keySet();
		        for(Integer key: keys){
		            System.out.println(key);
		        }
				
	}

}

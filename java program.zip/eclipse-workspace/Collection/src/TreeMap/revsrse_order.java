package TreeMap;

import java.util.TreeMap;

/*
 * 
10. Write a Java program to get a reverse order view of the keys contained in a given map.
 */
public class revsrse_order {

	public static void main(String[] args) {

		 
		TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
				
				ob.put(1, "Apple");
				ob.put(6, "Orange");
				ob.put(2, "grapes");
				ob.put(5, "mango");
				ob.put(4, "guava");
				
				System.out.println(ob);
				System.out.println("reverse order keys");
				
				System.out.println(ob.descendingKeySet());
	}

}

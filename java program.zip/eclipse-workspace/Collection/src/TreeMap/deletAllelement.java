package TreeMap;

import java.util.TreeMap;

public class deletAllelement {

	public static void main(String[] args) {
		 
TreeMap <Integer,String>ob= new <Integer,String>TreeMap();
		
		ob.put(1, "Apple");
		ob.put(6, "Orange");
		ob.put(2, "grapes");
		ob.put(5, "mango");
		ob.put(4, "guava");
		
		System.out.println(ob);
		
		
		ob.clear();
		System.out.println("Delete All element in Treemap");
		
		System.out.println(ob);
	}

}

package Treeset;

import java.util.Iterator;
import java.util.TreeSet;

/*
 * 4. Write a Java program to create a reverse order view of the elements contained in a given tree set.


 */
public class reverseTreeset {

	public static void main(String[] args) {


		TreeSet<Integer> ob=new TreeSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	
	
	System.out.println("  Treeset="+ob);
 
	 Iterator it = ob.descendingIterator();
    
	 System.out.println("Elements in Reverse Order:");
	 
     while (it.hasNext()) {
        System.out.println(it.next());
     }
	
	}

}

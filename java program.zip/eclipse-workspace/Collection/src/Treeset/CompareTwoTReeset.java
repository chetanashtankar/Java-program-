package Treeset;

import java.util.HashSet;
import java.util.TreeSet;

public class CompareTwoTReeset
{
	public static void main(String[] args) {
		
	 
	TreeSet<Integer> ob=new TreeSet<Integer>();
 	ob.add(88);
ob.add(65);
ob.add(64);
ob.add(99);
ob.add(85);
ob.add(87);

 

TreeSet ob1=new TreeSet();
ob1.add(10);
ob1.add(20);
ob1.add(30);
ob1.add(40);
ob1.add(50);
ob1.add(60);

System.out.println(ob);
System.out.println(ob1);

boolean eq=ob.equals(ob1);
if(eq) {
	System.out.println("are Equal");
}
else {
	System.out.println("are not equal");
}

}
}
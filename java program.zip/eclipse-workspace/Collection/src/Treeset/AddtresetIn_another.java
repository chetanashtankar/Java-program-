package Treeset;

import java.util.TreeSet;

public class AddtresetIn_another {

	public static void main(String[] args) {


		TreeSet<Integer> ob=new TreeSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	
	
	System.out.println("1st Treeset="+ob);
	
	TreeSet<Integer> ob1=new TreeSet<Integer>();
 	ob1.add(88);
ob1.add(62);
ob1.add(61);
 

System.out.println(" 2nd Treeset="+ob1);

ob.addAll(ob1);

System.out.println("add one treeset into another");
System.out.println(ob);

 
	 
	}

}

package Treeset;
import java.util.*;
public class EmployeePojo implements Comparable<EmployeePojo> 
{


	private int id;
	private String name;
	private String City;
	
	
	public int compareTo(EmployeePojo o)
	{
		return this.id-o.id;
    }


	public EmployeePojo(int id, String name, String city) {
		super();
		this.id = id;
		this.name = name;
		City = city;
	}
	
	


	public int getId() {
		return id;
	}


	public String getName() {
		return name;
	}


	public String getCity() {
		return City;
	}


	 
	public String toString() {
		return "\n"+"id =" + id + ", name=" + name   ;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package Treeset;

import java.util.TreeSet;

public class removeRetrieve {

	public static void main(String[] args) {


		 
 	TreeSet<Integer> ob=new TreeSet<Integer>();
 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);

	System.out.println(ob);
	
//	System.out.println("Removes the Last  element: "+ob.pollLast());
	ob.remove(64);
	
	System.out.println("After removing ="+ob);
	
	}

}

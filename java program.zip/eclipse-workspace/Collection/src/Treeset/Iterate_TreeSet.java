package Treeset;

import java.util.TreeSet;

public class Iterate_TreeSet {

	public static void main(String[] args) {
		TreeSet<Integer> ob=new TreeSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	
	
	System.out.println("Treeset="+ob);
	
	 
	System.out.println("iterate all elements");
	   for (int element : ob) {
		    System.out.println(element);
		    }
}
	

}

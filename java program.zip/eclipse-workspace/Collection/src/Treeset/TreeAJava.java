package Treeset;
import java.util.TreeSet;

public class TreeAJava {

	public static void main(String[] args) {
		 
		TreeSet<String> ob = new TreeSet<String>();
		  ob.add("Red");
		  ob.add("Green");
		  ob.add("Orange");
		  ob.add("White");
		  ob.add("Black");
		  System.out.println("Tree set: ");
		  System.out.println(ob);
		 }
	}



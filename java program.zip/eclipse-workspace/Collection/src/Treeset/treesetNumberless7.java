package Treeset;
import java.util.*;

 
public class treesetNumberless7 {

	public static void main(String[] args) {
		
		
		 TreeSet <Integer>ob = new TreeSet<Integer>();
		   TreeSet <Integer>ob1 = new TreeSet<Integer>();
		     
		  
		   ob.add(1);
		   ob.add(2);
		   ob.add(3);
		   ob.add(5);
		   ob.add(6);
		   ob.add(7);
		   ob.add(8);
		   ob.add(9);
		   ob.add(10);
		  
		   
		   System.out.println(ob);
		   
		   ob1=(TreeSet)ob.headSet(7);
		   
		  
		  Iterator iterator= ob1.iterator();
		     
		  
		   System.out.println("Tree set data: ");     
		   while (iterator.hasNext()){
		   System.out.println(iterator.next() + " ");
		   }
		   }    
		   


}

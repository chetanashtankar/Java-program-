package Treeset;

import java.util.TreeSet;

public class CloneTreeset {

	public static void main(String[] args) {
		TreeSet<Integer> ob=new TreeSet<Integer>();
	 	ob.add(88);
	ob.add(65);
	ob.add(64);
	ob.add(99);
	ob.add(85);
	ob.add(87);
	
	System.out.println("  Treeset="+ob);
	
	TreeSet<Integer> ob1=new TreeSet<Integer>();
	
	ob1=(TreeSet)ob.clone();
	System.out.println("clone a tree set list to another tree set.");
	
	System.out.println(ob1);
	
	}

}

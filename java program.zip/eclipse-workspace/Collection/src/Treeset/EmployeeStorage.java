package Treeset;
import java.util.*;
public class EmployeeStorage {

	public static void main(String[] args) {
 
		
TreeSet<EmployeePojo> ob = new TreeSet ();

ob.add(new EmployeePojo(141, "Nehal", "nagpur"));
ob.add(new EmployeePojo(134, "Chetan", "pune"));
ob.add(new EmployeePojo(145, "prakash", "solapur"));

 
  System.out.println(ob  );

 
 
 
	}
	

}
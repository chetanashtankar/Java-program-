import java.io.File;

public class CreateTwoFile1 {

	public static void main(String[] args) {

		try {

			File ob= new File("D:firstFile.txt");
			
			File ob1= new File("D:SecondFile.txt");
			
			if(ob.createNewFile())
			{
				
				System.out.println(" 2 file is creates Successfully");
				
				
			}
			
			else {
				
				System.out.println("file is not created");
			}
		}
			catch (Exception e) {
				 System.out.println(e);
			}
	}

}

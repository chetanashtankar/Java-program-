import java.io.File;
import java.io.FileWriter;
public class WeriteFile {

	public static void main(String[] args) {


		try {
			
			FileWriter f1= new FileWriter("D:Demo1.txt");
			
			f1.write("java  & python is very  good , programming language !!");
          f1.close();
          
          System.out.println("content added");
		
		}catch (Exception e) {
			System.out.println(e);		}
	}

}

import java.io.File;
import java.util.Scanner;

public class twofileRead {

	public static void main(String[] args) {
		 
		
		String data="";
		String data1="";
		try {
			File f=new File("D:firstFile.txt");
			File s=new File("D:SecondFile.txt");
			
			Scanner sc=new Scanner(f);
			Scanner ob=new Scanner(s);
			
			while(sc.hasNextLine()&& sc.hasNextLine())
			{
				String d=sc.nextLine();
				String l=ob.nextLine();
				System.out.println("1st file data :");
				System.out.println(d);
				System.out.println();
				System.out.println("2nd  file data");
				System.out.println(l);
				System.out.println();
			
				String first[]=d.split(" ");
				String second[]=l.split(" ");
				
				System.out.println("common two files data :");
			
				for (int i = 0; i < first.length; i++) {
					
					for (int j = 0; j < second.length; j++) {
						
						
							
							if (first[i].equals(second[j]))
									{
								      System.out.print(first[i]+"  ");
									}
						
						
					}
					
				}
				
				
				
			}
			
		}
		catch (Exception e) {
		System.out.println(e);	 
		
		}
	}

}

import java.io.File;
import java.util.Scanner;

public class readfilemenu {

	public static void main(String[] args) {

		String data="";
		try {
			
			
			
			File fw= new File("D:Demo1.txt");
			
			Scanner sc= new Scanner(fw);
			
			while(sc.hasNextLine())
			{
				data = sc.nextLine();
				
				System.out.println(data);
			}
			sc.close();
			
			System.out.println(data.length());
		}
		catch (Exception e) {
		System.out.println(e);	 
		
		}
	}

}

import java.io.File;
public class creatingFile {

	public static void main(String[] args) {

		try {

		File ob= new File("D:first1.txt");
		
		if(ob.createNewFile())
		{
			
			System.out.println("file is creates Successfully");
			
			
		}
		
		else {
			
			System.out.println("file is not created");
		}
	}
		catch (Exception e) {
			 System.out.println(e);
		}

	}
}

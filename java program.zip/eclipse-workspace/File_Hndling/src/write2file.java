import java.io.FileWriter;

public class write2file {

	public static void main(String[] args) {
try {
			
			FileWriter f1= new FileWriter("D:firstFile.txt");
			
			f1.write("nehal shubham kumar prakash ");
          f1.close();
          
          FileWriter f2= new FileWriter("D:SecondFile.txt");
      	f2.write("nehal shubham prakash dhiraj");
        f2.close();
        
          System.out.println("content added");
		
		}catch (Exception e) {
			System.out.println(e);		}
	

	}

}

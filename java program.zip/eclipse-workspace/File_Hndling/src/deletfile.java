import java.io.File;
public class deletfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try {
			
			
			File fw= new File("D:first.txt");
			
			if(fw.delete())
			{
				System.out.println("file deleted");
			}else {
					
					System.out.println("not deleted");
					
				}
			}catch (Exception e) {
			System.out.println(e);	 
			
			}
		}
	

}

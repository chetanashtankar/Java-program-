import java.io.File;

public class deleteFile {

	public static void main(String[] args) {
	
		try {
			
			File fw= new File("D:Demo1.txt");
			
			
			if(fw.delete())
			{
				System.out.println("file deleted ");
			}
			
			
			else {
				
				System.out.println("not deleted");
			}
		}
		catch (Exception e) {
			System.out.println(e);		}
	}

}

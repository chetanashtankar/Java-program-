import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
/*
 * Q.You are given two text files, file1.txt and file2.txt, both of which contain a list of names.
 *  Your task is to find names that are common to both files and write them to a new file called 
 *  common_names.txt.
 */
public class createTwoFile {

	public static void main(String[] args) {
  Scanner sc= new Scanner(System.in);
  	try {

			File ob= new File("D:file3.txt");
			
			File ob1= new File("D:file4.txt");
			
			if(ob.createNewFile())
			{
				
				System.out.println(" 2 file is creates Successfully");
				
				
			}
			
			else {
				
				System.out.println("file is not created");
			}
			
			
			
  FileWriter f1= new FileWriter("D:file3.txt");
  System.out.println("first file names");
			String s=sc.nextLine();
			f1.write(s);
          f1.close();
          
          
          FileWriter f2= new FileWriter("D:file4.txt");
          System.out.println("second file names");
			String s1=sc.nextLine();
		
			f2.write(s1);
         
          System.out.println("content added");
          
          
         
          
      	
			File fw= new File("D:file3.txt");
			
			String data="";
			  
				
			while(sc.hasNextLine())
			{
				data = sc.nextLine();
				
				System.out.println(data);
			}
			sc.close();
			
			File fw1= new File("D:file4.txt");
			
			String data1="";
			while(sc.hasNextLine())
			{
				data = sc.nextLine();
				
				System.out.println(data1);
			}
			sc.close();
			
			
			
		
		}
			catch (Exception e) {
				 System.out.println(e);
			}

	}

}

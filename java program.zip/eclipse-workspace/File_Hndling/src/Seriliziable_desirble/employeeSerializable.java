package Seriliziable_desirble;
import java.io.Serializable;
public class employeeSerializable implements Serializable {
	
	private int id;
	private String name;
	private int salary;
	private String city;
	
	
	
	

	public void setId(int id) {
		this.id = id;
	}





	public void setName(String name) {
		this.name = name;
	}





	public void setSalary(int salary) {
		this.salary = salary;
	}





	public void setCity(String city) {
		this.city = city;
	}





	public static void main(String[] args) {


	}

}

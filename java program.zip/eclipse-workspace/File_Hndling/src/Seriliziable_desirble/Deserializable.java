package Seriliziable_desirble;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deserializable {

	public static void main(String[] args) {

String file="D:\\encrypted.txt";
		
		try 
		{
			FileInputStream fi=new FileInputStream(file);
			ObjectInputStream oi=new ObjectInputStream(fi);
			
			employeeSerializable ob1= (employeeSerializable)oi.readObject();
			
			
			System.out.println(ob1.getId+"\t"+ob1.getname()+"\t"+ob1.getSalary()+"\t"+ob1.getCity());
			
		} 
		catch (Exception e) 
		{
			System.out.println(e);
		}

	}

}

package Seriliziable_desirble;

import java.io.File;

public class menuProgramcreatefile {

	public static void main(String[] args) {

		try {

		File ob= new File("D:Demo1.txt");
		
		if(ob.createNewFile())
		{
			
			System.out.println("file is creates Successfully");
			
			
		}
		
		else {
			
			System.out.println("file is not created");
		}
	}
		catch (Exception e) {
			 System.out.println(e);
		}

	}

}

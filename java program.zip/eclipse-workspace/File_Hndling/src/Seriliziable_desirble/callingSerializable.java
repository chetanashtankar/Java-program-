package Seriliziable_desirble;

import java.io.*;
public class callingSerializable {

	public static void main(String[] args) {

		employeeSerializable ob = new employeeSerializable();
		
		ob.setId(123);
		ob.setName("ABC");
		
		ob.setSalary(12000);
		
		ob.setCity("mumbai");
		
		String file="D:\\encrypted.txt";
		try
		{
		
		FileOutputStream fo=new FileOutputStream(file);
		ObjectOutputStream ou=new ObjectOutputStream(fo);
		ou.writeObject(ob);
		
		fo.close();
		ou.close();
		
		
		System.out.println("object of employee class is saved successfully into bytestream");
		
		
		}
		catch(Exception e)
		{
			
			System.out.println(e); 
		}
		
		
		
	}

}

/*
 * 
3. Write a Java program to create a method that reads a file and throws an exception if the file is not found.


 */

import java.io.File;
import java.util.Scanner;

public class readfileAssgn {

	public static void main(String[] args) {
		String data="";
		try {
			
			
			
			File fw= new File("D:Abcs.txt");
			
			Scanner sc= new Scanner(fw);
			
			while(sc.hasNextLine())
			{
				data = sc.nextLine();
				
				System.out.println(data);
			}
			sc.close();
			
				}
		catch (Exception e)
		{
			
		System.out.println(e);	
		System.out.println("file not found");
		
		}
	}
	

}

/*
 * Q1.You have been given a task to analyze a text file using Java file handling. 
 * Your goal is to determine the frequency of each character present in the file.
 *  Write a Java program that reads the content of a specified text file and calculates
 *   the frequency of each character (including letters, digits, 
 *   punctuation, and whitespace).
 *    Implement this program using file handling concepts in Java.

Your program should be able to answer the following questions:

1.How many times does each character appear in the file?
2.Which character appears the most frequently?
3.Are there any characters that do not appear in the file?
 */
import java.io.File;
import java.util.Scanner;

public class FreqUsingFilehaNdling {

	public static void main(String[] args)
	{

String s="";

try {
		File fw= new File("D:first1.txt");
		
       Scanner sc= new Scanner(fw);
       
       while(sc.hasNextLine())
		{
			s = sc.nextLine();
			
			System.out.println(s);
		}
		sc.close();
		
		System.out.println("length of String="+s.length());
		 
		 	char a[]=s.toCharArray();
		int p[]=new int[s.length()];
		int ind=-1;
		for (int i = 0; i < a.length; i++) {
			int count=1;
			for (int j = i+1; j < a.length; j++) {
				if(a[i]==a[j]) {
					count++;
					p[j]=ind;
				}
			}
			if(p[i]!=ind) {
				p[i]=count;
			}
		}
		System.out.println("frequence is");
  for (int i = 0; i < p.length; i++) {
		if(p[i]!=ind)
		{
			System.out.println(a[i]+"           "+p[i]);
		}
	}
 
	}
	catch (Exception e) {
	System.out.println(e);	 
	
	} 
		
		
		

	}

}

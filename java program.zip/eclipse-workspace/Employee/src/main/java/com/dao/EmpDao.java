package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.bo.Emp;

public class EmpDao {

public static Connection getConnection() {
		
		Connection con=null;
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
		    con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/april", "root", "12345678");			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return con;
}
  public static int addEmp(Emp e1) {
	
	  int status=0;
	
	  
	  try {
		
		  Connection con = EmpDao.getConnection();
		  String sql="insert into signup1(name,email,phone) values(?,?,?)";
		  PreparedStatement ps=con.prepareStatement(sql);
		  ps.setString(1, e1.getName());
		  ps.setString(2, e1.getEmail());
		  ps.setString(3, e1.getPhn());
		  
		  status= ps.executeUpdate();
		  
		  
	} catch (Exception e) {
		e.printStackTrace();
	}
	  
	
	  return status;
}
}






package noreturnwith_argument;
import java.util.Scanner;
public class printName {

	Scanner sc=new Scanner(System.in);
	String fname ,lname;
	public void display(String fname ,String lname)
	{
		System.out.println(fname+" "+lname);
	}
public static void main(String[] args) {
	printName P=new printName ();
	System.out.println("Enter a first and last name");
	Scanner sc=new Scanner (System.in);
	String fname=sc.nextLine();
	String lname=sc.nextLine();
	P.display(fname, lname);
	
}	

}


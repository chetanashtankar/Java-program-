package noreturnwith_argument;

import java.util.Scanner;

/* Q2.Create a method called calculateAverage that takes an array of integers as an argument and calculates
the average of those numbers. Print the result.*/
public class avgofelement
{
Scanner sc= new Scanner(System.in);
	
	int i,j,sum=0,avg=0;
	public void input(int a[],int size)
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
	}
	
	  public void disp(int a[],int size)
	  {
		  for(i=0;i<a.length;i++)
		  {
			  sum=sum+a[i];
			  avg=sum/5;
		  }
		  System.out.println("avg of array="+avg);
	  }
    
	  public static void main(String[]args)
		{
		  avgofelement ob= new avgofelement();
			Scanner sc= new Scanner(System.in);
			System.out.println("enter the size of an array");
			int size=sc.nextInt();
			int arr[]=new int[size];
			ob.input(arr, size);
			ob.disp(arr,size);
		}
}

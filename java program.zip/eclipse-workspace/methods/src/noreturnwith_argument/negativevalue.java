/*
 * Write a Java program to rearrange the elements of an integer array in such a way that all positive 
 * numbers appear before the negative numbers. The relative order of positive and negative numbers should 
 * be maintained. The modified array should have all positive numbers followed by all negative numbers. 
 * If the array contains zero or has only one element, no rearrangement is required.
 */

package noreturnwith_argument;
import java.util.Scanner;
public class negativevalue
{
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		
		 System.out.println("enter the size");
		 int size=sc.nextInt();
		 int a[]=new int[size];
		 int n=a.length;
		 System.out.println("enter array elements");
		 for(int i=0;i<a.length;i++)
		 {
			a[i]=sc.nextInt();
		 }
		
		
		 
		 System.out.println("orignal array ");
		 
		 for(int i=0;i<a.length;i++)
		 {
			 System.out.println(a[i]);
		 }
		 
		 for(int i=0;i<n;i++)
		 {
			 if(a[i]<0)
			 {
				 for(int j=i;j<n-1;j++)
				 {
					 int temp=a[j];
					 a[j]=a[j+1];
					 a[j+1]=temp;
				 }
				 n--;
				 i--;
				 
			 }
		 }
		 System.out.println("positive number before negative");
			
		 for(int i=0;i<a.length;i++)
		 {
			 System.out.println(a[i]);
		 }
		 
		 
	}

}

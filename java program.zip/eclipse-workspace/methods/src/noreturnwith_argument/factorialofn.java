package noreturnwith_argument;
/*
 * Q1.Create a method called calculateFactorial that takes an integer argument n and calculates the factorial of that number. Print the result.

 */
import java.util.Scanner;

public class factorialofn
{
	Scanner sc=new Scanner(System.in);
	int i,j;
	
	public void disp( int n)
	{
		System.out.println("factorial of number");
		int fact=1;
		for(i=1;i<=n;i++)
		{
			fact = fact*i;
		}
		System.out.println(fact);
		
	}
	
	public static void main(String[]args)
	{
		factorialofn ob=new factorialofn();
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
	    ob.disp( n);

	}

}

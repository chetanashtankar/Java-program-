package noreturnwith_argument;
import java.util.Scanner;
/*
 * 3.create a method called printEvenNumbers that takes an integer argument limit and prints all even numbers 
 * from 1 to the specified limit.

 */
public class printEvennumb
{
	
Scanner sc= new Scanner(System.in);
	
	int i,n ;
	/*public void input(int i,int n)
	{
		 n=sc.nextInt();
	}*/
	
	public void disp( int n)
	{
		System.out.println("all even numbers ");
		
		for(i=1;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
		
	}
	
	public static void main(String[]args)
	{
		printEvennumb ob=new printEvennumb();
		System.out.println("Enter a number");
		Scanner sc=new Scanner (System.in);
		int n=sc.nextInt();
	    ob.disp( n);

	}
}

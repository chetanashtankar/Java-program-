package noreturnwith_argument;
import java.util.Scanner;

public class noreturnarg {

	Scanner sc= new Scanner(System.in);
	
	int i,j;
	public void input(int a[],int size)
	{
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
	}
	
	public void disp(int a[],int size)
	{
		System.out.println("array elements are");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
			
		}
	}
	
	public static void main(String[]args)
	{
		noreturnarg ob= new noreturnarg();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the size of an array");
		int size=sc.nextInt();
		int arr[]=new int[size];
		ob.input(arr, size);
		ob.disp(arr, size);
	}
}

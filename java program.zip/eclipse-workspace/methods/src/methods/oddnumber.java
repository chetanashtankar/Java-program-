package methods;
import java.util.Scanner;
public class oddnumber {

	Scanner sc=new Scanner(System.in);
		
	int f,l;
	
	    
	    public void input()
	    {
	    	System.out.println("enter first and last element");
	    	 f=sc.nextInt();
	         l=sc.nextInt();  	     
	    	
	}
	    
	   public void odd()
	   { 
		  int sum=0,c=0;
		   for(int i=f;i<=l;i++)
		   {
			   
				   if(f%2!=0)
				   {
					   System.out.println(f);
					   c++;
					   sum=sum+f;
				   }
			    f++;
		   }
		   System.out.println("sum of odd numbers="+sum);
		   System.out.println("count of odd number="+c);
		 
	   }
	   
	   
	   public static void main(String[]args)
	   {
		   oddnumber ob=new oddnumber();
		   ob.input();
		   ob.odd();
	   }
}

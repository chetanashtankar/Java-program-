package methods;
//11:Write a Java method that calculates and returns the average of elements in a given array of integers.
import java.util.Scanner;

public class returnavg 
{
	Scanner sc=new Scanner(System.in);
	int a[];
	int size;
	 public void input()
	   {
		   System.out.println("enter size");
		   int size=sc.nextInt();
		   a=new int[size];
		   System.out.println("enter the elements");
		   for(int i=0;i<a.length;i++)
		   {
		   a[i]=sc.nextInt();
		   }   
	   }
	 
	 public float avg()
	 {   int Sum=0,avg=0;
		 for(int i=0;i<a.length;i++)
		 {
			 Sum=Sum+a[i];
			 avg=Sum/5;
		 }
		 
		 
		return avg;
		 
	 }
	 
	 public static void main(String[]args)
	 {
		 returnavg obj= new returnavg();
		 obj.input();
		 
		  System.out.println("evg of element");
		  System.out.println(obj.avg());
			
			
	 }

}

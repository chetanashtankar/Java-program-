package methods;
import java.util.Scanner;
 
public class FreqofArray 
{
	//2) Java Program to find the frequency of each element in the array.

	
	public static void main(String[]args)
	{
		FreqofArray ob= new FreqofArray();
		ob.fre();
		
	}
	public void fre()
	{
		int a[]={1,2,3,4,5,2,1,4};
		
		int b[]=new int[a.length];

		System.out.println("given elements...");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}

		
		for(int i=0;i<a.length;i++)
		{
			int count=1;
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					b[j]=-1;
					count++;
				}
			}
		  if(b[i]!=1)
			{
				b[i]=count;
			}
		}

	System.out.println();
	System.out.println("elements   count");
	System.out.println();
	for(int i=0;i<a.length;i++)
		{
			if(b[i]!=-1)
			{
				System.out.println(a[i]+"          "+b[i]);
			}
			
		}
	}
	}



package methods;

import java.util.Scanner;

public class armstrongseries 
{
Scanner sc=new Scanner(System.in);
	
    int f,l;
      
    int rev,rem,temp;
	public void input()
	{
	  	System.out.println("enter first and last number");
	  	
	    f=sc.nextInt();
	    l=sc.nextInt();
      int sum,rem;
       
      while(f<=l)
	    {
	    	sum=0;
	    	rem=0;
	    	int j=f;
	    	while(j!=0)
	    	{
	    		rem=j%10;
	    		sum=sum+(rem*rem*rem);
	    		j=j/10;
	    	}
	    	if(sum==f)
	    	{
	    		System.out.print(f+"  ");
	    	}
	    	f++;
	    }

}
	public static void main(String[]args)
	
	{
		
		armstrongseries obj=new armstrongseries();
		obj.input();
		
		
	}
}
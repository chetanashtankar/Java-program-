package methods;

import java.util.Scanner;

public class AScorder
{
Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	
    	
    	System.out.println("enter Array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
    	

}
    public void Asc()
    {
    	  for(i=0;i<a.length;i++)
   	   {
   		   for(j=i+1;j<a.length;j++)
   		   {
   			   if(a[i]>a[j])
   			   {
   				   temp=a[i];
   				   a[i]=a[j];
   				   a[j]=temp;
   			   }
   		   }
   	   }
    	  System.out.println("Array is Ascending order:-  ");
      	
    	 
    	  for(i=0;i<a.length;i++)
      	{
    		  System.out.print(a[i]+"  ");
    	      
      	}
      	
    }
    public static void main(String[]args)
    {
    	AScorder obj=new AScorder();
    	obj.input();
    	obj.Asc();
    }
}
package methods;

import java.util.Scanner;

public class palindromseries
{
	Scanner sc=new Scanner(System.in);
	
    int f,l;
      
    int rev,rem,temp;
	public void input()
	{
	  	System.out.println("enter first and last number");
	  	
	    f=sc.nextInt();
	    l=sc.nextInt();
	    
	    while(f<=l)
	    {
	    	temp=f;
	    	rev=0;
	    	while(temp!=0)
	    	{
	    		rem=temp%10;
	    		rev=rev*10+rem;
	    		temp=temp/10;
	    	}
	    	   	
	    	if(rev==f)
	    	{
	    		System.out.print(f+" ");
	    	}
	    	f++;
	    }
	}
	
	
	public static void main(String[]args)
	{
		palindromseries obj=new palindromseries();
		obj.input();
	}
}

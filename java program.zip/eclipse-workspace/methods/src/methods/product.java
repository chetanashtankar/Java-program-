package methods;
//1.Write a Java program to find maximum product of two integers in a given array of integers. 

public class product 
{
   public void proct()
   {
	  int a[]= {1,2,3,4,5,6,7};
	  int b[]=new int[a.length];
	  int total=1;
	  
	  for(int i=0;i<a.length;i++)
	  {
		  total=total*a[i];
	  }
	  System.out.println("total="+total);

	  for(int i=0;i<a.length;i++)
	  {
		  b[i]=(total/a[i]);
	  }
	  
	  for(int i=0;i<b.length;i++)
	  {
		  System.out.print(b[i]+" ");
	  }
	}
   public static void main(String[]args)
   {
	   product obj= new product();
	   obj.proct();
   }
   
}

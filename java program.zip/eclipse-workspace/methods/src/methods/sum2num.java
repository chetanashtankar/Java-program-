package methods;
import java.util.Scanner;
//1:Write a Java method that returns the sum of two numbers entered by the user.

public class sum2num
{
	Scanner sc=new Scanner(System.in);
	int n1,n2,sum;
	public void input()
	{
		System.out.println("enter two numbers");
		n1=sc.nextInt();
	    n2=sc.nextInt();
	    
	}
	
	public int sumnumber()
	{
		
		sum=n1+n2;
		
		return sum;
		
	}
	
	public static void main(String[]args)
	{
		

		sum2num obj=new sum2num();
		obj.input();
		System.out.println("sum of two number");
		System.out.println(obj.sumnumber());
	}

}

package methods;
import java.util.Scanner;
public class noretrntype 
{
	Scanner sc=new Scanner(System.in);
	int size,i,max=0;
	int a[];
   public void input()
   {
	   System.out.println("enter size");
	   size=sc.nextInt();
	   int a[]=new int[size];
	   
	   
   }
}

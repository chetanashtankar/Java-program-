package methods;
import java.util.*;
public class leftright
{
	
		
		public void name() {
			int a[]={ 1, 2, 4, 9, 5, 3, 8, 7, 10, 12, 14 };
			
		       for (int i = 1; i < a.length ; i += 2) {
		            int temp = a[i];
		            a[i] = a[i + 1];
		            a[i + 1] = temp;
		        }
			
			System.out.println(Arrays.toString(a));
		}
	public static void main(String[] args) {
		leftright ob=new leftright();
		ob.name();
	}
	}



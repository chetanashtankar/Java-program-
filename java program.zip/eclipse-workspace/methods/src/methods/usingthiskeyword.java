package methods;

public class usingthiskeyword 
{
	int id;
	String name;

	public void input(int id,String name)
	{
		this.id=id;
		this.name=name;
	  
	}

	public void disp()
	{
	  	this.input(17,"ND");
	  System.out.println(id+" "+name);

	}
	public void sum()
	{
		this.disp();
		System.out.println(id+name);
	}

	public static void main(String[]args)
	{
		usingthiskeyword ob= new usingthiskeyword();
	    ob.sum();
	}

}

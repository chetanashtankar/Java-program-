package methods;
import java.util.Scanner;
public class evennumbsum {
	 
		Scanner sc=new Scanner(System.in);
			
		int f,l;
		
		    
		    public void input()
		    {
		    	System.out.println("enter first and last element");
		    	 f=sc.nextInt();
		         l=sc.nextInt();  	     
		    	
		}
		    
		   public void even()
		   { 
			  int sum=0,c=0;
			   for(int i=f;i<=l;i++)
			   {
				   
					   if(f%2==0)
					   {
						   System.out.println(f);
						   c++;
						   sum=sum+f;
					   }
				    f++;
			   }
			   System.out.println("sum of even numbers="+sum);
			   System.out.println("count of even  number="+c);
			 
		   }
		   
		   
		   public static void main(String[]args)
		   {
			   evennumbsum ob=new evennumbsum();
			   ob.input();
			   ob.even();
		   }
	}




package methods;
//Q14.Wap enter an array and search any particular element and found the count of that.

import java.util.Scanner;
public class searchArrayelement
{
	Scanner sc=new Scanner(System.in);
	
    int size,i,n;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	System.out.println("enter array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
    }
     public void search()
     {
    	 int count=0;
    	 System.out.println("enter a number you want to search");
    	 n=sc.nextInt();
    	 
    	 for(i=0;i<a.length;i++)
    	 {
    		 if(a[i]==n)
    		 {
    			 count++;
    		 }
    		 
    	 }
    	 System.out.println("number is found");
         
    	 System.out.println("count number is : "+count);
     	
     }
     
     public static void main(String[]args)
     {
    	
    	 searchArrayelement obj= new searchArrayelement();
    	 obj.input();
    	 obj.search();
    	
     }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
}

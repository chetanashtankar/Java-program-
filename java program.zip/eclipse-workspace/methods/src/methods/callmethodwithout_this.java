package methods;

public class callmethodwithout_this {
int id;
String name;

public void input(int id,String name)
{
	this.id=id;
	this.name=name;
  
}

public void disp()
{
  	input(17,"ND");
  System.out.println(id+" "+name);

}
public void sum()
{
	disp();
	System.out.println(id+name);
}

public static void main(String[]args)
{
	callmethodwithout_this ob= new callmethodwithout_this();
    ob.sum();
}
	
}

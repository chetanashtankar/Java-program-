
	package methods;
	//Q4. Wap enter an array and find the second min element.

	import java.util.Scanner;

	public class Sec_min 
	{
	Scanner sc=new Scanner(System.in);
		
	    int size,i,j,temp=0;
	    int a[];
	    public void input()
	    {
	    	System.out.println("enter array size");
	    	size=sc.nextInt();
	    	a=new int[size];
	    	
	    	
	    	System.out.println("enter Array element");
	        
	    	for(i=0;i<a.length;i++)
	    	{
	    		a[i]=sc.nextInt();
	    	}
	}
	    public void min()
	    {
	    	 int temp=0;
	         for(int i=0;i<a.length;i++)
	        {
	          for(int j=i+1;j<a.length;j++)
	            {
	              if(a[i]>a[j])
	              {
	            	  temp=a[i];
	            	  a[i]=a[j];
	            	  a[j]=temp;
	              }
	        	  
	              }

	          }  
	         System.out.println("min number is="+a[0]);
	         System.out.println("second min number is="+a[1]);
	         

	       }
	         
	        
	    
	    public static void main(String[]args)
	    {
	    	Sec_min  obj=new Sec_min();
	    	obj.input();
	    	obj.min();
	    }

	}




package methods;
//3:Write a Java method that calculates and returns the factorial of a given number.
import java.util.Scanner;

public class returnfact
{
	Scanner sc=new Scanner(System.in);
	
	int n;
	
	public void input()
	{
		System.out.println("enter a number");
		n=sc.nextInt();
		
		
	}
	public int display()
	{
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		return fact;
		
	}
	public static void main(String[]args)
	{
		returnfact obj=new returnfact();
		obj.input();
		
		System.out.println("factorial is :-");
		System.out.println(obj.display());
		
	}

}

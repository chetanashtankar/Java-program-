package methods;

import java.util.Scanner;

public class prime_series 
{
Scanner sc=new Scanner(System.in);
	
    int f,l;
      
    int rev,rem,temp;
	public void input()
	{
	  	System.out.println("enter first and last number");
	  	  	
	    f=sc.nextInt();
	    l=sc.nextInt();
		System.out.println("prime number series");
		
	     for(int i=f;f<=l;f++)
	    {  
	    	 int c=0;
	   	  
	    	for(int j=2;j<f;j++)
	    	{
	    		if(f%j==0)
	    		{
	    			c++;
	    			break;
	    		}
	    	}
	    		 if(c==0 && f!=1)
	    			{
	    				System.out.print(f+ "  ");
	    				
	    			}
	    	
	    	
	    }
	   
	}
	
	public static void main(String[]args)
	{
		prime_series obj= new prime_series();
		obj.input();
	}

}

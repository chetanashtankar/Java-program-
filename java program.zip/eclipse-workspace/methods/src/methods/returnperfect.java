package methods;
//15:Write a Java method that checks and returns whether a given number is a perfect square or not.

public class returnperfect {

}

//Q6.Wap enter an array and find the duplicate element and also count of that.

package methods;
import java.util.Scanner;
public class duplicate_element
{
	Scanner sc=new Scanner(System.in); 
	
int a[];
 
  public void input()
  {
	    a=new int[5];
	  System.out.println("enter array element");
	  for(int i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
		  
	  }
	  
	  }
  public void duplicate()
  {
	  int c=0;
	  System.out.println("duplicate  array element");
		
  
  
	  for(int i=0;i<a.length;i++)
	  {
		  for(int j=i+1;j<a.length;j++)
		  {
		  if(a[i]==a[j])
		  {
			  c++;
			  System.out.println(a[i]);
		  }
	  }
  }
	System.out.println("count of duplicate array element="+c);  

  }
  public static void main(String[]args)
  {
	  duplicate_element obj=new duplicate_element();
	  obj.input();
	  obj.duplicate();
  }
  }

package methods;
//4:Write a Java method that determines and returns whether a given number is prime or not.

import java.util.Scanner;

public class returnprime {
	
	Scanner sc=new Scanner(System.in);
	int n;
	int f=n;
	public void input()
	{
		System.out.println("enter the number");
		n=sc.nextInt();
		
	}
   
	 public int prime()
	 {
		 int  c=0;
		for(int i=2;i<n;i++)
		{
		 if(n%i==0)
		 {
			 c++;
			 
			 }
		 }if(c==0)
		 {
			 System.out.println("prime");
			 
		 }
		 return n;
		
	 }
	 public static void main(String[]args)
	 {
		 returnprime obj= new returnprime();
		 obj.input();
		 System.out.println("number is prime");
		 System.out.println( obj.prime());
			
	 }
}

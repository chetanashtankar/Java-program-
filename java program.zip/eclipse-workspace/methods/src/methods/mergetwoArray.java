package methods;
/*
 
Q3.a[]={10,20,30,40,50}
   b[]={1,2,3,4,5}
 
  output array=c[]={10,5,20,4,30,3,40,2,50,1}
*/


import java.util.Scanner;

public class mergetwoArray 
{
	Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[],b[],c[],p;
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	b=new int[size];
    	c=new int[a.length+b.length];
    	p=b.length-1;
    	
    	
    	System.out.println("enter 1st Array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
    System.out.println("enter 2nd Array element");
        
    	for(i=0;i<b.length;i++)
    	{
    		b[i]=sc.nextInt();
    	}
    	
    	
    }
    
    public void mergetwo()
    {
    	int h=0;
    	System.out.println("two array merge");
    	for(i=0;i<a.length;i++)
    	{
    		c[h]=a[i];
    		h++;
    		c[h]=b[p];
    		h++;
    		p--;
    		
    	}
    	
    	for(i=0;i<c.length;i++)
    	{
    		System.out.print(c[i]+"  ");
    	}
    	
      	
    }
    
    public static void main(String[]args)
    {
    	mergetwoArray obj=new mergetwoArray();
    	obj.input();
    	obj.mergetwo();
    	
    }

}






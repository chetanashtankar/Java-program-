package methods;
//9:Write a Java method that determines and returns the maximum element from an array of integers.
import java.util.Scanner;

public class returnmax
{
   Scanner sc=new Scanner(System.in);
   int a[];
   int size;
   int max;
   public void input()
   {
	   System.out.println("enter size");
	   int size=sc.nextInt();
	   a=new int[size];
	   System.out.println("enter the elements");
	   for(int i=0;i<a.length;i++)
	   {
	   a[i]=sc.nextInt();
	   }   
   }
  public int maxele()
  {
	  for(int i=0;i<a.length;i++)
	  {
		  if(a[i]>max)
		  {
			  max=a[i];
		  }
	  }
	    System.out.println("max number:-"+max);
	return max;
  }
  
  public static void main(String[]args)
  {
	  returnmax max=new returnmax();
	  
	  max.input();
	 
	  System.out.println(max.maxele());
		
	  
	  
	  
	  
	  
  }
}


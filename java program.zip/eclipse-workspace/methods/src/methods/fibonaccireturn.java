package methods;

import java.util.Scanner;
public class fibonaccireturn
{
	 int n;
	 int n1=0,n2=1,n3,i;    
		
	Scanner sc= new Scanner(System.in);
	public void input()
	{
		System.out.println("enter number");
		n=sc.nextInt();
		
	}
	 public int fibonacci()
	 {
		 
	 
	 System.out.print(n1+" "+n2);  
	    
	 for(i=2;i<n;++i)//loop starts from 2 because 0 and 1 are already printed    
	 {    
	  n3=n1+n2;    
	  System.out.print(" "+n3);    
	  n1=n2;    
	  n2=n3;    
	 }
	return i;  
	
	  
	}
	 public static void main(String[]args)
	 {
		 fibonaccireturn obj= new fibonaccireturn();
		 obj.input();
		 obj.fibonacci();
	 }
	 }  


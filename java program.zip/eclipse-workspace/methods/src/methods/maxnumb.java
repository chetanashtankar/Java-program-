package methods;
import java.util.Scanner;

public class maxnumb
{
	 Scanner sc= new Scanner(System.in);
	 int a[];
	 int size,i,j;
	 
	 public void input()
	    {
	    	System.out.println("enter array size");
	    	size=sc.nextInt();
	    	a=new int[size];
	    	
	    	
	    	System.out.println("enter Array element");
	        
	    	for(i=0;i<a.length;i++)
	    	{
	    		a[i]=sc.nextInt();
	    	}
	}
	 
	 public void min()
	 {
		 int min=a[0];
		 for(i=0;i<a.length;i++)
		 {
			 for(j=i+1;j<a.length;j++)
			 {
				 if(min > a[i])
				 {
					 min=a[i];
				 }
			 }
		 }

	     System.out.println("min number in array="+min);
	     
	 }
	 public static void main(String[]args)
	 {
		 maxnumb ob= new maxnumb();
		 ob.input();
		 ob.min();
	 }
	 

}

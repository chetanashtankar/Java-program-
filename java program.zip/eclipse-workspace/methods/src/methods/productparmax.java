package methods;

public class productparmax

{/*
	 * Original array: [1, 2, 3, 4, 7, 0, 8, 4]
	Maximum product pair is: (7, 8)
	Original array: [0, -1, -2, -4, 5, 0, -6]
	Maximum product pair is: (-4, -6)
	Click me to see the sample solution
	 */
 

	 
		int i,j;
		int a[]= {1, 2, 3, 4, 7, 0, 8, 4};
		public int max(int a[])
		{
			
			 
			System.out.println("Original Array");
			for(i=0;i<a.length;i++)
			{
				System.out.println(a[i]);
			}
			int x=a[0];
			int y=a[1];
			
			for(i=0;i<a.length;i++)
			{
				for(j=i+1;j<a.length;j++)
				{
					if(a[i]*a[j]>x*y)
					{
						x=a[i];
						y=a[i];
					}
				}
			}
			
			System.out.println("max product"+x+" "+y);
			return 0;
			
		}
 

	 	public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			int a[]= {1, 2, 3, 4, 7, 0, 8, 4};
			productparmax o= new productparmax();
			o.max(a);
		}

	}
	



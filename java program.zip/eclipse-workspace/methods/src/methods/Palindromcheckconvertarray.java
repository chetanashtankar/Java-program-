package methods;
import java.util.Scanner;
//wajp to check number is palindrome if it is palindrome the
public class Palindromcheckconvertarray
{
	int n;
	int f;
  Scanner sc=new Scanner(System.in);
  int rem,rev=0;
   public void input()
  {
	   System.out.println("enter number");
	   
     	n=sc.nextInt();
     	 f=n;
  }
   public void check()
   {
	   while(n!=0)
	   {
		   rem=n%10;
		   rev=rev*10+rem;
		   n=n/10;
	   }
	    if(rev==f)
	    {
	    	System.out.println("number is palindrome");
	    }
   }
  
   public static void main(String[]args)
   {
	   Palindromcheckconvertarray obj=new Palindromcheckconvertarray();
	   obj.input();
	   obj.check();
   }
}

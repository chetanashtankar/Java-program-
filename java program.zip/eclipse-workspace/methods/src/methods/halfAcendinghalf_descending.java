package methods;

import java.util.Scanner;
/*
  Q4.Wap sort half array in accending and half in decending order
    input= int [] a={9,1,3,5,6,11,22,66,10,19}.
    output={1,3,5,6,9,10,66,22,19,11,10},
 */

public class halfAcendinghalf_descending 
{

	Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	System.out.println("enter array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
    	
    }
       public void Ascdesc()
       {
    	   for(i=0;i<a.length/2;i++)
    	   {
    		   for(j=i+1;j<a.length;j++)
    		   {
    			   if(a[i]>a[j])
    			   {
    				   temp=a[i];
    				   a[i]=a[j];
    				   a[j]=temp;
    			   }
    		   }
    	   }
    	    
    	   for(i=a.length/2;i<a.length;i++)
    	   {
    		   for(j=i+1;j<a.length;j++)
    		   {
    			   if(a[i]<a[j])
    			   {
    				   temp=a[i];
    				   a[i]=a[j];
    				   a[j]=temp;
    			   }
    		   }
    	   }
    	   
    	   System.out.println("number is half descending and ascending");
    	   
    	   for(i=0;i<a.length;i++)
       	{
       		System.out.print(a[i]+"  ");
       	}
    	   
    	  
       }
       
       
       
       
       
       
       
       public static void main(String[]args)
       {
    	   halfAcendinghalf_descending obj=new halfAcendinghalf_descending();
    	   obj.input();
    	   obj.Ascdesc();
       }
       
}
    
    



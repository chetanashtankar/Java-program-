package methods;

import java.util.Scanner;

public class oddsq {
	
Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	
    	
    	System.out.println("enter Array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
    	
    	
}
    public void odd()
    {
    	int sq=0;
    	System.out.println("odd  Array element");
        for(i=0;i<a.length;i=i+2)
        
        {
        	System.out.println(a[i]);
        	sq=a[i]*a[i];
        	System.out.println("square of element ="+sq);
        	   
        }
             
    }
    
    public static void main(String[]args)
    {
    	oddsq obj= new oddsq();
    	obj.input();
    	obj.odd();
    }
}

package methods;
//Q21.Write a program that takes in an array of integers and finds the second largest value in the array.
import java.util.Scanner;

public class secmax_
{
Scanner sc=new Scanner(System.in);
	
    int size,i,j,temp=0;
    int a[];
    public void input()
    {
    	System.out.println("enter array size");
    	size=sc.nextInt();
    	a=new int[size];
    	
    	
    	System.out.println("enter Array element");
        
    	for(i=0;i<a.length;i++)
    	{
    		a[i]=sc.nextInt();
    	}
}
    public void max()
    {
    	 int temp=0;
         for(int i=0;i<a.length;i++)
        {
          for(int j=i+1;j<a.length;j++)
            {
              if(a[i]<a[j])
              {
            	  temp=a[i];
            	  a[i]=a[j];
            	  a[j]=temp;
              }
        	  
              }

          }  
         System.out.println("max number is="+a[0]);
         System.out.println("second max number is="+a[1]);
         

       }
         
        
    
    public static void main(String[]args)
    {
    	secmax_ obj=new secmax_();
    	obj.input();
    	obj.max();
    }

}

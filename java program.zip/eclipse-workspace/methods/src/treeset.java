/*
 * Q. wap take 10 element in arrayList and find the frequency of each element.
 */

import java.util.ArrayList;
import java.util.Collections;

public class treeset {

	public static void main(String[] args) {


		ArrayList ob= new ArrayList();
		
		
		ob.add(1);
		ob.add(2);
		ob.add(3);
		ob.add(1);
		ob.add(7);
		ob.add(4);
		ob.add(4);
		ob.add(4);
		ob.add(17);
		ob.add(7);
		
		
		System.out.println("array list="+ob);
		
		 Object []a=ob.toArray();
		 int []b= new int [a.length];
		 
		 int c;
		 
		 for (int i = 0; i < a.length; i++) {
			
			 
			 c=1;
			 
			 for (int j = i+1; j < a.length; j++) {
				
				 
				 
				 if(a[i]==a[j])
				 {
					 b[j]=-1;
					c++;
					
				 }
			}
			 
			 
			 if(b[i]!=-1)
			 {
				 b[i]=c;
			 }
			 
		}
		 System.out.println("duplicate ="+"count");
		 
		 for (int i = 0; i < a.length; i++) {
			
			 
			 if(b[i]!=-1)
			 {
				 System.out.println(a[i]+" "+b[i]);
			 }
		}
		 
		 
		 
		 
		 
		
	}

}

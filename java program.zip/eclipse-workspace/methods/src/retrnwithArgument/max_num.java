package retrnwithArgument;
import java.util.Scanner;
/*
 *Create a method called findMax that takes an array of integers as
 * an argument and returns the largest number in the array.
 */
 class max_num 
{

	Scanner sc= new Scanner(System.in);
	int i,j,max;
	  protected int disp(int num[],int size)
	  {
		  for(int i=0;i<num.length;i++) {
		  if(num[i]>max)
		  {
			  max=num[i];
		  }
		  }
		  return max;
	  }
    
	  public static void main(String[]args)
		{
		  max_num obj= new max_num();
			Scanner sc= new Scanner(System.in);
			System.out.println("enter the size of an array");
			int size =sc.nextInt();
			int num[];
			System.out.println("enter the Elements");
			num=new int[size];
			for(int i=0;i<num.length;i++) {
				num[i]=sc.nextInt();
			}
			int k=obj.disp(num, size);
			System.out.println("max number");
			
			System.out.println(k);
		}
}
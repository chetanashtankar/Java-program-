package retrnwithArgument;
/*
 * Question 7:
Write a Java method that takes an array of integers as input and returns the number of occurrences 
of a given element in the array.

 */
import java.util.Scanner;

public class occursereturn 
{
	
	int i,j;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[],int size)
	{
		int count=0;
		System.out.println("enter the number for occurance");
		
		int n=sc.nextInt();
		System.out.println("number of occurance");
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==n)
			{
				
				count++;
			}
		}
		
		return count;
		
	}
		 
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		int i,j;
		for(  i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		occursereturn ob= new occursereturn();
		  
		 System.out.print(ob.intput(a, size));
			
			
	}


}

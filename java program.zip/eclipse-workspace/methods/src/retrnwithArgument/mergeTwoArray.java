package retrnwithArgument;
/*
 * Q9.Write a program that takes in two sorted arrays of integers and merges them into a single sorted array.

 */
import java.util.Scanner;
public class mergeTwoArray 
{

	int i;
	public void maxinput(int a[],int b[],int c[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a element ");
		for(i=0;i<a.length;i++)
		{
			 a[i]=sc.nextInt();
		}
		System.out.println("Enter a element b");
		for(i=0;i<b.length;i++)
		{
			 b[i]=sc.nextInt();
		}
		
		for(int i=0;i<a.length;i++)
		{
			c[i]=a[i];
		}
		
		for(int i=0;i<b.length;i++)
		{
			c[a.length+i]=b[i];
		}
		System.out.println("merge two array");
		
		for(int i=0;i<c.length;i++)
		{
			System.out.println(c[i]);
		}
	
	}
	
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a size");
		int size=sc.nextInt();
		int a[]=new int [size];
		int b[]=new int [size];
		int c[]=new int [a.length+b.length];
		mergeTwoArray ob= new mergeTwoArray();
		ob.maxinput(a, b, c);
	}
}

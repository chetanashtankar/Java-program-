package retrnwithArgument;

import java.util.Scanner;

/*
 * Question 5:
Write a Java method that takes an array of integers as input and returns a new array with only the even elements from the original array.

 */
public class returnEven 
{
	int i,j;
	 	Scanner sc= new Scanner(System.in);
	public int intput(int a[],int size)
	{
		
			for(i=0;i<a.length;i++)
		{
				System.out.println("min element in array");
				
			  if(a[i]%2==0)
			  {
				  System.out.println(a[i]);
			  }
			 
		}
			 
			
		   
		return i;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		int i,j;
		for(  i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		returnEven ob= new returnEven();
		  
		 System.out.println(ob.intput(a, size));
			
			
	}

}



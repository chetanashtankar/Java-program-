package retrnwithArgument;
import java.util.Scanner;
public class sumcountEven
{
	int i,j,d;
	
	Scanner sc= new Scanner(System.in);
	public int input(int a[])
	{
		
		System.out.println("array elemnt is");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		int sum=0;
		d=0;
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				sum=sum+a[i];
				d++;
			}
		}
		
		
		System.out.println("sum of odd number="+sum);
		System.out.println("count=");
		return d;
		
	}

	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		  int a[]= {1,2,3,4,5,6,7,8};
		
		sumcountEven ob= new sumcountEven();
	
		System.out.println(ob.input(a));
	}
	
}

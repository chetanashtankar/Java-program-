package retrnwithArgument;

import java.util.Scanner;

/*
 * Q10.Write a program that takes in an array of integers and returns a new array with all the odd numbers from the original array.

 */
public class oddreturnArray
{
	int a[];
	  int size,i,j;
    int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	  public int[] odd(int a[])
	  {
		  int c=0;
		  for(i=0;i<a.length;i++)
		   {
			  if(a[i]%2!=0)
			  {
				  c++;
			  }
		   }
		  int p[]=new int[c];
		  int m=0;
		  System.out.println("odd num");
		  
		  for(i=0;i<a.length;i++)
		   {
			  if(a[i]%2!=0)
			  {
				  p[m]=a[i];
				  m++;
			  }
		   }
		  
		return p;
		  
	  }
	  
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
		  System.out.println("enter size");
		  int size=sc.nextInt();
		  int a[]=new int[size];
		  oddreturnArray ob= new oddreturnArray();
		  ob.input(a);
		  int k[]=ob.odd(a);
		  for(int bb:k)
			{
				if(bb!=0)
				{
					System.out.println(bb);
				}
			}
		  
	  }

}

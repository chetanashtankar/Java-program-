package retrnwithArgument;
/*
 * Write a Java method that takes an array of integers as input and returns the sum of all the elements in the array.

 */
import java.util.Scanner;
public class returnsumele
{
	
	int i,j;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[])
	{
		
		System.out.println("sum array element");
		int sum=0;
		
	 
		for(i=0;i<a.length;i++)
		{
			sum=sum+a[i];
			 
		}
		
		return sum;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		returnsumele ob= new returnsumele();
		ob.intput(a);
		 int k=ob.intput(a);
		 System.out.println(k);
			
	}

}

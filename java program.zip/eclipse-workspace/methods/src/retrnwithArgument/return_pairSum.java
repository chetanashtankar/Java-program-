package retrnwithArgument;
/*Q28.Write a program that takes in an array of integers and returns the first pair of numbers that add up to a given sum.
*/
import java.util.Scanner;
public class return_pairSum
{
	int i,j;
	 
	 
	Scanner sc= new Scanner(System.in);
	public int[] input(int a[],int size)
	{
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the sum");
		int sum=sc.nextInt();
		int c=0;
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==sum)
				{
					System.out.println(a[i]+" "+a[j] +" ="+sum);
					c++;
				}
			}
		}
		
		int p[]=new int[c];
		int m=0;
		
		System.out.println("enter the sum");
	//	int sum1=sc.nextInt();
		 
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==sum)
				{
					 p[m]=a[i];
					 m++;
				}
			}
		}
		return p;
		
		 
	}
	  
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		 System.out.println("enter size");
		 int  size=sc.nextInt();
		 int a[]=new int[size];
		 return_pairSum ob= new return_pairSum();
		 int k[]=ob.input(a, size);
		 for(int pai : k)
		 {
			 if(pai!=0)
			 {
				 System.out.println(pai);
			 }
		 }
	}
}

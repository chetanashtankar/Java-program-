package retrnwithArgument;
import java.util.Scanner;
public class return_palindromseries_covArray 

{
	
	public int[]  palindrome(int f,int l)
	{
		int j=0;
		int rem=0;
		int a[]= new int[l];
		System.out.println("palindrome series convert in array");
		
		while(f<=l)
		{
			int temp=f;
			int rev=0;
			
			while(temp!=0)
			{
				rem=temp%10;
				rev= rev*10+rem;
				temp=temp/10;
				
			}
			
			if(rev==f)
			{
			//	System.out.println(f);
				a[j++]=f;
				
			}
			f++;
			
		}
		
		
		
		return a;
		
		
	}

	public static void main(String[]args)
	{
       Scanner sc= new Scanner(System.in);
       System.out.println("enter number");
       int f=sc.nextInt();
       int l=sc.nextInt();
       return_palindromseries_covArray ob= new return_palindromseries_covArray();
       int k[]=ob.palindrome(f, l);
       for(int cd : k)
       {
    	   if(cd!=0)
    	   {
    		   System.out.println(cd);
    	   }
    	   
       }
      
	}
}

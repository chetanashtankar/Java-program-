package retrnwithArgument;

import java.util.Scanner;

/*
 * .Write a program that takes in an array of integers and removes all the duplicates in the array, returning a new array with only the unique values.
Q6
 */
public class returnduplicate
{
	  int a[];
	  int size,i,j;
       int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	 
	  public int[] disp(int a[])
	  {
		  int m=0;
			
		  int c=0;
			
		   for(i=0;i<a.length;i++)
		   { 
			   for(j=i+1;j<a.length;j++)
			   {
				   if(a[i]==a[j])
				   { 
					   c++;
					    
				   }
			   }
		   }
	  int  p[]= new int[c];
			
			for(i=0;i<a.length;i++)
			{
				for(j=i+1;j<a.length;j++)
				   {
					 
				 if(a[i]==a[j])
				   { 
					    p[m]=a[i];
					    m++;
				   }
			}
				}
			 System.out.println("duplicate element");
				
		return p;
	  }
	 
	 	public static void main(String[]args)
		{
			Scanner sc= new Scanner(System.in);
			 System.out.println("enter the size ");
			  
			int    size=sc.nextInt();
			  int a[]=new int[size];
			  
			  returnduplicate ob= new returnduplicate();
			  ob.input(a);
			  int k[]=ob.disp(a);
		 
			  for(int ab:k)
				{
					if(ab!=0)
					{
						System.out.println(ab);
					}
				}
			
		}

}

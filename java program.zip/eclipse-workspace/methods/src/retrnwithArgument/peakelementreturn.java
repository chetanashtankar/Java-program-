package retrnwithArgument;
/*
 * Q30.Write a program that takes in an array of integers and returns the index of the first peak in the array
 *  (a peak is defined as an element that is greater than its neighboring elements).

 */
public class peakelementreturn 
{
	public int peakele(int a[])
	{

		int peak=a[0];
		int peak2=a[1]; 
		int index=0;
	for(int i=2;i<a.length;i++)
	{
		 
		if(a[i]>peak && peak2>peak)
		{
			index=i;
		peak=a[i];	
		peak2=peak;
		
		}
		break;		
	}
	 System.out.println("peak element is.."+peak);
	return index;
	}
	public static void main(String[] args) 
	{
		int[] a= {5,10,20,15};
		peakelementreturn ob= new peakelementreturn();
		int k=ob.peakele(a);
		System.out.print(k);
	}

}

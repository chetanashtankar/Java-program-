package retrnwithArgument;
/*
 * Write a program that takes in two sorted arrays of integers and merges them into a single sorted array.
 */
import java.util.Scanner;
public class mergtwo_insinglArr

{
	 
		int i;
		public void maxinput(int a[],int b[],int c[])
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter a element ");
			for(i=0;i<a.length;i++)
			{
				 a[i]=sc.nextInt();
			}
			System.out.println("Enter a element b");
			for(i=0;i<b.length;i++)
			{
				 b[i]=sc.nextInt();
			}
			
		}
		public void maxdisplay(int a[],int b[],int c[])
		{
			System.out.println("Element is ");
			for(i=0;i<a.length;i++)
			{
				System.out.print (" "+a[i]);
			}
			for(i=0;i<b.length;i++)
			{
				System.out.print(" "+b[i]);
			}
			
		}
		public int[]  maxout(int a[],int b[],int c[])
		{
			for(int i=0;i<a.length;i++)
			{
				for( i=0;i<b.length;i++)
				{
					c[i]=a[i]+b[i];
					
					
				}
			}
			return c;
		}
		
		public static void main(String[] args) 
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter a size");
			int size=sc.nextInt();
			int a[]=new int [size];
			int b[]=new int [size];
			int c[]=new int [size];
			mergtwo_insinglArr m=new mergtwo_insinglArr();
			m.maxinput(a,b,c);
			m.maxdisplay(a,b,c);
			
			int k[]=m.maxout(a ,b,c);
			System.out.println("\nAddtion is ");
			for(int d:k)
			{
				System.out.println(d);
			}
			
			
		}
	}



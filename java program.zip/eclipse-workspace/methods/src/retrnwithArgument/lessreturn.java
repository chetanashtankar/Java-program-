package retrnwithArgument;

import java.util.Scanner;

/*
 * Q13.Write a program that takes in an array of integers and returns a new array with all the numbers in the original array that are less than a given number.

 */
public class lessreturn 
{
	int a[];
	  int size,i,j;
int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
		   
		   
	  }
	  public int[] retrn(int a[])
	  {
		  System.out.println("enter  number");
		  int n=sc.nextInt();
		  int c=0;
		   for(i=0;i<a.length;i++)
		   {
			   if(a[i]<n)
			   {
				   c++;
			   }
		   }
		   int p[]= new int[c];
		   
		   int m=0;
			  System.out.println("array less element");
			  
			  for(i=0;i<a.length;i++)
			   {
				   if(a[i]<n)
				   {
					   p[m]=a[i];
					   m++;
				   }
			   }
		  
		  
		return p;
		  
	  }
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
		  System.out.println("enter size");
		  int size=sc.nextInt();
		  int a[]=new int[size];
		  lessreturn ob= new lessreturn();
		  ob.input(a);
		  int k[]=ob.retrn(a);
		  for(int bb:k)
			{
				if(bb!=0)
				{
					System.out.println(bb);
				}
			}
		 
	  }

}

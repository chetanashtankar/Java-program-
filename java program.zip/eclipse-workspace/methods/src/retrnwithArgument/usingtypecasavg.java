package retrnwithArgument;
/*
 * Write a Java method called calculateAverage that takes an array of integers as input and returns 
 * the average of the elements as a double.
 *  The method should handle potential data loss during the calculation by using appropriate 
 *  data type casting.
 */
import java.util.Scanner;
public class usingtypecasavg 
{
	int i,j;
	Scanner sc= new Scanner(System.in);
	public double calculatesum()
	{
	System.out.println("enter size arry");
	 int size= sc.nextInt();
	 int a[]=new int[size];
	 int sum=0;
	
	 for(i=0;i<a.length;i++)
	 {
		 a[i]=sc.nextInt();
	 }
	 for(i=0;i<a.length;i++)
	 {
		sum=sum+a[i];
	 }
	 System.out.println("sum of array element");
	 
	 double avg=(double)sum/a.length;
	 
	 
		return avg ;
		
	}
	
	public static void main(String[]args)
	{
		usingtypecasavg ob= new usingtypecasavg();
		System.out.println(ob.calculatesum());
	}
	
	
	
	
	
	
	
	

}

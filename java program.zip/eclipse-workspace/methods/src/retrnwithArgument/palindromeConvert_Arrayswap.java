package retrnwithArgument;
import java.util.Scanner;
/*
 * Q1. Wap take a number as an argument and  check it is palindrome or not , 
 * if the no is palindrome then convert it in array and return max number without 
 * sorting, else swap 1st number with the last number, use return type with argument
 *  method.
 */
public class palindromeConvert_Arrayswap 

{
	int a[];
	public int pal(int n)
	{
		int max=0;
		
		int rev=0;
		int rem;
		int temp=n;
		int c=0;
		while(temp!=0)
		{
			c++;
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
			
		}
		
		if(rev==n)
		{
			System.out.println("number is palindrome");
			int a[]=new int[c];
			int j=0;
			while(rev!=0)
			{
				rem=rev%10;
				
				a[j]=rem;
				j++;
				rev=rev/10;
			
			}
			System.out.println("palindrome convert in array");
			for(int k=0;k<a.length;k++)
			{
				System.out.println(a[k]);
			}
			
			for(int k=0;k<a.length;k++)
			{
				 if(a[k]>max)
				 {
					max= a[k]; 
				 }
			}
			
			
		}
		else {
			
			System.out.println("number is not palindrome");
		  
			}
		
		
	 
		
		System.out.println("max number in array");
		
		return max;
		
	}
	
	
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter mumber");
		int n=sc.nextInt();
		
		palindromeConvert_Arrayswap ob= new palindromeConvert_Arrayswap();
		System.out.println(ob.pal(n));
		
		
	}

}

package retrnwithArgument;
/*
 * Q19.Write a program that takes in an array of integers and returns a new array with all the prime numbers
 *  from the original array.

 */
import java.util.Scanner;
public class returnprime_innewArray 
{
	
	 int a[];
	  int size,i,j;
      int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	  
	  public int[] prime(int a[])
	  {
		  
	  int count;
		  for(int i=0;i<a.length;i++)
		  {
				count=0;
				for(int j=2;j<a.length;j++)
				{
					if(a[i]%j==0) 
					{
						count++;
					 
					}
				}
				if(count==0 && i!=1) {
					System.out.println(a[i]);
			 
				}
		  }
		  
		return a;
		  
	  }

	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		 System.out.println("enter the size ");
		  
		int    size=sc.nextInt();
		  int a[]=new int[size];
		  returnprime_innewArray ob= new returnprime_innewArray();
		  ob.input(a);
		  ob.prime(a);
	}
}

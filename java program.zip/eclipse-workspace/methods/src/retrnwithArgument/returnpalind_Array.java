package retrnwithArgument;
import java.util.Scanner;

public class returnpalind_Array
{
	public int[] returnsArray()
	{
	int a[]= {1,121,122,131,156};
	int i,j,rem,rev;
	int c=0,m=0;
	System.out.println("return palindrome in array");
	
	for(i=0;i<a.length;i++)
	{
		int temp=a[i];
		rev=0;
		while(temp!=0)
		{
			rem=temp%10;
			rev= rev*10+rem;
			temp=temp/10;
			
		}
		if(rev==a[i])
		{
			c++;
		}
	}
	int p[]= new int[c];
	
	for(i=0;i<a.length;i++)
	{
		int temp=a[i];
		rev=0;
		while(temp!=0)
		{
			rem=temp%10;
			rev= rev*10+rem;
			temp=temp/10;
			
		}
		if(rev==a[i])
		{
			p[m]=a[i];
			m++;
		}
		
		
	}
	return p;

}
	public static void main(String[]args)
	{
		returnpalind_Array ob= new returnpalind_Array();
		int k[]=ob.returnsArray();
		
		for(int aa:k)
		{
			if(aa!=0)
			{
				System.out.println(aa);
			}
		}
	}
	
}

















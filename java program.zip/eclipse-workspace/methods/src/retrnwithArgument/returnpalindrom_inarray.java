package retrnwithArgument;
import java.util.Scanner;
/*
 * Q23.Write a program that takes in an array of integers and returns a new array with all the 
 * palindrome numbers from the original array.

 */
public class returnpalindrom_inarray 
{
	int i,j;
	int rem,rev,c=0;
	Scanner sc= new Scanner(System.in);

	public void input(int a[])
	{
		System.out.println("enter array");
          for(i=0;i<a.length;i++)
          {
        	  a[i]=sc.nextInt();
          }
	}
	
	public int[] pal(int a[])
	{
		System.out.println("return palindrome in new  array ");

		for(i=0;i<a.length;i++)
		{
			int temp=a[i];
			
			rev=0;
	 
			while(temp!=0)
			{
				rem=temp%10;
				rev=rev*10+rem;
				temp=temp/10;
			}
			if(rev==a[i])
			{
				c++;
			}
			
		}
		
		int p[]=new int[c];
		int m=0;
		for(i=0;i<a.length;i++)
		{
			int temp=a[i];
			
			rev=0;
			c=0;
			while(temp!=0)
			{
				rem=temp%10;
				rev=rev*10+rem;
				temp=temp/10;
			}
			if(rev==a[i])
			{
				p[m]=a[i];
				m++;
				
			}
			
		}
		
		return p;
		
	}
	
public static void main(String[]args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("enter size");
	int size=sc.nextInt();
	int a[]=new int[size];
	returnpalindrom_inarray ob = new returnpalindrom_inarray();
	ob.input(a);
	int k[]=ob.pal(a);
	
	for(int ac : k)
	{
		if(ac!=0)
		{
			
			System.out.println(ac);
		}
	}


}
}

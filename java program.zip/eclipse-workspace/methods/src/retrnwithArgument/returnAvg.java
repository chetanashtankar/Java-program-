package retrnwithArgument;

import java.util.Scanner;

/*
 * Question 2:
Write a Java method that takes an array of integers as input and returns the average of all the elements in the array.

 */
public class returnAvg 
{
	int i,j;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[])
	{
		
		System.out.println("Avg array element");
		int sum=0;
		int avg=0;
	 
		for(i=0;i<a.length;i++)
		{
			sum=sum+a[i];
			
			 
		}
		  avg=sum/5;
		return avg;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		returnAvg ob= new returnAvg();
		ob.intput(a);
		 int k=ob.intput(a);
		 System.out.println(k);
			
	}

}



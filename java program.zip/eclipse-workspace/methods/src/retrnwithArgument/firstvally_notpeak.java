package retrnwithArgument;
/*
 * Q31.Write a program that takes in an array of integers and returns the index of the first valley in the array
 *  (a valley is defined as an element that is less than its neighboring elements).

 */
public class firstvally_notpeak 
{
	public int peakele(int a[])
	{

		int vally=a[0];
		int vally1=a[1]; 
		int index=0;
	for(int i=2;i<a.length;i++)
	{
		 
		if(a[i]<vally && vally1<vally)
		{
			index=i;
			vally=a[i];	
			vally1=vally;
		
		}
		break;		
	}
	 System.out.println("peak element is.."+vally);
	 System.out.println("first index of vally element");

	return index;
	}
	public static void main(String[] args) 
	{
		int[] a= {5,10,20,15};
		firstvally_notpeak ob= new firstvally_notpeak();
		int k=ob.peakele(a);
		System.out.println(k);
	}

}

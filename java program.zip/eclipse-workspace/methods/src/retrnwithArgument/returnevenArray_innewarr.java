package retrnwithArgument;

import java.util.Scanner;

/*
 * Q8.Write a program that takes in an array of integers and returns a new array with all the even numbers from the original array.

 */
public class returnevenArray_innewarr

{
	 int a[];
	  int size,i,j;
      int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	  public int[] even(int a[])
	  {
		  int c=0;
		  for(i=0;i<a.length;i++)
		   {
			  if(a[i]%2==0)
			  {
				  c++;
			  }
		   }
		  int p[]=new int[c];
		  int m=0;
		  System.out.println("even num");
		  
		  for(i=0;i<a.length;i++)
		   {
			  if(a[i]%2==0)
			  {
				  p[m]=a[i];
				  m++;
			  }
		   }
		  
		return p;
		  
	  }
	  
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
		  System.out.println("enter size");
		  int size=sc.nextInt();
		  int a[]=new int[size];
		  returnevenArray_innewarr ob= new returnevenArray_innewarr();
		  ob.input(a);
		  int k[]=ob.even(a);
		  for(int bb:k)
			{
				if(bb!=0)
				{
					System.out.println(bb);
				}
			}
		  
	  }
}

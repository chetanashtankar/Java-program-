package retrnwithArgument;
import java.util.Scanner;

public class returnsum {

	
	int sum=0;
	public int sum(int a,int b)
	{
		sum=a+b;
		return sum;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		returnsum ob= new returnsum();
		int x,y;
		System.out.println("enter a number");
		x= sc.nextInt();
		y=sc.nextInt(); 
		 
		
		int k=ob.sum(x, y);
		System.out.println("sum of two element="+k);
	}
}

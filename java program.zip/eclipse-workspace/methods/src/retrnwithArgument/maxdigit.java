package retrnwithArgument;
//2. Write a program to find the max number from an n-digit number.
import java.util.Scanner;
public class maxdigit 
{
	public int max(int n)
	{   int max=0;
	   while(n!=0)
	   {
		int rem=n%10;
		n=n/10;
		
		if(rem>max)
		{
			max=rem;
		}
		return max;
		
	}
	return n;

	}
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		maxdigit ob= new maxdigit();
		
		System.out.println("enter number");
		
		int n=sc.nextInt();
		
		int k=ob.max(n);
		System.out.println("max number in digit="+k);
	}
}

package retrnwithArgument;
import java.util.Scanner;

public class mindigit {
		 
			public int min(int n)
			{   int min=9;
			   while(n!=0)
			   {
				int rem=n%10;
				n=n/10;
				
				if(rem<min)
				{
					min=rem;
				}
				 
			}
			return min;
		 

			}
			public static void main(String[]args)
			{
				Scanner sc=new Scanner(System.in);
				mindigit ob= new mindigit();
				
				System.out.println("enter number");
				
				int n=sc.nextInt();
				
				int k=ob.min(n);
				System.out.println("min number in digit="+k);
			}
		}




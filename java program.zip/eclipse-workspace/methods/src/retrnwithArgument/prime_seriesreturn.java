package retrnwithArgument;
import java.util.Scanner;
/*
 * wap to find prime number series using return type with argument method
 */
public class prime_seriesreturn

{
	int a[];
	
 public int[] input(int f,int l)
 {
	 int p[]=new int[a.length];
     int k=0;
	 int c1=0;
	 for(int i=f;i<=l;i++)
	 {
		 int c=0;
	 
      for(int j=2;i<=j;j++ )
    	//	  while(f%i==0)
         {
        	 if(i%j==0)
        	 {
        		 c++;
        	 }
         }
         
         
         if(c==0)
         {
        	  a[k++]=i;
         }
		 
		
	 }
	  
	 
	return a;
	 
 }
 
 public static void main(String[]args)
 {
	 Scanner sc= new Scanner (System.in);
	 System.out.println("enter number");
	 int f= sc.nextInt();
	 int l=sc.nextInt();
	 prime_seriesreturn ob= new prime_seriesreturn();
	int k[]= ob.input(f, l);
	
	for(int bc: k)
	{
		if(bc!=0)
		{
			System.out.println(bc);
		}
	}
	 
 }
	
	
	

}

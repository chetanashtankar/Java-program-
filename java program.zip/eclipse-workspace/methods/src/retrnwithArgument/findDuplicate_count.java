package retrnwithArgument;

import java.util.Scanner;

/*
 * 6.Wap enter an array and find the duplicate element and also count of that.

 */
public class findDuplicate_count
{

	int i,j;
	
   public int input(int a[])
   {
	   int c=0;
	   Scanner sc= new Scanner(System.in);
		System.out.println("enter array element");
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			}
		System.out.println("find duplicates in array");
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					c++;
					System.out.println(a[i]);
				}
			}
		}
		
		System.out.println("count=");
	
	return c;
	   
   }
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int size=sc.nextInt();
		int a[]=new int[size];
		findDuplicate_count ob= new findDuplicate_count();
		System.out.println(ob.input(a));
		
		
	}

}

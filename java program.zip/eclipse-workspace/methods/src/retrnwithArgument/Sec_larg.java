package retrnwithArgument;

import java.util.Scanner;

/*
 * Question 6:
Write a Java method that takes an array of integers as input and returns the second largest element in the array.

 */
public class Sec_larg
{

	int i,j;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[],int size)
	{
		
		System.out.println("Sec max element in array");
		int max =a[0];
			 
		int sec_max=a[0];
		
	
	for(int i=0;i<a.length;i++)
	{
		if(a[i]>max)
		{
			sec_max=max;
			max=a[i];
		}
		else if(a[i]>sec_max && a[i]!=max)
		{
			sec_max=a[i];
		}
		   
		 
	}
	return sec_max;
	}
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		int i,j;
		for(  i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		Sec_larg ob= new Sec_larg();
		  
		 System.out.println(ob.intput(a, size));
			
			
	}


}

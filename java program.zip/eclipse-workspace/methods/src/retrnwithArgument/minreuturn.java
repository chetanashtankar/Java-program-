package retrnwithArgument;
/*
 * Question 4:
Write a Java method that takes an array of integers as input and returns the minimum element in the array.

 */
import java.util.Scanner;
public class minreuturn
{
	int i,j;
	int min= Integer.MAX_VALUE;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[],int size)
	{
		
		System.out.println("min element in array");
		 
		for(i=0;i<a.length;i++)
		{
			 if(a[i]<min)
			 {
				 min=a[i];
			 }
			 
		}
		   
		return min;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		int i,j;
		for(  i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		minreuturn ob= new minreuturn();
		  
		 System.out.println(ob.intput(a, size));
			
			
	}

}

package retrnwithArgument;

import java.util.Scanner;

/*
 * 
Question 3:
Write a Java method that takes an array of integers as input and returns the maximum element in the array.

 */
public class maxelementArray
{

	int i,j;
	Scanner sc= new Scanner(System.in);
	public int intput(int a[],int size)
	{
		
		System.out.println("max element in array");
		 int max=0;
		for(i=0;i<a.length;i++)
		{
			 if(a[i]>max)
			 {
				 max=a[i];
			 }
			 
		}
		   
		return max;
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("enter array element");
		int i,j;
		for(  i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		maxelementArray ob= new maxelementArray();
		  
		 System.out.println(ob.intput(a, size));
			
			
	}

}



	
	


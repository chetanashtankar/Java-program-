package retrnwithArgument;

import java.util.Scanner;

/*
 * Q29.Write a program that takes in an array of integers and removes all the negative numbers in the array, 
 * returning a new array with only the positive values.

 */
public class returnpositive_removengativ 
{
	
	 int a[];
	  int size,i,j;
      int p;
	  Scanner sc= new Scanner(System.in);
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	 
	  public int[] disp(int a[])
	  {
		  int m=0;
			
		  int c=0;
		  System.out.println("return positive array remove negative ");
			 
			
		   for(i=0;i<a.length;i++)
		   { 
			   if(a[i]>0)
			   {
				   c++;
			   }
		   }
		   
		   int p[]= new int[c];
		   
		   for(i=0;i<a.length;i++)
		   { 
			   if(a[i]>0)
			   {
				   p[m]=a[i];
				   m++;
			   }
		   }
		   
		return p;
		   
	  }
		   public static void main(String[]args)
		   {
			   
			   Scanner sc= new Scanner(System.in);
				 System.out.println("enter the size ");
				  
				int    size=sc.nextInt();
				  int a[]=new int[size];
				  returnpositive_removengativ ob= new returnpositive_removengativ();
				  ob.input(a);
				  
				  
				  int k[]=ob.disp(a);
				  
				  for(int neg : k)
				  {
					  if(neg!=0)
					  {
					  System.out.println(neg);
					  }
				  }
		   
		   }
}

package retrnwithArgument;

import java.util.Scanner;
/*
 * Q9. WAP to replace all negative value with its immediate left elements square. Means 
     arr[] = [12, 3, -19, 29, 5, -61, 44, 7, -9] 
     Output array will be [12, 3, 9, 29, 5, 25, 44, 7, 49].
 */
public class negative_leftsq 
{

	int i,j;
	
   public int[] input(int a[])
   {
	   int c=0;
	   Scanner sc= new Scanner(System.in);
		System.out.println("enter array element");
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			}
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]<0)
			{
			a[i]=a[i-1]*a[i-1];
		}
		}
		System.out.println("negative values left element square array element are");
		 
		return a;

}
   
   public static void main(String[] args) {
	
	   Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int size=sc.nextInt();
		int a[]=new int[size];
		negative_leftsq ob= new negative_leftsq();
		int k[]=ob.input(a);
		for(int ab : k)
		{
			if(ab!=0)
				System.out.println(ab);
		}
		 
}
}
package retrnwithArgument;

/*
 * Q4.Wap enter an array and search any particular element and find the count.

 */import java.util.Scanner;
public class searchPerticular_element
{
	
	int i,j;
	
	public int input(int a[])
	{
		int c=0;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter array element");
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			}
		System.out.println("enter u want to search element in array");
		int n=sc.nextInt();
		
		for(i=0;i<a.length;i++)
		{
			 if(a[i]==n)
			 {
				 c++;
				 System.out.println("element found");
			 }
			}
		
		System.out.println("count");
		return c;
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int size=sc.nextInt();
		int a[]=new int[size];
		searchPerticular_element ob= new searchPerticular_element();
		System.out.println(ob.input(a));
		
	}

}

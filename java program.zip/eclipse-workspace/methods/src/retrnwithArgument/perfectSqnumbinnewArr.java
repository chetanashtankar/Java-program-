package retrnwithArgument;

public class perfectSqnumbinnewArr
{
	 public int[] input(int a[])
	 {
		 int n=a.length;
		 int count = 0;
	    	
      for (int i = 0; i < a.length; i++)
    {
 
        // Square of the element
        int square = a[i] * a[i];
  
        for (int j = 0; j < a.length; j++)
        {
 
           
            if (a[j] == square)
            {
                
                count++;
            }
        }
    }
    
    int p[]=new int[count];
    int m=0;
    for (int i = 0; i < a.length; i++)
    {
 
        // Square of the element
        int square = a[i] * a[i];
  
        for (int j = 0; j < a.length; j++)
        {
 
           
            if (a[j] == square)
            {
                 p[m]=a[i];
                 m++;
            }
        }
        
    }
    System.out.println("perfect square  element");
	
    
	return p;
    
	 
}
	 
	 public static void main(String[]args)
	 
	 {
		 int a[]= {2,4,5,8,64,10};
		 perfectSqnumbinnewArr ob= new perfectSqnumbinnewArr();
	  int k[]=ob.input(a);
	  for(int per : k)
	  {
		  if(per!=0)
		  {
			  System.out.println(per);
		  }
	  }
		 
	 }

}

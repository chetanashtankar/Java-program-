package retrnwithArgument;
import java.util.Scanner;
/*
 * Q3. WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
    54, 34, 10, 0, 34] 
 */
public class ret 
{
	int i,j;
	public int [] replace(int a[])
	{
	
 			Scanner sc= new Scanner(System.in);
		
		System.out.println("enter array");
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
	System.out.println("replace 0's element into 1");
		for(i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				a[i]=1;
			}
		}
		
		 System.out.println("return new Array");
		
		
		
		return a;
		
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		System.out.println("enter size");
		int size= sc.nextInt();
		
		int a[]=new int[size];
		ret ob= new ret();
		int k[]=ob.replace(a);
		
		for(int bv : a)
		{
			if(bv!=0)
			{
				System.out.println(bv);
			}
		}
		
	}

}

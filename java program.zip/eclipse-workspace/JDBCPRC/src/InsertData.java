import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class InsertData {

	public static void main(String[] args) {


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/april ","root","12345678");
			
			//create a query
			
			String q= "insert into table1(tName,tCity) values(?,?)";
			
			// get the prepared ststement object
			
		PreparedStatement pstmt=con.prepareStatement(q);
		
		// set the values to the query
		
		pstmt.setString(1, "chetan Dafre");
		pstmt.setString(2, "Nagpur");
		
		pstmt.executeUpdate();
		
		System.out.println("inserted");
		
		con.close();
			
	}catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}

}
}

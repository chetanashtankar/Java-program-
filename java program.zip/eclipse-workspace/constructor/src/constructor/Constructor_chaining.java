package constructor;

public class Constructor_chaining
{

	

}

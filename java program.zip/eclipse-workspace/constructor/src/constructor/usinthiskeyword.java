package constructor;

public class usinthiskeyword 
{
	
	
	int id;
	String name;
	 
	 
	
 
	
	public void disp( int id,String name)
	{
		this.id=id;
		this.name=name;

		System.out.println(id+"  "+name);

	 
		
 }
	public void disp2()
	{
		System.out.println(id+ "   "+name);
	}
	
	public static void main(String[]args)
	{
		usinthiskeyword ob = new usinthiskeyword();
		ob.disp(12, "Nd");;
		ob.disp2();
		
	}

}

package constructor;
/*Q1. WAP In java Reverse the array 
input in constructor and final result through the method. 
*/
import java.util.Scanner;

public class reverse
{
	Scanner sc= new Scanner(System.in);
	int i,j;
	
	reverse(int a[],int size)
	
	{
		System.out.println("enter array element");
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("reverse array");
		for(i=a.length-1;i<a.length;i--)
		{
			System.out.println(a[i]);
		}
	}

	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size of array element");
		
		
		int size=sc.nextInt();
		int a[]=new int[size];
		
		reverse ob= new reverse(a,size);
	}
}

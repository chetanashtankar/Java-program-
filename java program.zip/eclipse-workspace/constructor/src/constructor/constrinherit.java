package constructor;

public class constrinherit {

}

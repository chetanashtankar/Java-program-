package constructor;
import java.util.Scanner;
public class parameter_constructor {
	int a,b;
	Scanner sc= new Scanner(System.in);
	
	parameter_constructor(int a, int b)
	{
	 
	 
		System.out.println("usiing parameter constructor");

		int sum=0;
		sum=a+b;
		System.out.println("sum of two number=" +sum);
	
	
		int sub=0;
		sub=a-b;
		System.out.println("sub of two number="+sub);
	 int mul=0;
		mul=a*b;
		System.out.println("mul of two number="+mul);
 
	
	 	int div=0;
		div=a+b;
		System.out.println("div of two number="+div);
	 
}
	public static void main(String[]args)
	{
		parameter_constructor ob= new parameter_constructor(12,8);
		 
	}
	
}




package constructor;

import java.util.Scanner;

/*
 * Q2.input two matrix and print sum in third matrix.

 */
public class additioninthird_matrix
{



Scanner sc= new Scanner(System.in);
	
	
	int a[][];
	int b[][];
	int c[][];
	additioninthird_matrix (int size,int a[][],int b[][],int c[][])
	{
	
	

	System.out.println("enter array elements A");
	for( int i=0;i<a.length;i++)
	{
		for(int j=0;j<a.length;j++)
		
		{
		a[i][j]=sc.nextInt();
		}
	}
	System.out.println("enter elements of B");
	for( int i=0;i<b.length;i++)
	{
		for(int j=0;j<b.length;j++)
		
		{
		b[i][j]=sc.nextInt();
		}
	}
	
	}
	public void disp(int size,int a[][],int b[][],int c[][])
	{
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c.length;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
			}
				
			}
		System.out.println("Additon of two matrix is");
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c.length;j++)
			{
				System.out.print(" "+c[i][j]);
				
			}
			System.out.println();
			}
			
		}
			
	
	
	
	
public static void main(String[] args)
{
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enetr a size");
int size=sc.nextInt();
	
	
	

 int a[][]=new int [size][size];
 
 int b[][]=new int [size][size];
 int c[][]=new int [size][size];
 
	
 additioninthird_matrix d=new additioninthird_matrix (size,a,b,c);
	d.disp(size ,a,b,c);
	
	
}



}
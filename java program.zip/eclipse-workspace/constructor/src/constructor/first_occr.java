package constructor;
/*
 * Q7.Given an array of integers of size N, the task is to find the first non-repeating
 element in this array. 

Examples:

Input: {-1, 2, -1, 3, 0}
Output: 2
 */
import java.util.Scanner;
public class first_occr
{
	Scanner sc= new Scanner(System.in);
	public void occr(int a[])
	{
		
		int i,j;
		System.out.println("enter array element");
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("first occur");
		
		for(i=0;i<a.length;i++)
		{
			 int c=0;
				
			for(j=0;j<a.length;j++)
			{
		   if(a[i]==a[j])
		   {
			c++;
		   }
		   
 		}
			if(c==1)
			   {
				   System.out.println(a[i]);
				   break;
			   }
			
 	}
		
 	
	}
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		first_occr ob= new first_occr();
		 ob.occr(a);
		
	}

}

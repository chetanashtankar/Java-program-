package constructor;
import java.util.Scanner;

public class transposematrix 
{
	Scanner sc=new Scanner(System.in);
	
	
	
	int a[][];
	
	transposematrix(int size,int a[][])
	{
	
	

	System.out.println("enter array elements A");
	for( int i=0;i<a.length;i++)
	{
		for(int j=0;j<a.length;j++)
		
		{
		a[i][j]=sc.nextInt();
		}
	}
	
	}
	public void disp(int size,int a[][])
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				System.out.print(" "+a[i][j]);
			}
			System.out.println();
				
			}
		System.out.println();
		System.out.println("transpose matrix");
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				System.out.print(" "+a[j][i]);
			}
			System.out.println();
				
			}
		
		}
			
	
	
	
	
public static void main(String[] args)
{
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enetr a size");
int size=sc.nextInt();
	
	
	

 int a[][]=new int [size][size];
 
 
 
	
 transposematrix d=new transposematrix (size,a);
	d.disp(size ,a);
	
	
}



}



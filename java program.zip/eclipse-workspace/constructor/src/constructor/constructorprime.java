package constructor;
import java.util.Scanner;
public class constructorprime
{
	int f,l;
	constructorprime()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the first and last number");
		 f=sc.nextInt();
		l=sc.nextInt();
		
		
	}
	
	public void prime()
	{
		System.out.println("prime number are");
		
		for(int i=f;i<=l;i++)
		{
			int c=0;
			 
			for(int j=2;j<i;j++)
			{
			   if(i%j==0)
			   {
				   c++;
				   break;
			   }
			}
			if(c==0)
			{
				System.out.println(i);
			}
		}
	}
	
	public static void main(String[]args)
	{
		constructorprime ob= new constructorprime();
		ob.prime();
	}

}

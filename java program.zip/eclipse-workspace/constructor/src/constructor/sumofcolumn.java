package constructor;
import java.util.Scanner;
public class sumofcolumn 
{
	
	int sum,row,col,rowsum;
	Scanner sc=new Scanner(System.in);
	sumofcolumn(int a[][])
	{
		System.out.println("Eneter the elemen");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++)
			{
				System.out.print(a[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public void name(int a[][]) {
		row=a.length;
		col=a.length;
		System.out.println("Sum of col");
		for (int i = 0; i < row; i++) 
		{
			int sumcol=0;
			
			for (int j = 0; j < col; j++)
			{
				sumcol=sumcol+a[j][i];
			}
			System.out.println("sum of:-"+(i+1)+ " col:  "+ sumcol);
		}
	}
	public static void main(String[] args) {
		int a[][]=new int[3][3];
		sumofcolumn obj=new sumofcolumn(a);
		obj.name(a);
	}
}





package constructor;
//Q2. WAP to print addition,substraction,multiplication,division.
import java.util.Scanner;
public class sumsubmul
{
	 
	int a,b;
	Scanner sc= new Scanner(System.in);
	
	sumsubmul()
	{
			System.out.println("enter two number");

		 a=sc.nextInt();
		 b=sc.nextInt();
	}
	
	public void sum()
	{
		System.out.println("using non parameter constructor");

		int sum=0;
		sum=a+b;
		System.out.println("sum of two number=" +sum);
	}
	public void sub()
	{
		int sub=0;
		sub=a-b;
		System.out.println("sub of two number="+sub);
	}
	public void mul()
	{
		int mul=0;
		mul=a*b;
		System.out.println("mul of two number="+mul);
	}
	
	public void div()
	{
		int div=0;
		div=a+b;
		System.out.println("div of two number="+div);
	}
	
	
	public static void main(String[]args)
	{
		sumsubmul ob= new sumsubmul();
		ob.sum();
		ob.sub();
		ob.mul();
		ob.div();
	}
	
}

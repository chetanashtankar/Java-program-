package constructor;

public class constructoe_chaining
{
	
	constructoe_chaining()
	{
		String name="Nd";
		int id=10;
		System.out.println(name+" "+id);
	}
	constructoe_chaining(int a, int b)

	{
		this();
		System.out.println(a+"  "+b);
	}
	
	constructoe_chaining(int a)
	{
		this(10,20);
		System.out.println(a);
	}
	
	
	public static void main(String[]args)
	{
		constructoe_chaining ob = new constructoe_chaining(40);
		 
	}
}

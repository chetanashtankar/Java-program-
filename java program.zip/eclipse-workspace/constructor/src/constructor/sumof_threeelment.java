package constructor;
/*
 * Q3.input a matrix and find the sum of any three element.

 */
import java.util.Scanner;
public class sumof_threeelment
{
	
	int i,j;
	Scanner sc= new Scanner(System.in);
	
	sumof_threeelment(int size,int a[][])
	{
		
		for( i=0;i<a.length;i++)
		{
			for( j=0;j<a.length;j++)
			{
				a[i][j]=sc.nextInt();
			}
			System.out.println();
		}
	}
		 
	
	public void sum(int size,int a[][])
	{
		System.out.println("sum of 3 element...");
		int sumrow=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[0].length;j++)
			{
				sumrow=a[0][0]+a[0][1]+a[0][2];
			}
			System.out.println();
			System.out.println("Sum of " +sumrow);  
		}
		 
	}

	
	
	public static void main(String[]args)
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enetr a size");
	int size=sc.nextInt();
		
		
		
    
	 int a[][]=new int [size][size];
	 
	  sumof_threeelment ob= new sumof_threeelment(size,a);
	 ob.sum(size, a);
	}
	 
	

}


package constructor;
import java.util.Scanner;
public class detailsparametr
{
	String name;
    int age;
	int idno;
  double salary;
  detailsparametr(String Name, int Age,int Idno,double Salary)
  {
	System.out.println("Name: " + name);
    System.out.println("Age: " + age);
    System.out.println("IDNO " + idno);
    System.out.println("Salary:" + salary);
}
public static void main(String[] args) {
	
	Scanner sc= new Scanner (System.in);

    System.out.println("Enter the Details");
    String name=sc.nextLine();
    int age=sc.nextInt();
   int idno=sc.nextInt();
   double salary=sc.nextDouble();
   detailsparametr ob= new detailsparametr("xyz",12,123,1200);
	  
}
}



package constructor;
import java.util.Scanner;
public class Symmetricmatrix 

{
	 int i,j;
	 int row ,col;
		Scanner sc=new Scanner(System.in);
		Symmetricmatrix(int num[][]){
			 System.out.println("Enter the Element");
			 for (int i = 0; i < num.length; i++) {
				for (int j = 0; j < num.length; j++) {
					num[i][j]=sc.nextInt();
				}
			}
			 for (int i = 0; i < num.length; i++) {
					for (int j = 0; j < num.length; j++) {
						System.out.print(num[i][j]+"\t");
					}
					System.out.println();
				}
		 }
		 public void name(int num[][]) {
			if(row!=col) {
				System.out.println("it's Square Matrix");
			}
			else {
				boolean flag=true;
				for (int i = 0; i < num.length; i++) {
					for (int j = 0; j < num.length; j++) {
						if(num[i][j]!=num[j][i]) {
							flag=false;
							break;
						}
						
					}
				}
				if(flag) {
					System.out.println("it's  symmetric");
				}
				else {
					System.out.println("Is's not  symmetric");
				}
			}
		}
		  
			
	
public static void main(String[]args)
 {
	Scanner sc=new Scanner(System.in);
	 System.out.println("enter the  Size");
	  
	  
	  int r=sc.nextInt();
	  int c=sc.nextInt();
	   int a[][]=new int[r][c];
	   
	   Symmetricmatrix ob= new Symmetricmatrix(a);
        ob.name(a);
 }
}

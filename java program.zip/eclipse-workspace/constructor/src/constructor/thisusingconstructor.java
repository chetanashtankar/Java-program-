package constructor;

public class thisusingconstructor 
{
   int id;
   String name;
   
   thisusingconstructor()
   {
	    this(12,"Nd");
	   
	   System.out.println("non parameterize construcor");
		
	   
   }
   thisusingconstructor(int id,String name)
   {
	  this.id=id;
	  this.name=name;
	  
	  System.out.println("parameterize constructor");
	  
	  
   }
   public void disp()
   {
	   System.out.println(id+ " "+name);
   }
   
   public static void main(String[]args)
   {
	   thisusingconstructor ob= new thisusingconstructor();
	   ob.disp();
	  
	   
   }
}


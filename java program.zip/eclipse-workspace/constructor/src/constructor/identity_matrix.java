package constructor;
import java.util.Scanner;
public class identity_matrix 
{
	int row ,col;
	Scanner sc=new Scanner(System.in);
	identity_matrix(int num[][]){
		 System.out.println("Enter the Element");
		 for (int i = 0; i < num.length; i++) 
		 {
			for (int j = 0; j < num.length; j++) 
			{
				num[i][j]=sc.nextInt();
			}
		}
		 for (int i = 0; i < num.length; i++)
		 {
				for (int j = 0; j < num.length; j++)
				{
					System.out.print(num[i][j]+"\t");
				}
				System.out.println();
			}
	 }
	 public void name(int num[][])
	 
	 {
		if(row!=col)
		{
			System.out.println("it's Square Matrix");
		}
		else {
			boolean flag=true;
			for (int i = 0; i < num.length; i++) 
			{
				for (int j = 0; j < num.length; j++)
				{
					if(num[i][j]!=1 && num[j][i]!=0) 
					{
						flag=false;
						break;
					}
					
				}
			}
			if(flag)
			{
				System.out.println("it's  IdentityMatrix");
			}
			else 
			{
				System.out.println("Is's not  IdentityMatrix");
			}
		}
	}
	 public static void main(String[] args)
	 {
		int num[][]=new int [3][3];
		identity_matrix obj=new identity_matrix(num);
		 obj.name(num);
	}
}


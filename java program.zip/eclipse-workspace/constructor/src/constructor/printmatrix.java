package constructor;
/*
 * Q1.initialise 3*3 matrix and print the element.

 */
import java.util.Scanner;

public class printmatrix
{
	int i,j;
	Scanner sc= new Scanner(System.in);
	
	
	printmatrix(int a[][])
	{
		System.out.println("enter 3*3 mtrix array element");
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
	}
	public void matrix(int a[][])
	{
		System.out.println("3*3 mtrix array element");
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				 System.out.print(a[i][j]+"  ");
			}
			System.out.println();
		}
		
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter row and column");
		
		int r=sc.nextInt();
	 int c=sc.nextInt();
		
		int a[][]=new int[r][c];
		printmatrix ob= new printmatrix(a);
		ob.matrix(a);
		
	}

}

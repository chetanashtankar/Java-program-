package constructor;
import java.util.Scanner;
public class parameter
{
	
	 
	
	parameter( int f, int l)
	{
System.out.println("palindrome numbers are using parameter constructor");
	    
		int rev,rem,temp;
		 while(f<=l)
		    {
		    	temp=f;
		    	rev=0;
		    	while(temp!=0)
		    	{
		    		rem=temp%10;
		    		rev=rev*10+rem;
		    		temp=temp/10;
		    	}
		    	   	
		    	if(rev==f)
		    	{
		    		System.out.println(f+" ");
		    	}
		    	f++;
		    }
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter first and last number");
		int x=sc.nextInt();
		int y=sc.nextInt();
		parameter ob= new parameter(x,y);
		
		
		
	}

}

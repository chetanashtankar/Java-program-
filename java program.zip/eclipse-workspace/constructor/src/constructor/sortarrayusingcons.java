package constructor;
/*
 * Q4..Find the duplicate from the elements Size of array will be 10; 
 input in constructor and final result through the method. 


 */
import java.util.Scanner;
public class sortarrayusingcons {

	Scanner sc= new Scanner(System.in);
	 
	 int size,i,j;
	 
	 sortarrayusingcons( int a[], int size )
	    {
	     for(i=0;i<a.length;i++)
	     {
	    	a[i]=sc.nextInt();
	    	}
	  
		 System.out.println("duplicate array element is ");
	     
		 for(i=0;i<a.length;i++)
	    	{
		 
	    		for(j=i+1;j<a.length;j++)
	    		{
	    			if(a[i]==a[j])
	    			{
	    				System.out.println(a[i]);
	    			}
	    		}
	    	}
	 }
	 
	 public static void main(String[]args)
	 {  
		 	
		 Scanner sc= new Scanner(System.in);
			int size;
			int a[];
	    	System.out.println("enter array size");
	    	  size=sc.nextInt();
	          a=new int[size];
	        
	        sortarrayusingcons ob= new sortarrayusingcons(a,size);
		 
			 
	 }
	 
	
	}
	
	
	


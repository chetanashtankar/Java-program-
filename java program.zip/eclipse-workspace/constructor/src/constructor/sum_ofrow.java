package constructor;
import java.util.Scanner;
/*
 * 
Q8.Wap initialise a 3*3 matrix and find the sum of rows.

 */
public class sum_ofrow {
	
	int sum,row,col,rowsum;
	Scanner sc=new Scanner(System.in);
	sum_ofrow(int num[][])
	{
		System.out.println("Eneter the elemen");
		for (int i = 0; i < num.length; i++) 
		{
			for (int j = 0; j < num.length; j++)
			{
				num[i][j]=sc.nextInt();
			}
		}
		for (int i = 0; i < num.length; i++)
		{
			for (int j = 0; j < num.length; j++)
			{
				System.out.print(num[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public void name(int num[][]) {
		row=num.length;
		col=num.length;
		System.out.println("Sum of row");
		for (int i = 0; i < row; i++) 
		{
			int rowsum=0;
			
			for (int j = 0; j < col; j++)
			{
				rowsum=rowsum+num[i][j];
			}
			System.out.println("sum of:-"+(i+1)+ " row:  "+ rowsum);
		}
	}
	public static void main(String[] args) {
		int num[][]=new int[3][3];
		sum_ofrow obj=new sum_ofrow(num);
		obj.name(num);
	}
}



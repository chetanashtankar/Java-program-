package constructor;
/*
 * Q3.WAP to enter a no and check it is pelindrome or not?

 */
import java.util.Scanner;
public class palindromenonparametr 
{
	int n;
	
	palindromenonparametr()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		
	}
	
	public void palindrome()
	{ 
		int f=n;
		int rem=0,rev=0;
		while(n!=0)
		{
		  rem= n%10;
		  rev= rev*10+rem;
		  n=n/10;
		  
		}
		if(rev==f)
		{
			System.out.println("number is palindrome");
			
		}
		else {
			System.out.println("number is not  palindrome");
			
		}
	}
	
	public static void main(String[]args)
	{
		palindromenonparametr ob= new palindromenonparametr();
		ob.palindrome();
	}

}

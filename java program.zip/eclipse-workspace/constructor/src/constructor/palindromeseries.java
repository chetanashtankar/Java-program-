package constructor;
//Q4.Wap print all pelindrome no between 10 to 200.
import java.util.Scanner;
public class palindromeseries
{
	int f,l;
	palindromeseries()
	{
		Scanner sc= new Scanner(System.in);
		f=sc.nextInt();
		l=sc.nextInt();
		
	}
	
	public void palindrome()
	{
		System.out.println("palindrome numbers are");
	    
		int rev,rem,temp;
		 while(f<=l)
		    {
		    	temp=f;
		    	rev=0;
		    	while(temp!=0)
		    	{
		    		rem=temp%10;
		    		rev=rev*10+rem;
		    		temp=temp/10;
		    	}
		    	   	
		    	if(rev==f)
		    	{
		    		System.out.println(f+" ");
		    	}
		    	f++;
		    }
	}
	
	
	public static void main(String[]args)
	{
		palindromeseries ob= new palindromeseries();
		ob.palindrome();
	}
	

}

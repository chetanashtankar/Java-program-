package constructor;
/*
 * Q8.WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
    54, 34, 10, 0, 34] 

 */
import java.util.Scanner;

public class zeroreplace1 
{

	int i,j;
	Scanner sc= new Scanner(System.in);
	
	zeroreplace1(int a[],int size)
	{
		System.out.println("enter array element");
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		System.out.println("replacing 0's element to 1  element");
		
		 
		for(i=0;i<a.length;i++)
		{
			 if(a[i]==0)
			 {
				 a[i]=1;
				 
			 }
		}
		for(i=0;i<a.length;i++)
		{
			 System.out.print(a[i]+"  ");
		}
		
		
	}
	
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size= sc.nextInt();
		int a[]=new int[size];
		zeroreplace1 ob= new zeroreplace1(a,size);
	}
}

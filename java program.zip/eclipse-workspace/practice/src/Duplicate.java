/*
 Find the Second Largest Element in an Array:
public static int findSecondLargest(int[] arr) {
    // Your code here
}
}
 */

import java.util.Scanner;
public class Duplicate
{
	
	public static  int findSecondLargest(int a[])
	{
		Scanner sc= new Scanner(System.in);
		
		int max=a[0];
		int Sec_max=a[0];
		System.out.println("enter element");
		
		for (int i = 0; i < a.length; i++) {
			a[i]=sc.nextInt();
			
		}
		
		for (int i = 0; i < a.length; i++) {
			
			if(a[i]>max)
			{
				Sec_max=max;
				max=a[i];
			}
			
			else if(a[i]>Sec_max && a[i]!=max)
			{
				Sec_max=a[i];
			}
		}
		
		
		System.out.println("maximum number:"+max);
		System.out.println("sec max:"+Sec_max);
		return Sec_max;
	 
	}
	
	public static void main(String[] args) {
		
			 
		Scanner  sc= new Scanner(System.in);
		int size =sc.nextInt();
		
		int a[]= new int[size];
		 	System.out.println(Duplicate.findSecondLargest(a));
		 
		
	}
	
}
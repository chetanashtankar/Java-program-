package Home_Practice;
 //in array palindrome number convert in new array
import java.util.Scanner;
public class PalindromeArrayCovertnewA
{  
	Scanner sc= new Scanner(System.in);
	public void disp()
	{
		System.out.println("enter size");
		int size= sc.nextInt();
		int a[]= new int[size];
		int d[]= new int[a.length];
		for (int i = 0; i < a.length; i++) {
			
			a[i]=sc.nextInt();
		}
		
		System.out.println("palindrome number in array");
		int c=0;
		for (int i = 0; i < a.length; i++) {
			
			int temp=a[i];
			
			int rem,rev=0;
			
			while(temp!=0)
			{
				rem=temp%10;
				rev= rev*10+rem;
				temp=temp/10;
	 		}
		 	
			if(a[i]==rev)
			{
				 
				System.out.println(a[i]); 
				d[i]=a[i];

	}

	}
		for (int i = 0; i < d.length; i++) {
			
			System.out.println("new "+d[i]);
		}
		
	}
		 

	public static void main(String[] args) {
		 
		PalindromeArrayCovertnewA ob= new PalindromeArrayCovertnewA();
		ob.disp();
	}

}

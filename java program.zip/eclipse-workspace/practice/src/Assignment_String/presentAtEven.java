package Assignment_String;
/*
 * Q2. WAP to print the all words that are present at even index and odd index

 */
public class presentAtEven {
	public static void main(String[] args) {
		 
		
		String s="Nehal Dafre";
		
		 System.out.println("String="+s);
		 char a[]=s.toCharArray();
		 System.out.println("even index : ");
		 
		 
		 for(int i=0;i<a.length;i++)
		 {
			 if(i%2==0)
			 {
				 System.out.print(  (a[i]));
			 }
			 
		 }
		 System.out.println();
		 System.out.println("odd index :");
			
		 for (int i = 0; i < a.length; i++) {
			

			 if(i%2!=0)
			 {
				 System.out.print("odd index="+ (a[i]));
			 }
		}


	}
}

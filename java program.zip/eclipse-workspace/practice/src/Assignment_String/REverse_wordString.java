package Assignment_String;
/*
 * Q3. Wap to reverse the word by word of String

 */
public class REverse_wordString {

	 public static void main(String[] args) {
		
		 
		 String s="hello java";
		 System.out.println("String ="+s);
		 
		 char a[]= s.toCharArray();
		 
		 for (int i = a.length-1;i>=0;i--) {
			
			 System.out.print(a[i]);
		}
		 
	}	 
	

}

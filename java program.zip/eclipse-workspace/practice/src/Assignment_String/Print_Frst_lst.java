package Assignment_String;
/*
 * Q1. WAP to print the first and last word of String

 */
import java.util.*;
public class Print_Frst_lst {

	public static void main(String[] args) {

		
		   Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter a string: ");
	        String input = scanner.nextLine();
	        
	        String[] a = input.split("\\s+"); 
	        if (a.length > 0) {
	            String firstWord = a[0];
	            String lastWord = a[a.length - 1];
	            System.out.println("First word: " + firstWord);
	            System.out.println("Last word: " + lastWord);
	        }
	        else
	        {
	            System.out.println("No words found in the input.");
	        }
	    }
		
		

		
		
	}


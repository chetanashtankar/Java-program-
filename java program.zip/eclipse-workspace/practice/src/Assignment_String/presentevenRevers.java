package Assignment_String;
/*
 *  Q4. WAP to reverse the word that are present at odd index.

 */
public class presentevenRevers {

	 
	public static void main(String[] args) {


		String s="hello java";
		
		char a[]=s.toCharArray();
		System.out.println(s);
		
		System.out.println("odd index");
		for (int  i=a.length-1;i>=0; i--) 
		{
			if(i%2!=0) {
				System.out.println(a[i]);
			}
		}
	}

}

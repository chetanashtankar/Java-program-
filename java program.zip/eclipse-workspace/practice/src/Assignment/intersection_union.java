package Assignment;

public class intersection_union {
 	
		/*
		10..Given two sorted arrays, find their union and intersection.
		  Example:
		  Input: arr1[] = {1, 3, 4, 5, 7}
		        arr2[] = {2, 3, 5, 6} 
		  Output: Union : {1, 2, 3, 4, 5, 6, 7} 
		         Intersection : {3, 5}
		 */

		 
			public static void main(String[] args) 
			{
				int a[]= {1, 3, 4, 5, 7,5,5};
				int b[]= {2, 3, 5, 6,3};
				
				int [] c=new int[a.length+b.length];
				
				for(int i=0;i<a.length;i++)
				{
					c[i]=a[i];
				}
				
				for(int i=0;i<b.length;i++)
				{
					c[a.length+i]=b[i];
				}
				
				System.out.println("Intersection Elements are : ");
				
				int n=c.length,k;
				for(int i=0;i<n;i++)
				{
					for(int j=i+1;j<n;j++)
					{
						if(c[i]==c[j])
						{
							System.out.print(c[i]+" ");
							for(k=j;k<n-1;k++)
							{
								c[k]=c[k+1];
							}
						n--;
						}
					}
				}
				
				System.out.println("");
				System.out.println("Union Elements are : ");
				for(int i=0;i<n;i++)
				{
					System.out.print(c[i]+" ");
				}
			

		
	}

}

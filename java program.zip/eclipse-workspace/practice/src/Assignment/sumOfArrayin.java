package Assignment;
/*
 * Q2.Given an array Arr of N positive integers and another number X. Determine whether or not there exist two elements in Arr whose sum is exactly X.

Example 1:

Input:
N = 6, X = 16
Arr[] = {1, 4, 45, 6, 10, 8}
 */
public class sumOfArrayin 
{
	
	public void sum()
	{
		
		int a[]= {1, 4, 45, 6, 10, 8};
		
		System.out.println("original array");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		for (int i = 0; i < a.length; i++) {
			
			int sum=16;
			for (int j = 0; j < a.length; j++) {
				
				
				if(a[i]+a[j]==sum)
				{
					System.out.println(a[i]+ " + "+ a[j]+ " "+ sum);
				}
			}
		}
	}

	public static void main(String[] args)
	{
		sumOfArrayin ob = new sumOfArrayin();
		ob.sum();
	}

}

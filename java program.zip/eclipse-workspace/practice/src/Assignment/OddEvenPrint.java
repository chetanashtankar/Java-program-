package Assignment;
/*
 * Q2. WAP to print the all words that are present at even index and odd index

 */
public class OddEvenPrint {

	public static void main(String[] args) {

String s="hello java programming ";



String a[]=s.split("\\s+");

System.out.println("words at even position");

for (int i = 0; i < a.length; i+=2) {
	
	
	System.out.println(a[i]);
}

System.out.println("words at odd position");

for (int i = 1; i < a.length; i+=2) {
	
	System.out.println(a[i]);
}
	}

}

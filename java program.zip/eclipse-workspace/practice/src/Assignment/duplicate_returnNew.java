package Assignment;
/*
 * Q2. Write a Java program to remove the duplicate elements of a given array and print the new length of the array.
    Sample array: [20, 20, 30, 40, 50, 50, 50]
    After removing the duplicate elements the program should return 4 as the new length of the array. 
 */
public class duplicate_returnNew
{
	public void name()
	{
		int num[]= {20, 20, 30, 40, 50, 50, 50};
		int m=0,count=0;
		int p[]=new int[num.length];
		System.out.println("original array");
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i]+" ");
		}
		System.out.println();
		System.out.println("remove Duplicate Element");
		for (int i = 0; i < num.length; i++) 
		{
			count=0;
		   for (int j = i+1; j < num.length; j++) 
		 {
			if(num[i] == num[j])
			{
				count=1;
				break;
			}
		}
		   if(count== 0)
		   {
			   p[m++]=num[i];
			   
			   //System.out.print(num[i]+" ");
		   }
		}
		
	    
		
		for (int i = 0; i < p.length; i++) 
		{
		   if(p[i]> 0)
		   {
			   count++;
			   System.out.print(p[i]+" ");
		   }
		}
		
		System.out.println();
		System.out.println("Length Of New Array is : "+count);
	
	}
	 



	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		duplicate_returnNew ob= new duplicate_returnNew();
		ob.name();

	}

}

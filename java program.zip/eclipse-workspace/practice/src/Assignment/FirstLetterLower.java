package Assignment;
/* 
 * Input:
S = "abCD"
Output: abcd
Explanation: The first letter (a) is
lowercase. Hence, the complete string
is made lowercase.
 */
public class FirstLetterLower {

	public static void main(String[] args) {

String s = "abCD";
System.out.println("String: "+s);
System.out.println("convert all lower case");
String s1 = s.substring(0,1)  + s.substring(1).toLowerCase();
System.out.println(s1);
 	}
	

}

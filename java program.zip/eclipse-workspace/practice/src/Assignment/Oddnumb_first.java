package Assignment;
/*
 * Q.6Write a Java program to separate even and odd numbers of a given array of integers. Put all even numbers first, and then 
 * odd numbers.
 */
public class Oddnumb_first {
	
	
	public void disp()
	{
		
		int a[]= {1,2,3,4,5,6,7,8,9,10};
		
		
		System.out.println("original array");
		for (int i = 0; i < a.length; i++) {
			
			System.out.println(a[i]);
		}
		
		System.out.println("even number");
		for (int i = 0; i < a.length; i++) {
			
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
			}
		}
		 	for (int i= 0; i < a.length; i++) {
			
		 
	  if(a[i]%2!=0)
	 {
		 System.out.println(a[i]);
		}
		}
	}

	public static void main(String[] args) {

		Oddnumb_first ob= new Oddnumb_first();
		ob.disp();
		

	}

}

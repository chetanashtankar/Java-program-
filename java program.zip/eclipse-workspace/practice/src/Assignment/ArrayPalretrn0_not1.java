package Assignment;
/*
 * Q6.Given a Integer array A[] of n elements. Your task is to complete the function PalinArray. Which will return 1 if all the elements of the Array are palindrome otherwise it will return 0.

Example 1:

Input:
5
111 222 333 444 555

Output:
1

Explanation:
A[0] = 111 //which is a palindrome number.
A[1] = 222 //which is a palindrome number.
A[2] = 333 //which is a palindrome number.
A[3] = 444 //which is a palindrome number.
A[4] = 555 //which is a palindrome number.
As all numbers are palindrome so This will return 1.
Example 2:

Input:
3
121 131 20
 
Output:
0


 */
import java.util.Scanner;
public class ArrayPalretrn0_not1
{
	Scanner sc= new Scanner(System.in);
  public int disp(int a[])
  {
	  System.out.println("Enter array element ");
	  
	  for (int i = 0; i < a.length; i++) {
		
		  a[i]=sc.nextInt();
	}
	  int temp,rem,rev=0,c=0;
	  for (int i = 0; i < a.length; i++)
	  {
		  temp=a[i];
		  
		  while(temp!=0)
		  {
			  rem=temp%10;
			  rev= rev*10+rem;
			  temp=temp/10;
			  
		  }
		  if(rev==a[i])
		  {
			  c++;
		  }
		  
		  
		
	}
	  
	  if(c==a.length)
	  {
		  System.out.println("this all numbers are palindrome it returns =");
	return 0;
	  
	  }
	  else {
		  System.out.println("this all numbers are not palindrome it returns =");

		  return 1;
	  }
	
	  
	  
	  
  }
	public static void main(String[] args) {
     Scanner sc= new Scanner(System.in);
	
	System.out.println("enter size");
	int size =sc.nextInt();
	
	 
    int a[]= new int[size];
    
    
    ArrayPalretrn0_not1 ob= new ArrayPalretrn0_not1();
    
    System.out.println(ob.disp(a));
	}

}

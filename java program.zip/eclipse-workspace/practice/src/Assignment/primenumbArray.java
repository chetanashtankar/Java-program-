package Assignment;
/*
 * Q7.Write a java program to find prime number between an array of element.


 */
public class primenumbArray {

	public static void main(String[] args) {


		
		int a[]= {1,2,3,4,5,6,7,8,9};
		
		System.out.println("original array");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		System.out.println("prime number in Array");
		for(int i=0;i<a.length;i++)
		{
			int j=2;
			int c=0;
			while(j<a[i])
			{
				
				
				if(a[i]%j==0)
			{
				c++;
				break;
				
			}
				 j++;
			
			}
			if(c==0 && a[i]!=1)
			{
				System.out.println(a[i]);
			}
			
			
		}
	}

}

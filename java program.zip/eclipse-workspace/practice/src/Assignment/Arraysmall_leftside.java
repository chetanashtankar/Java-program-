package Assignment;

import java.util.Scanner;

/*
 * Q5.Given an unsorted array of size N. Find the first element in array such that all of its left elements are smaller and all right elements to it are greater than it.

Note: Left and right side elements can be equal to required element. And extreme elements cannot be required element.

 

Example 1:

Input:
N = 4
A[] = {4, 2, 5, 7}
Output:
5
 */
public class Arraysmall_leftside 
{
	 public void disp()
	 {
		   Scanner sc = new Scanner(System.in);
		   
			System.out.println("Enter Size of array");
			int size = sc.nextInt();
			
			System.out.println("Enter Array Element");
			int a[]= new int[size];
			for (int i = 0; i < a.length; i++) 
			{
			  a[i]= sc.nextInt();	
			}
			
			System.out.println("Array Element Are");
			for (int i = 0; i < a.length; i++) 
			{
				System.out.println(a[i]+" ");
			}
			
			System.out.println("greater to left side");
			int temp=0;
			for (int i = 0; i < a.length; i++) {
			
				for (int j = i+1; j < a.length-1; j++) {
					
					  if (a[i] < a[j] && a[j]<a[j+1])
		                {
		                    temp=a[j];
		                }
				}
				
			}
			
			System.out.println(temp);
	 }
	 
	public static void main(String[] args) {
      
		Arraysmall_leftside ob= new Arraysmall_leftside();
		ob.disp();

	}

}

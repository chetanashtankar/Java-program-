package Assignment;
/*
 * Q3.Write a Java program to find the sum of the two elements
 *  of a given array which is equal to a given integer.
   Sample array: [1,2,4,5,6]
   Target value: 6. 
 */

public class sumofArray 
{

	public static void main(String[] args) {

  int a[]= {1, 5, 7, -1};
  int i,j;
  System.out.println("original array");
  for(i=0;i<a.length;i++)
{
	
System.out.println(a[i]);

}
  
  int sum=6;
  int c=0;
  for(i=0;i<a.length;i++)
  {
	  for(j=i+1;j<a.length;j++)
	  {
		  if(a[i]+a[j]==sum)
		  {
			  c++;
			  System.out.println(a[i]+ "  "+ a[j]+"  = "+sum);
		  }
		  
	  }
  }
  
  System.out.println("count of pair number="+c);
		
	}

}

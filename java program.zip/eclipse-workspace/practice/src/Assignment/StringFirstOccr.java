package Assignment;
/*
 * 6.Write a program that takes in a string and returns the index of the first occurrence of
a given substring.
 */
public class StringFirstOccr {

	public static void main(String[] args) {
		 
		
		String s="gibbleabbler";
		char ch[]=s.toCharArray();
		int c;
		System.out.println("Original string :");
		System.out.println(s);
		
		System.out.println("most repeating  :");
		for (int i = 0; i < ch.length; i++) 
		{
			c=0;
			for (int j = i+1; j < ch.length; j++)
			{
				
				if(ch[i]==ch[j])
						{
					        c=1;
						}
				
			}
			if(c==1)
			{
				System.out.println(i);
				break;
			}
			
		}
	
		
	}

}

package Assignment;

public class firstnonRepeating {

	public static void main(String[] args) {

		String s="codenerac";
		char ch[]=s.toCharArray();
		int c;
		System.out.println("Original string :");
		System.out.println(s);
		
		System.out.println("first non repeating char is :");
		for (int i = 0; i < ch.length; i++) {
			c=0;
			for (int j = i+1; j < ch.length; j++) {
				
				if(ch[i]==ch[j])
						{
					        c++;
						}
				
			}
			if(c==0)
			{
				System.out.println(ch[i]);
				break;
			}
			
		}
	
	}

}

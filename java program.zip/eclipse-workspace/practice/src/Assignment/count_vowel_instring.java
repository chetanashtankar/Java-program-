package Assignment;
/*
 * 2. Write a program that takes in a string and counts the number of vowels in it.

 */
public class count_vowel_instring 
{

	public static void main(String[] args)
	{
	 
		
		String s="programming";
		char a[]=s.toCharArray();
		int c=0;
		char x=0;
		System.out.println("original string:");
		System.out.println(s);
		System.out.println("after remove vowel string is:");
		for (int i = 0; i < a.length; i++)
		{
			
				
				if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')
				{
					
					
					c++;
				
				}	
			
				
		}
		System.out.println("number of vowel is :"+c);
		
		}

	
	

}

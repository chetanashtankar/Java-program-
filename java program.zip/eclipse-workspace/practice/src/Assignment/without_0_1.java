package Assignment;
/*
 * Q1.Write a Java program to check if an array of integers without 0 and -1.

 */
import java.util.Scanner;
public class without_0_1 {

	public static void main(String[] args) {
	 
	Scanner sc= new Scanner(System.in);
	System.out.println("enter size");

	int size=sc.nextInt();
		int a[]=new int[size];
	int i,j;
	System.out.println("enter array element");
	for(i=0;i<a.length;i++)
	{
		a[i]=sc.nextInt();
	}
	int c=0;
	System.out.println("in array not presenting 0 and -1");
	for (  i = 0; i < a.length; i++)
	{
		
		 if(a[i]==0|| a[i]==-1)
		 {
			c++; 
		 }
		  
		 if(c==0)
		 {
			 System.out.println(a[i]);
		 }
	}
	 
		
	}

}

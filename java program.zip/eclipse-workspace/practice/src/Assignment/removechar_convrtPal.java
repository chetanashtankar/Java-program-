package Assignment;
/*
 * 8. Remove a character from a string to make it a palindrome

Input  : str = “abcba”
Output : Yes
we can remove character ‘c’ to make string palindrome
 * 
 */
public class removechar_convrtPal {

	public static void main(String[] args) {
		String s="abcba";
		String s3=" ";
			String s2=	s.replace("c","");
			System.out.println("String after removing c is :");
		System.out.println(s2);
				
		for (int i =s.length()-1; i>=0; i--)
		{
			 s3=s2;
			break;
			
		}
		System.out.println("reverse String :");
		System.out.println(s3);
		
			if(s2==s3)
			{
				System.out.println("yes");
			}
			
			
	}

}

package Assignment;
/*
 * Q8.Given three arrays sorted in non-decreasing order, print all common elements in these arrays.

Examples: 

Input: 
ar1[] = {1, 5, 10, 20, 40, 80} 
ar2[] = {6, 7, 20, 80, 100} 
ar3[] = {3, 4, 15, 20, 30, 70, 80, 120} 
Output: 20, 80

 */
public class threearray_common {

	public static void main(String[] args) {
		 
		
		int a[]= {1, 5, 10, 20, 40, 80} ;
		int  b[] = {6, 7, 20, 80, 100} ;
		 int c[] = {3, 4, 15, 20, 30, 70, 80, 120} ;
		 
		 System.out.println("1st array");
		 
		 for (int i = 0; i < a.length; i++) {
			
			 System.out.println(a[i]);
		}
		 
		 
		 System.out.println("2nd array");
		
		 for (int i = 0; i < b.length; i++) {
			System.out.println(b[i]);
		}
		 
		 
		 System.out.println("3rd array");
		
		 for (int i = 0; i < c.length; i++) {
			System.out.println(c[i]);
		}
		 
		 System.out.println("common elements in three  Array");
		 for (int i = 0; i < a.length; i++) {
			
			 for (int j = 0; j < b.length; j++) {
				
				 for (int j2 = 0; j2 < c.length; j2++) {
					
					 if(a[i]==b[j]&& b[j]==c[j2])
					 {
						 
						 System.out.println(a[i]);
					 }
				}
			}
		}
	}

}

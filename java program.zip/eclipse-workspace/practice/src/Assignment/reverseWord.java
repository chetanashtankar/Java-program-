package Assignment;
/*
 *  Wap to reverse the word by word of String

 */
public class reverseWord {

	public static void main(String[] args) {


		String s="hello java programming";
		
		String []a=s.split(s);
		
		for (int i = a.length-1; i>=0; i--) {
			
			System.out.println(a[i]);
			
		}
	}

}

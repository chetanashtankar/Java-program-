package Assignment;
/*
 * Q7.Given two sorted arrays of distinct elements. There is only 1 difference between the arrays. First array has one element extra added in between. Find the index of the extra element.

Example 1:

Input:
N = 7
A[] = {2,4,6,8,9,10,12}
B[] = {2,4,6,8,10,12}
Output: 4
Explanation: In the second array, 9 is
missing and it's index in the first array
is 4.
 */
import java.util.Scanner;

public class TwoArraynotMAtchIndex 
{
	 public void disp()
	 {
		   Scanner sc = new Scanner(System.in);
		   
			System.out.println("Enter Size of 1st array");
			int size = sc.nextInt();
			
			System.out.println("Enter 1st Array Element");
			int a[]= new int[size];
			for (int i = 0; i < a.length; i++) 
			{
			  a[i]= sc.nextInt();	
			}
			System.out.println("Enter Size of 2nd array");
			
         int size2 = sc.nextInt();
         int b[]= new int[size];
         System.out.println("Enter 2nd Array Element");
 		
         for (int i = 0; i < b.length; i++) 
			{
			  b[i]= sc.nextInt();	
			}
         int c=0;
         System.out.println("output =");
         for (int i = 0; i < a.length; i++) {
			    c=0;
        	 for (int j = 0; j < b.length; j++) 
        	 {
        		 if(a[i]==b[j])
        		 {
        			 c=1;
        		 }
				
			}
        	 if(c==0) {
        	 System.out.println(i);
        	 break;
        	 }
		}
         
         
         
         
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TwoArraynotMAtchIndex ob= new TwoArraynotMAtchIndex();
		ob.disp();
	}

}

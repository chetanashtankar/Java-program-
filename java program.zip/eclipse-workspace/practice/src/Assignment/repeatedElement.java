package Assignment;
/*
 * Q6.Given an array of size N filled with numbers from 1 to N-1 in random order. The array has only one repetitive element. The task is to find the repetitive element.

Examples:

Input: a[] = {1, 3, 2, 3, 4}
Output: 3
 */
public class repeatedElement {

	
	public void disp()
	{
		
		
		int a[]={1, 3, 2, 3, 4};
		System.out.println("original array element");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		
		System.out.println("repeated element in array");
		for (int i = 0; i < a.length; i++) {
		
			for (int j = i+1; j < a.length; j++) {
				
				
				if(a[i]==a[j])
				{
					System.out.println(a[i]);
				}
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		repeatedElement ob= new repeatedElement();
		ob.disp();
	
	}

}

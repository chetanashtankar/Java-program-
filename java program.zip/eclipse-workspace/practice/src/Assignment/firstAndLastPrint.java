package Assignment;
/*
 * Q1. WAP to print the first and last word of String

 */
import java.util.Scanner;
public class firstAndLastPrint {

	public static void main(String[] args) {

		      Scanner scanner = new Scanner(System.in);
		        
		        System.out.print("Enter a string: ");
		        String input = scanner.nextLine();
		        
		        String[] a = input.split("\\s+");  
		        
		        if (a.length > 0)
		        {
		            System.out.println("First word: " + a[0]);
		            System.out.println("Last word: " + a[a.length - 1]);
		        } 
		        else
		        {
		            System.out.println("No words found in the input.");
		        }
		        
		        scanner.close();
		    
		
		
	}

}

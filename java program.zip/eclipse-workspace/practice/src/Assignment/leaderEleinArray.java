package Assignment;
/*
 * 
Q2.Given an array A of positive integers. Your task is to find the leaders in the array. An element of array is leader if it is greater than or equal to all the elements to its right side. The rightmost element is always a leader. 

Example 1:

Input:
n = 6
A[] = {16,17,4,3,5,2}
Output: 17 5 2
 */
public class leaderEleinArray {

	
	public void leader()
	{
		
		int a[]={16,17,4,3,5,2};
		int n=a.length;
		System.out.println("original Array");
		for (int i = 0; i < a.length; i++) {
			
			System.out.println(a[i]);
		}
		
		System.out.println("leader element");
		int c=0;
		for (int i = 0; i < a.length; i++) {
		int j;
			for (  j = i+1; j < a.length; j++) {
				
				
				if(a[i]<a[j])
				{
					c++;
					break;
				}
			}
				if(j==n)
				{
					System.out.println(a[i]);
				}
			 
			
			
		}
		
		
	}
	public static void main(String[] args) {
 
		leaderEleinArray ob = new leaderEleinArray();
		ob.leader();

	}

}

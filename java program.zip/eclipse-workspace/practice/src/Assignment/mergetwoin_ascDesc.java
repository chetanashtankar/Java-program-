package Assignment;
/*
 * Q6.a[]={10,20,30,40,50}
   b[]={1,2,3,4,5}
 
  output array=c[]={10,5,20,4,30,3,40,2,50,1}

 */
public class mergetwoin_ascDesc
{
public void merge() {
	
	int a[]={10,20,30,40,50};

	int b[]={1,2,3,4,5};
	

	int j=a.length;

	int k=b.length;

	int c[]=new int[j+k];

	int p=b.length-1;

	int h=0;
     
     System.out.println("1st array");
     for (int i = 0; i < a.length; i++)
     {
		System.out.println(a[i]);
	}
     
     System.out.println("2nd array");
     
     for (int i = 0; i < b.length; i++)
     {
		System.out.println(b[i]);
	}
	
	System.out.println("two array merge");
	for(int i=0;i<a.length;i++)
	{
			c[h]=a[i];
			h++;
			c[h]=b[p];
			h++;

			p--;
	}
		
	for(int i=0;i<c.length;i++)
	{
	  System.out.println(c[i]);
	}
}

	
	
	
	public static void main(String[] args) {


		mergetwoin_ascDesc ob= new mergetwoin_ascDesc();
		ob.merge();

	
	}
}

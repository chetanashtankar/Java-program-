package Assignment;
/*
 * 5. Write a program that takes in a string and removes all consecutive duplicates (leaves Only one instance of each character)
 */
public class remover_consecutive_string {

	public static void main(String[] args) {
		 
		String s="programming";
		System.out.println("original string :");
		System.out.println(s);
		char a[]=s.toCharArray();
		char x=0;
		System.out.println("After removing duplicate :");
		for (int i = 0; i < a.length; i++) {
			
			for (int j =i+1; j < a.length; j++) {
				if(a[i]==a[j])
				{
					a[j]=x;
				}
				
			}
			if(a[i]==x)
			{
				continue;
			}
			System.out.print(a[i]);
		}
		
	
	}

}

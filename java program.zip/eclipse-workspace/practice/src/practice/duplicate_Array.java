package practice;
//array is perfect or not
public class duplicate_Array
{
	
	int i,j;
	public int  input(int a[])
	{
		int p[]= new int[a.length];
	 	 int m=0;
	 	 System.out.println("array elements");
	 	 
	 	 for(i=0;i<a.length;i++)
	 	 {
	 		 System.out.println(a[i]);
	 	 }
	 	 
	 	System.out.println(" remove duplicate array elements");
	 	 int c=0;
	 	 for(i=0;i<a.length;i++)
	 	 {
	 		 for(j=i+1;j<a.length;j++)
	 		 {
	 			 if(a[i]==a[j])
	 			 {
	 				 a[i]=0;
	 			 }
	 		 }
	 	 }
	 	 for(i=0;i<a.length;i++)
	 	 {
	 		 if(a[i]==0)
	 		 {  
	 			
	 			 continue;
	 		
	 		 }
	 		 p[i]=a[i];
	 		 System.out.println(a[i]);
	 	 }
	 	 System.out.println("new Array");
	 	 
	 	 for(i=0;i<p.length;i++)
	 	 {
	 		 if(p[i]!=0)
	 		 System.out.println(p[i]);
	 	 }
		return 0;
	 
	}
		 
	
	public static void main(String[]args)
	{
		 int a[]= {20, 20, 30, 40, 50, 50, 50};
		 
			
		duplicate_Array ob= new duplicate_Array();
		 System.out.println(ob.input(a));
	}
}

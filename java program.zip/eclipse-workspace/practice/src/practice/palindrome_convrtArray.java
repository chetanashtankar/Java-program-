package practice;
import java.util.Scanner;
//wajp to check it is palindrome or not convert in array
public class palindrome_convrtArray 
{ 
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		int rem,rev=0;
		int i,j=0,c=0;
		int n1=n;
		while(n1!=0)
		{    c++;
			rem=n1%10;
			rev=(rev*10)+rem;
			n1=n1/10;
		}
		if(rev==n)
		{
			System.out.println("number is palindrome");
			int a[]=new int[c];
			while(rev!=0)
			{
				rem=rev%10;
				
				a[j]=rem;
				j++;   
				rev=rev/10;
			
			}
			System.out.println("palindrome convert in array");
			
			for(int k=0;k<a.length;k++)
			{
				System.out.println(a[k]);
			}
			
	 
		}
		else 
		{
			System.out.println("not palindrome");
		}
		
		
		
	}

}

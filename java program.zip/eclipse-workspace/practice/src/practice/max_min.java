package practice;
/*
 * Q2.Write a program that takes in an array of integers and finds the maximum and minimum values in the array.

 */
import java.util.Scanner;

public class max_min
{

	int i,j;
	  Scanner sc= new Scanner(System.in);
	  int a[];
	  int size;
	 int max=0;
	 int min=Integer.MAX_VALUE;
	public void input()
	{
		 System.out.println("size of array");
		 size=sc.nextInt();
		 a= new int[size];
		 System.out.println(" array element");
			
		 for(i=0;i<a.length;i++)
		 {
		 a[i]=sc.nextInt();
		 
		 }
	}
	
	public void max()
	{
		for(i=0;i<a.length;i++)
		 {
		    if(a[i]>max)
		    {
		    	max=a[i];
		    }
		 
		 }
		System.out.println("max number in array="+max);
	}
	public void min()
	{
		for(i=0;i<a.length;i++)
		 {
		    if(a[i]<min)
		    {
		    	min=a[i];
		    }
		 
		 }
		System.out.println("min number in array="+min);
	}
	
	
	public static void main(String[]args)
	{
		max_min ob= new max_min();
		ob.input();
		ob.max();
		ob.min();
	}
	}
	


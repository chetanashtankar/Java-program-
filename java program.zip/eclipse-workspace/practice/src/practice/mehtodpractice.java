package practice;
import java.util.Scanner;
public class mehtodpractice
{
	 
	Scanner sc= new Scanner(System.in);
	int a1,b1;
	public void disp(int a,int b)
	{
		 a=sc.nextInt();
	     b=sc.nextInt();
		
		a1=a;
		b1=b;
	}
	public void sum()
	{
 
		System.out.println(a1+b1);
		
	}
	
	public static void main(String[]args)
	{
		mehtodpractice ob= new mehtodpractice();
		
		 
		
		ob.disp(12, 13);
		ob.sum();
	}

}

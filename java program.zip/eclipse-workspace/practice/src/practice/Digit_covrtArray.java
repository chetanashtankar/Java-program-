package practice;

public class Digit_covrtArray {

	public static void main(String[] args) 
	{
		 
		int n=12345;
		
		int rem,rev=0;
		int c=0;
		while(n!=0)
		{
			c++;
			rem=n%10;
		     rev=rev*10+rem;
			n=n/10;
			
		}
		System.out.println(rev);
		
		int a[]=new int[c];
		
		 int j=0;
		 //int rem1;
		 while(rev!=0)
			{
				 
				rem=rev%10;

               a[j]=rem;
               j++;
				rev=rev/10;
				
			}
		 
		 for(int k=0;k<a.length;k++)
		 {
			 System.out.println(a[k]);
		 }
	}

}

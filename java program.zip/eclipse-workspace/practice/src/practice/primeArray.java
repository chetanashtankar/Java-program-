package practice;

import java.util.Scanner;

/*
 * find prime numbers in an array
 */
public class primeArray 
{
	
	int i,j;
	Scanner sc= new Scanner(System.in);
	public void prime1(int a[])
	{
		for(i=0;i<a.length;i++)
		{
			
			a[i]=sc.nextInt();
		}
		for(i=0;i<a.length;i++)
		{
			int c=0;
			
		//	for(j=2;j<i;j++)
			while(a[i]!=0)
			{
				if(a[i]%j==0)
				{
					c++;
					j++;
				}
				

			}

			if(c<0)
			{
				System.out.println(a[i]);
			}
			
			
			
		}
		
	}
	
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		
		int a[]=new int[size];
		primeArray ob= new primeArray();
		ob.prime1(a);
	}

}

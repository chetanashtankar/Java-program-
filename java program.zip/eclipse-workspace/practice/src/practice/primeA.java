package practice;
import java.util.Scanner;

public class primeA
{
	
	public void input()
	{
		Scanner sc= new Scanner(System.in);
		int a[]= { 2,3,4,5,6,7};
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("prime");
			
		for(int i=0;i<a.length;i++)
		{
			 boolean z=false;
				
			 
			/* for(int j=2;j<a[i];j++)
			{*/
				 while(a[i]!=0)
				 {
					 int j=2;
				if(a[i]%j==0)
				{
					z=true;
					break;
					
				}
				j++;
				 
				 }
			
			
			if(z)
			{
				
				System.out.println(a[i]);
			}
		}
		
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		primeA ob= new primeA();
		ob.input();
	}

}

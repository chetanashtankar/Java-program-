package practice;

import practceeasy.prime_numb_greater10sum;

/*
 * WAP to print the series of prime number between 1 to 100, 
 * now store all the prime number into array and remove all the prime number 
 * who's sum is greater than 5.
 */
public class prime_100sum10 
{

	 public void palindrome()
	    {
	    	int f=1;
			int l=100;
			int i=f;
			int c=0;
			int d=0;
			int sum=0;
		   int x=0;
			int p[]=new int [l];
			
			

		while(i<l)
			{
				int j=2;
				c=0;
				
				while(j<i)
				{
					if(i%j==0)
					{
						c++;
						d++;
						break;
						
					
					}
					j++;
				}
				
				
				
						if(c==0 && i!=1 )
						{
							 
							
							p[x++]=i;
								 
				     }
						
			i++;
			}
		System.out.println("prime series");
		  for (int j = 0; j < p.length; j++)
		  {
			  if(p[j] != 0)
			  {
			System.out.print(p[j]+" ");
		
			  }
		  }
		  System.out.println();
		  System.out.println(" sum is less than 5");
			
		 		for(i=0;i<p.length;i++)
			{
				int rem=0;
				int temp=p[i];
				while(temp!=0)
				{
					rem=temp%10;
					sum=sum+rem;
					temp=temp/10;
					
				}
				//System.out.println(sum);
				if(sum < 5)
				{
					
					if(p[i] != 0)
					  {
					System.out.print(p[i]+" ");
				
					  }
				}
				sum=0;
			}
	    }
	    
		
		
		public static void main(String[] args) 
		{
			prime_100sum10 obj = new prime_100sum10();
	      obj.palindrome();
		}

	}
package practice;
/*
 * 
arr1[] = {7, 1, 5, 2, 3, 6} 
arr2[] = {3, 8, 6, 20, 7} 
Then your program should print Union as {1, 2, 3, 5, 6, 7, 8, 20}
 and Intersection as {3, 6, 7}. Note that the elements of union and 
 intersection can be printed in any order.
 * 
 * 
 */
import java.util.Scanner;
public class practiceArray

{
    int i,j;
     Scanner sc= new Scanner(System.in);
     
     public void intersection()
     {
    	 int	a[] = {7, 1, 5, 2, 3, 6}; 
         int  b[] = {3, 8, 6, 20, 7} ;
      	int c[]= new int[a.length+b.length];
    	 
      	System.out.println("first array");
    	 for(i=0;i<a.length;i++)
    	 {
    		 System.out.println(a[i]);
    	 }
    	 System.out.println("second nd array");
     	
    	 for(i=0;i<b.length;i++)
    	 {
    		 System.out.println(b[i]);
    	 }
    	 for(i=0;i<a.length;i++)
    	 {
    		 c[i]=a[i];
    	 }
    	 for(i=0;i<b.length;i++)
    	 {
    		 c[a.length+i]=b[i];
    	 }
    	 
    	 System.out.println("intersection elements are");
    	 
    	 int n=c.length;
    	 
    	 for(i=0;i<n;i++)
    	 {
    		 for(j=i+1;j<n;j++)
    		 {
    			 if(c[i]==c[j])
    			 {
    				 System.out.println(c[i]);
    				
    				 for(int k=j;k<n-1;k++)
    				 {
    					 c[k]=c[k+1];
    					 
    				 }
    				 n--;
    			 }
    		 }
    	 }
    	 
    	 System.out.println("union elements are ");
    	 
    	 for(i=0;i<n;i++)
    	 {
    		 System.out.print(c[i]+"  ");
    	 }
    	 
    	 
    	 
    	 
     }
    
    
    public static void main(String[]args)
    {
    	practiceArray ob= new practiceArray();
    	ob.intersection();
    }
}

package practice;
/*
 * Q15.Write a program that takes in an array of integers and finds the mode of the array (i.e., the number that appears most frequently).

 */
import java.util.Scanner;

 public class freq
{
	int a[];
	  int size,i,j;
	 
		int count=0;
		int maxcount=0;
		int index=-1;  
	  Scanner sc= new Scanner(System.in);
	  
	  public void input(int a[])
	  {	 
		  System.out.println("enter the array ");
		  
		   
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
		   for(int i=0;i<a.length;i++)
			{
			 for(int j=i+1;j<a.length;j++)
			 {
				 if(a[i]==a[j])
					 count++;
			 }
			 if(count > maxcount)
				{
					maxcount=count;
					index=i;
				}
			}
			   System.out.println("majority element :-");
			if(maxcount > a.length/2)
			{
				System.out.println(a[index]);
				
			}
		   

}

	  
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
		  System.out.println("enter size");
		  int size=sc.nextInt();
		  int a[]=new int[size];
		  
		  freq ob= new freq();
		  ob.input(a);
	  }
}

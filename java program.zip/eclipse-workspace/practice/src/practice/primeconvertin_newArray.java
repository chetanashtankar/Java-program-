package practice;
import java.util.Scanner;
public class primeconvertin_newArray {

	 	
		 Scanner sc = new Scanner(System.in);
		  public void find()
		  {
			  System.out.println(" enter size ");
			  int size = sc.nextInt();
	      int a[] = new int[size];
	      int b[]= new int [a.length];
	      int i, n;
	      System.out.println("Enter the array elements:");
	      for (i = 0; i < a.length; i++) 
			{
	          a[i] = sc.nextInt();
	      }
			System.out.println(" PRIME ARRAY ELEMENTS  :- ");

	      for (i = 0; i < a.length; i++)
			{
	          n = a[i];
	          int count=1;// 

	          if (n <= 1)
	   		{
	          	count--;;
	          	
	          } 
				else 
				{
	              for (int j = 2; j * j <= n; j++)
					{
	                  if (n % j == 0)
					    {
	                  	count--;
	                      break;
	                  }
	              }
	          }

	          if (count==1)
	          {
	              b[i]=n;
	          }
	          
			}
	      System.out.println(" Print fianl output");
	      for (int j = 0; j < b.length; j++) 
	      {
	    	  if(b[j]!=0)
	    	  {
			System.out.print(b[j]+"  ");
	    	  }
		}
	      System.out.println();
	      System.out.println(" reverse the array ");
	     int rem=0;int x=0;
	     
	      for (int j = b.length-1; j >=0; j--)
	      {
	    	  int rev=0;
	    	  x=b[j];
	    	  while(x!=0)
	    	  {
	    		  rem=x % 10;
	    		  rev =rev * 10 +rem;
	    		  x= x/10;
	    		  
				}
	    	  b[j]=rev;
	    	  }
	      for (int k = 0; k < b.length; k++) {
	    	  if(b[k]!=0)
	  			
	    			System.out.println(b[k]+ " ");
		}
			
		
		  }
		public static void main(String[] args) {
			
			primeconvertin_newArray e = new primeconvertin_newArray();
			e.find();
		}
		

	
	}



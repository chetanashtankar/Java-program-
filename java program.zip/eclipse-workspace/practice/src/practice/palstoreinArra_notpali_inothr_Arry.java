package practice;
import java.util.Scanner;
public class palstoreinArra_notpali_inothr_Arry
{
	 
	     public void palindrome(int a[],int size)
	     {
	    	 Scanner sc= new Scanner(System.in);
	    	 int temp=0;
	    	 for (int i = 0; i < a.length; i++) 
	    	 {
			    a[i]=sc.nextInt();	
			}
	    	 System.out.println("Array Element are");
	    	 for (int i = 0; i < a.length; i++) 
	    	{
				System.out.print(a[i]+" ");
			}
	    	 System.out.println();
	    	 int palidrome[]= new int[size];
	    	 int NotPolidrome[]= new int[size];
	    	 for (int i = 0; i < a.length; i++)
	    	{
			  temp=a[i];
			  int rem,rev=0;
			  while(temp!=0)
			  {
				  rem= temp % 10;
				  rev= rev * 10 + rem;
				  temp= temp/10;
			  }
			  if(a[i]== rev)
			  {
				  palidrome[i]=a[i];
			  }
			  else
			  {
				  NotPolidrome[i]=a[i];
			  }
			}
	    	 
	    	 System.out.println("Palindrome Array Is");
	    	 for (int i = 0; i < palidrome.length; i++) 
	    	 {
	    		if(palidrome[i]>0)
	    		{
	    			System.out.print(palidrome[i]+" ");
	    		}
				
			}
	    	 System.out.println();
	    	 System.out.println("Not Palindrome Array Is");
	    	 for (int i = 0; i < NotPolidrome.length; i++) 
	    	 {
	    		 if(NotPolidrome[i]>0)
	    		 {
	    			 System.out.print(NotPolidrome[i]+" ");
	    		 }
			    	
			}
	     }
		
	
		public static void main(String[] args) 
		{
		 Scanner sc = new Scanner(System.in);	
	     System.out.println("Enter Array Size");
	     int size= sc.nextInt();
	     System.out.println("Enter Array Element");
	     int a[]= new int[size];
	     palstoreinArra_notpali_inothr_Arry obj = new palstoreinArra_notpali_inothr_Arry();
	     obj.palindrome(a, size);
		}

	}

	 



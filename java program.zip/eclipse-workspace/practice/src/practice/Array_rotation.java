package practice;
/*
 * Q18.Write a program that takes in an array of integers and rotates the array by a given number of positions.

 */
import java.util.Scanner;
public class Array_rotation
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);

	       
	       int i,j;
	       int a[]={5,6,1,2,3,4};


	System.out.println("Array elements");

	for(i=0;i<a.length;i++)
	{
	System.out.print(" "+a[i]);
	}
	System.out.print("\nhow many times u want to rotate");
	int k=sc.nextInt();


	System.out.println("after rotation");
	for(j=0;j<k;j++)
	{

	int temp=a[0];

	for(i=0;i<a.length-1;i++)
	{
	 a[i]=a[i+1];
	}
	a[a.length-1]=temp;
	}
	for(i=0;i<a.length;i++)
	{
	System.out.println(a[i]);

	}
	System.out.println(" minimum="+a[0]);
	}
	}



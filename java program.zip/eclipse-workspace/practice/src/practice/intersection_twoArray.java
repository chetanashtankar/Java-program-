package practice;
/*
 * Q27.Write a program that takes in two arrays of integers and finds the intersection of the two arrays.

 */
public class intersection_twoArray 
{
	public static void main(String[] args) 
	{
		int a[]= {1, 3, 4, 5, 7,5,5};
		int b[]= {2, 3, 5, 6,3};
		
		int [] c=new int[a.length+b.length];
		
		for(int i=0;i<a.length;i++)
		{
			c[i]=a[i];
		}
		
		for(int i=0;i<b.length;i++)
		{
			c[a.length+i]=b[i];
		}
		
		System.out.println("Intersection Elements are : ");
		
		int n=c.length,k;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(c[i]==c[j])
				{
					System.out.print(c[i]+" ");
					for(k=j;k<n-1;k++)
					{
						c[k]=c[k+1];
					}
				n--;
				}
			}
		}
	}
}
	
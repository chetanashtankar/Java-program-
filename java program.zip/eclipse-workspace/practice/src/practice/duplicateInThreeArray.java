package practice;
/*
 * Q8.Given two arrays sorted in non-decreasing order, print all common elements in these arrays.

Examples: 

Input: 
ar1[] = {1, 5, 10, 20, 40, 80} 
ar2[] = {6, 7, 20, 80, 100} 

 
Output: 20, 80
 */
public class duplicateInThreeArray
{

	int i,j;
	public void disp() 
	{
	   int 	a[] = {1, 5, 10, 20, 40, 80} ;
	 int    b[] = {6, 7, 20, 80, 100}; 
	 int c[]= {8,12,63,20,80};
	  	 	System.out.println("first array");
		for(i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
  System.out.println();
	System.out.println("second array");
	
		for(i=0;i<b.length;i++)
		{
			System.out.print(b[i]+" ");
		}
		 System.out.println();
			System.out.println("third array");
			
			for(i=0;i<c.length;i++)
			{
				System.out.print(c[i]+" ");
			}
			 System.out.println();

		 System.out.println();

		System.out.println("common elements in three Array");
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<b.length;j++)
			{
				for (int k = 0; k < c.length; k++) {
					
				
					if(a[i]==b[j] && b[j]==c[k])
					{
						System.out.println(a[i]);
					 
			}
				}
				 
		
		
	}
		}
	}
 
	
	public static void main(String[] args)
	{
		 
		duplicateInThreeArray ob= new duplicateInThreeArray();
		ob.disp();
	}

}

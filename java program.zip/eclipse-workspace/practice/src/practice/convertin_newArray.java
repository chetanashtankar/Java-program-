package practice;
/*
 * Q1) Java Program to copy all elements of one array into another array

 */
import java.util.Scanner;
class d
{
	int i,j;
	int a[];
	int b[];
	int size;
	Scanner sc= new Scanner(System.in);
  public void input()
  {
	  System.out.println("enter size");
	   size=sc.nextInt();
	  a=new int[size];
	   b=new int[a.length];
	   System.out.println("enter Array");
	  for(i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
	  }
	  
  }
  


}

class e extends  d{
	
	public void disp()
	{
	for(i=0;i<a.length;i++)
	{
		b[i]=a[i];
	}
	
	System.out.println("copy all element in new array");
	
	for(i=0;i<b.length;i++)
	{
		System.out.println(b[i]);
	}
	
	
	
}}
public class convertin_newArray 
{
	public static void main(String[]args)

{
    e ob= new e();
    ob.input();
    ob.disp();


}
	
}

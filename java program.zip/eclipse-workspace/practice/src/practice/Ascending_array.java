package practice;
/*
 *  
	 * .Write a program that takes in an array of integers and sorts the elements in ascending order.
	Q5
	 */
	import java.util.Scanner;

 
public class Ascending_array 
{
	 public void input()
	 {
		 
		 int i,j;
			Scanner sc= new Scanner(System.in);
			  System.out.println("Enter a size ");
			   	
	       int size=sc.nextInt();
	     
	       int a[]=new int[size];
	      
			System.out.println("Enter a element ");
			for(i=0;i<a.length;i++)
			{
				 a[i]=sc.nextInt();
			}
			 System.out.println("Ascending order array  element ");
					
			for(i=0;i<a.length;i++)
			{
				 int temp;
					
					for(j=i+1;j<a.length;j++)
				{
					if(a[i]>a[j])
					{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					}
				}
					 System.out.println(a[i]);
						
					
			}
		 
	 }
		
		public static void main(String[]args)
		{
			
			Ascending_array ob= new Ascending_array();
			ob.input();

	}

}


package practice;
import java.util.Scanner;
public class maxreturnUsingStatic 
{
	
	
	static int max34(int a[],int size)
	{
		
		
		
		int i,j;
		Scanner sc= new Scanner(System.in);
		int max=a[0];
		
		
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		
		System.out.println("max number");
		
		return max;
		
		
	}
	
	
	
	public static void main(String[]args)
	{
	//	maxreturnUsingStatic maxreturnUsingStatic=new maxreturnUsingStatic();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		
		int size=sc.nextInt();
		 	int a[]=new int[size];
		System.out.println("enter a elements");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		System.out.println(maxreturnUsingStatic.max34(a, size));		 
	}

}

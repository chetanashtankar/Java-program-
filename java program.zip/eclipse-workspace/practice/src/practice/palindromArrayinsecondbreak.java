package practice;
import java.util.Scanner;
public class palindromArrayinsecondbreak {

	public static void main(String[] args) {
		 
		Scanner sc =  new Scanner(System.in);
		System.out.println("Enter size of array");
		int size = sc.nextInt();
		int a[] = new int[size];
		int i;
		
		System.out.println("Enter array element");
		for(i=0; i<a.length; i++)
		{
			a[i] = sc.nextInt();
		}
		System.out.println("Palindrome number form array");
		//System.out.println("palindrom it will return a 1");
		int count=0;
		int count1=0;
		
		for(i=0; i<a.length; i++)
		{
			int rem, rev;
			int b = a[i];
			rev=0;
			while(b !=0)
			{
				count1++;
				rem= b%10;
				rev = rev*10+rem;
				b = b/10;
			}
			if(rev == a[i])
			{
				count++;
			}
		
		}
		
		int c[]=new int[count];
		
		for(i=0; i<a.length; i++)
		{
			int rem, rev;
			int b = a[i];
			rev=0;
			while(b !=0)
			{
				rem= b%10;
				rev = rev*10+rem;
				b = b/10;
			}
			if(rev == a[i])
			{
				c[i]=a[i];
			}
		}
		System.out.println("store in another array");
		for(i=0;i<c.length-1;i++)
		{
			System.out.println(c[i]);
		}
		
		
		
		
		
	}

	
	

}

package practice;
/*
 * Q8. WAP In java Reverse the array 
 input in constructor and final result through the method. 

 */
import java.util.Scanner;

public class reverseArray_constructor
{
	int i,j;
	Scanner sc= new Scanner(System.in);
	  reverseArray_constructor(int a[],int size)
	{

			
		 
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		 
	}
	  
	  
	  public void si(int a[],int size)
		{
		  
		  System.out.println("return array");
		    
		  for(i=a.length-1;i>=0;i--)
			{
			System.out.println(a[i]);
			}
				  
		  
	  }

	public static void main(String[] args) 
	{
		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]= new int[size];
		
		reverseArray_constructor ob= new reverseArray_constructor(a,size);
	    ob.si(a, size);
	
	}

}

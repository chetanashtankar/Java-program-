package practice;
/*
 * Q4.You are given two arrays, A and B, of equal size N. 
 * The task is to find the minimum value of A[0] * B[0] + A[1] * B[1] + .... + A[N-1] * B[N-1], where shuffling of elements of arrays A and B is allowed.


Example 1:
Input:
N = 3 
A[] = {3, 1, 1}
B[] = {6, 5, 4}
Output:
23
 */
import java.util.Scanner;
public class Arraysumofsize
{
	
	int result=0;
	public int input(int num1[],int num2[],int n) 
	{
		System.out.println("first array");
		
		for(int i=0;i<num1.length;i++)
		{
			System.out.println(num1[i]);
		}
		
System.out.println("2nd array");
		
		for(int i=0;i<num2.length;i++)
		{
			System.out.println(num2[i]);
		}
		
		
		
		for (int i = 0; i < num1.length; i++)
		{
			for (int j = i+1; j < num2.length; j++)
			{
				if(num1[i]>num2[j])
				{
					int temp=num1[i];
					num1[i]=num2[j];
					num2[j]=temp;
				}
			}
		}
		
		System.out.println("after two arrays sorting minimum value");
		
		for (int i = 0; i <n; i++) {
			result=result+(num1[i]*num2[n-i-1]);
		}
		return result;
	}
public static void main(String[] args) {
	Arraysumofsize obj=new Arraysumofsize();
	int num1[]={3,1,1};
	int num2[]={6,5,4};
	int n=num1.length;
	int k=obj.input(num1, num2, n);
	System.out.println(k);
}
}
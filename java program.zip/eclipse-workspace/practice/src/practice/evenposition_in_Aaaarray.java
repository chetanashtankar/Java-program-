package practice;

import java.util.Scanner;

class f
{
	int i,j;
	int a[];
	int b[];
	int size;
	Scanner sc= new Scanner(System.in);
  public void input()
  {
	  System.out.println("enter size");
	   size=sc.nextInt();
	  a=new int[size];
	   b=new int[a.length];
	   System.out.println("enter Array");
	  for(i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
	  }
	  
  }
  


}

class g extends  f
{
	public void even()
	{
		int sq=0;
		for(i=1;i<a.length;i=i+2)
		{
			sq=a[i]*a[i];
			System.out.println(a[i]);
			System.out.println("square of even position="+sq);
			
		}
		
		
		 
	}
}
	
public class evenposition_in_Aaaarray 


{
  public static void main(String[] args) {
	
	  g ob= new g();
	  ob.input();
	  ob.even();
}
  
}

package practice;
/*
 * Write a program that takes in an array of integers and returns the number of times a given element occurs in the array.
Write a program that takes in an array of integers and returns the maximum difference between any two elements in the array.
Write a program that takes in an array of integers and returns the smallest difference between any two elements in the array.
 */
  
/*	public int occr(int a[])
	{
		
		int i,j;
		System.out.println("enter array element");
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the number u want to check");
		int n=sc.nextInt();
		int c=0;
		for(i=0;i<a.length;i++)
		{
		   if(a[i]==n)
		   {
			   c++;
		   }
		   
		}
		System.out.println("returns occr");
		
		
		
		
		return c;
		
	}
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int[size];
		Occur ob= new Occur();
		int k= ob.occr(a);
		System.out.println(k);
		
		
	}*/
	  //  Write a program that takes in an array of integers and returns the maximum 
	  //difference between any two elements in the array.

	  


	/*
	
	 
	  Scanner sc= new Scanner(System.in);
	
	  public int maxd(int a[])
	  {
		  
		  int i,j;
			System.out.println("enter array element");
			
			for(i=0;i<a.length;i++)
			{
				a[i]=sc.nextInt();
			}
			
			for(i=0;i<a.length;i++)
			{
				int temp;
				for(j=i+1;j<a.length;j++)
				{
					if(a[i]<a[j])
					{
						temp=a[i];
						a[i]=a[j];
						a[j]=temp;
						
					}
				}
			}
			System.out.println("maximum difference");
			
			int k=a[0]-a[a.length-1];
		  
		
		return k;
		  
	  }  
	  
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
			int size=sc.nextInt();
			int a[]=new int[size];
			Occur ob= new Occur();
			int k= ob.maxd(a);
			System.out.println(k);
		  
	  }
	  
	  
	  
	  */
/*
 * Write a program that takes in an array of integers and returns the smallest difference between any two elements in the array.

 */
	  
import java.util.Scanner;
public class Occur
{ 
	  Scanner sc=new Scanner(System.in);
	  public int mind(int a[])
	  {
		  int i,j;
			System.out.println("enter array element");
			
			for(i=0;i<a.length;i++)
			{
				a[i]=sc.nextInt();
			}
			int mindiff=0;
			for(i=0;i<a.length;i++)
			{
			  for(j=i+1;j<a.length;j++)
			  {
				  int diff=a[i]-a[j];
				  
				  if(diff<mindiff)
				  {
					  mindiff=diff;
				  }
			  }
			}
			
			
			
		return mindiff;
		  
	  }
	  
	  
	  public static void main(String[]args)
	  {
		  Scanner sc= new Scanner(System.in);
			int size=sc.nextInt();
			int a[]=new int[size];
			Occur ob= new Occur();
			int k= ob.mind(a);
			System.out.println(k);
			
	  }
	  
	  

}

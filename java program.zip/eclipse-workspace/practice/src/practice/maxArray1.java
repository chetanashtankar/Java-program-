package practice;
/*
 * Write a program to calculate the sum of all elements in an array.

 */
import java.util.Scanner;
public class maxArray1 


{
	
	int i,j;
	
	maxArray1(int a[])
	{
		Scanner sc= new Scanner(System.in);
		 System.out.println("enter array element");
		 for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
			for(i=0;i<a.length;i++)
			{
				 for(j=i+1;j<a.length;j++)
				 {
					 if(a[i]==a[j])
					 {
						 a[i]=0;
					 }
					 
				 }
		}
			
			System.out.println("after removing duplicate array element");
			
			for(i=0;i<a.length;i++)
			{
				if(a[i]==0)
				{
					continue;
				}
				System.out.println(a[i]);
				
			}
			
				 
			
			
			 
	 
		
	}
	
	
	public static void main(String[]args)
	{
		
		Scanner sc= new Scanner(System.in);
	
	    System.out.println("enter size");

	    int size=sc.nextInt();
	    
	    int a[]=new int[size];
	    
	    maxArray1 ob= new maxArray1(a);
	    
	    
	}
	
	

}

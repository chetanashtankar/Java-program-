package practice;
/*
 * The equilibrium index of an array is an index such that the sum of elements at lower indexes is equal to the sum of elements at higher indexes. 
Examples: 
Input: A[] = {-7, 1, 5, 2, -4, 3, 0} 
Output: 3 
 */
public class equilibrium
{
	public void input(){
		int i,j,k,lsum,rsum;
		int a[]={-7,1,5,2,-4,3,0};
		System.out.println("Equlibrium point is");
		for(i=0;i<a.length;i++)
		{
	                 lsum=0;
	                  rsum=0;
			for(j=0;j<i;j++)
			{
	           
	                          lsum=lsum+a[j];
			}
			
			
				for(k=i+1;k<a.length;k++)
				{
					rsum=rsum+a[k];
				}
				if(lsum==rsum)
				{
					System.out.println("\nindex= "+i+"  \nposition=   "+(i+1));
				}
		}
	}

	public static void main(String[] args) {
	
		equilibrium ob= new equilibrium();
		ob.input();
				
	}

}

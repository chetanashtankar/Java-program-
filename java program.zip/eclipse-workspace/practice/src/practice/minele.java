package practice;

public class minele
{
	
	static {
		
		
		int i=1;
		System.out.println(i);
	}
	
	 public static void main(String[] args) {
		
		 
	}

}

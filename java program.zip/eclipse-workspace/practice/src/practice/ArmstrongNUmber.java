package practice;
import java.util.Scanner;
public class ArmstrongNUmber
{
	
	static boolean armstr(int n)
	{
		int a=n;
		int rem,rev=0;
		 
		while(n!=0)
		{
			
			rem=n%10;
			rev=rev+rem*rem*rem;
			n=n/10;
		}
		
		
		if(a==rev)
		{
			return true;
		}
		
		else {
		
		return false;
		
	}
	}
	
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n= sc.nextInt();
		System.out.println(ArmstrongNUmber.armstr(n));
		
		
	}
	

}

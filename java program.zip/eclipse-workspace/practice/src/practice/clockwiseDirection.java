package practice;

public class clockwiseDirection
{
	/*
	 * input
6548

output

8 5 4 6
	 */
	public static void main(String args [])
	{
		 	int a[]= { 6,5,4,8 };
		
		int i; 
		int temp=a[0];
		System.out.println(" Array elements are  :-   ");
		for(i=0;i<a.length;i++)
		{
			System.out.print(a[i] +  "  ");
		}
		   System.out.println();
		    System.out.println(" Clockwise direction  :-  ");
		       for(i=0;i<a.length-1;i++)
			   {
			   a[i]=a[i+1];
			   }
			   a[a.length-1]=temp;
			             for(i=0;i<a.length;i++)
						 {
							 System.out.print(a[i]+  "  ");
						 }
						 System.out.println();
	}
}



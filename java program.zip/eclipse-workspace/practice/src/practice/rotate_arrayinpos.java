package practice;

public class rotate_arrayinpos 
{

}

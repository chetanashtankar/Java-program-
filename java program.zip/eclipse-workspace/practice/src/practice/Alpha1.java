package practice;

public class Alpha1
{
	
	public static void main(String[]arg)
	{
	
	int i,j;
	int n=6;
	char alpha=64;
	
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=i;j++)
		{
	     System.out.print( (char) (alpha + j));		
		}
		System.out.println();
	}
	
	}
}

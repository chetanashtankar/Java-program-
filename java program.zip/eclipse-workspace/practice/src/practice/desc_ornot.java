package practice;

import java.util.Scanner;

public class desc_ornot {
	
	
	public void input()
	{
		Scanner sc= new Scanner(System.in);
		int i,j;
		int a[];
		int size=sc.nextInt();
		a=new int[size];
		int c=0;
		int temp;
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("array is descending");
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					c++;
				}
			}
			System.out.println(a[i]);
		}
		if(c>0)
		{
			System.out.println("array is descending ");
		}
		else {
			System.out.println("array is not descending ");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		desc_ornot ob= new desc_ornot();
		ob.input();
	}

}

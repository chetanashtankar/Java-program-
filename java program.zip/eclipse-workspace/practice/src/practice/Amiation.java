package practice;

class animation extends Thread
{
	public void run()
	{
		String s="static variable: object.";
		System.out.println("String :"+s);
		
		char a[]=s.toCharArray();
		
		for(int i=0;i<a.length;i++)
		{
			try
			{
				Thread.sleep(100);
				
				System.out.print(a[i]+"");
				
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
	}
}

class animation2 extends Thread
{
	public void run()
	{
		String s="static variable: object.";
		System.out.println("String :"+s);
		
		char a[]=s.toCharArray();
		
		for(int i=0;i<a.length;i++)
		{
			try
			{
				Thread.sleep(100);
				
				System.out.print(a[i]+"");
				
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			
		}
	}
}
public class Amiation extends Thread
{

	public static void main(String[] args) 
	{
		animation animation=new animation();
		animation.start();
		
		animation2 animation2=new animation2();
		try
		{
			animation.join();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		animation2.start();
	}

}

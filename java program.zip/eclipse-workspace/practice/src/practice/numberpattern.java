package practice;

 
public class numberpattern 
{
	public static void main(String[] args)
	{
		
		int i,j;
			
		 for(i=1;i<=5;i++)
		 {
			 	
			 for(j=5;j>=i;j--)
			 {
				   
				 System.out.print( " ");
				 
			 }
			 int temp=1;
				
			 for(j=1;j<=i;j++)
			 {
				   
				 System.out.print(temp+ " ");
				 temp=temp*(i-j)/(j);
				 
			 }
			 
			 
		 	 System.out.println();
		 
	}
		 

	}
}

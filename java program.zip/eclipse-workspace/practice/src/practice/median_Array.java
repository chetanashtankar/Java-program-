package practice;
/*
 * Q11.Write a program that takes in an array of integers and
 *  finds the median value of the array.
 */
public class median_Array 
{

	public void input()
	{
		int a[]= {10,2,38,22,38,23};
		
		int b[]= {10,2,38,23,38,23,21};
		
		if(a.length %2==0)
		{
			int mid=a.length/2;
			
			int mid2=(a[mid]+a[mid-1])/2;
			
			System.out.println(mid2);
			
		}
		
		System.out.println(a[a.length/2]);
	}
	public static void main(String[] args) 
	{
		median_Array median=new median_Array();
		median.input();
		
	}
}

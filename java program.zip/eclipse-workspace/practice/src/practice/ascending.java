package practice;
/*
 * Q16.Write a program that takes in an array of integers and checks
 *  if the array is sorted in ascending order.

 */
import java.util.Scanner;
public class ascending
{
	public void input()
	{
		Scanner sc= new Scanner(System.in);
		int i,j;
		int a[];
		int size=sc.nextInt();
		a=new int[size];
		int c=0;
		int temp;
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("array is ascending");
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					c++;
				}
			}
			System.out.println(a[i]);
		}
		if(c>0)
		{
			System.out.println("array is ascending ");
		}
		else {
			System.out.println("array is not ascending ");
		}
		
		
	}
	
	public static void main(String[]args)
	{
		ascending ob=new ascending();
		ob.input();
	}

}

package practice;

import java.util.Scanner;

/*
 * 1. Check if all array elements are present in a given stack or not
Input: S = {10, 20, 30, 40, 50}, arr[] = {20, 30}
Output: Yes
Explanation:
Elements 20 and 30 are present in the stack.

 */
public class SearchElemet {

	 public void show() {
		 Scanner sc= new Scanner(System.in);
		 
		 int a[]= {10, 20, 30, 40, 50};
		 for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		 System.out.println("enter first number do you want to search"); 
		 int n=sc.nextInt();
		 System.out.println("enter second number number do you want to search"); 
		 int n1=sc.nextInt();
		 int c=0;
		 
		 for (int i = 0; i < a.length; i++) {
			 for (int j = i+1; j < a.length; j++) {
				
			
			if(a[i]==n && a[j]==n1 )
			{
				c++;
			 
			}
			 
			 }
			 
		}

			if(c>0)
			{
				System.out.println("number is present in stack");
			}
		
		 
	 }
	public static void main(String[] args) {
		SearchElemet SearchElemet= new SearchElemet();
		SearchElemet.show();
	}

}

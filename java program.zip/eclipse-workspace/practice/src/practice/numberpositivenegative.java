package practice;
/*
 * Q4.Take 20 integer inputs from user and print the following using class and object:
number of positive numbers
number of negative numbers
number of odd numbers
number of even numbers
number of 0s. 
 */
import java.util.Scanner;
class a12
{
   int a[];
   int i,j;
   int size;
   Scanner sc= new Scanner(System.in);
   public void input()
   {
	   System.out.println("enter size");
	   size=sc.nextInt();
	   a=new int[size];
	   System.out.println("enter array element ");
	   for(i=0;i<a.length;i++)
	   {
		   a[i]=sc.nextInt();
	   }
    }
 }

class b extends a12
{
	public void positive()
	{
		System.out.println("number of positive in array");
   for(i=0;i<a.length;i++)
   {
	   if(a[i]>0)
	   {
		   System.out.println(a[i]);
	   }
   }
	}

}

class h extends b
{
  	
	public void negative()
	{
		System.out.println("number of negative in array");
   for(i=0;i<a.length;i++)
   {
	   if(a[i]<0)
	   {
		   System.out.println(a[i]);
	   }
   }
	}
	
	
	public void odd()
	{
		System.out.println("odd numbers in array");
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				if(a[i]!=0)
				{
				System.out.println(a[i]);
				}
			}
		}
		
		
	}
	
	public void even()
	{
		System.out.println("even numbers in array");
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
			}
		}
		
		
	}

	public void zero()
	{
		System.out.println("zero numbers in array");
		for(i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				System.out.println(a[i]);
			}
		}
		
		
	}

}
public class numberpositivenegative {

	public static void main(String[] args) {
		h ob= new h();
		ob.input();
		ob.positive();
		ob.negative();
		ob.even();
		ob.odd();
		ob.zero();
		 
	}

}

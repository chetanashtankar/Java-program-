package practice;

import java.util.Scanner;

public class multiplytwomatrix 
{
	int i,j;
	public void maxinput()
	{
		Scanner sc= new Scanner(System.in);
		int size=sc.nextInt();
		
		int a[][]=new int [size][size];
		int b[][]=new int[size][size];
		int c[][]=new int[size][size];
		System.out.println("Enter a element ");
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++)
			{
				a[i][j]=sc.nextInt();
			}
			System.out.println();
		}
		System.out.println("Enter a element b");
		for(i=0;i<b.length;i++)
		{
			for(j=0;j<b.length;j++)
			{
				b[i][j]=sc.nextInt();
			}
			System.out.println();
			 
		}
		
		for(i=0;i<c.length;i++)
		{
		 
			for(j=0;j<c.length;j++)
			{
				
				 c[i][j]=a[i][j]*b[i][j];
			}
			System.out.println();
		 
			 
		}
		System.out.println("multiplication of two array");
		 
		for(i=0;i<c.length;i++)
		{
			for(j=0;j<c.length;j++)
			{
				System.out.print(c[i][j]+"  ");
				  
			}
			System.out.println();
		 
			 
		}
		
		
	}
	
	public static void main(String[]args)
	{
		
		multiplytwomatrix ob= new multiplytwomatrix();
		ob.maxinput();
		
	}


}

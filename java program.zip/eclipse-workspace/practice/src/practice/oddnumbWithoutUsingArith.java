package practice;
/*
 * How to check if a given number is even/odd without using an Arithmetic operator:
 */
import java.util.Scanner;
class odd1
{
	public void inp()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");

		int n=sc.nextInt();
		
		if((n & 1)!=0)
		{
			System.out.println("number is odd");
		}
		else {
			System.out.println("number is even");

		}
		
	}
}
public class oddnumbWithoutUsingArith
{
	public static void main(String[]args)
	{
		odd1 ob= new odd1();
		ob.inp();
	}

}

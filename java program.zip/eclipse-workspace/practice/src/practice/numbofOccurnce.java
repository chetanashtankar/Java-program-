package practice;
/*
 * /*
	Q26.Write a program that takes in an array of integers and finds the number of occurrences of a given number in the array.

 */
public class numbofOccurnce {
	
	 
		public static void main(String[] args) 
		{
			int a[]= {1, 1, 2, 2, 2, 2, 3};
			System.out.println("given elements..");
			for(int i=0;i<a.length;i++)
			{
				System.out.print(a[i]+" ");
			}
			System.out.println();
			int count=0;
			int n=2;
			for(int i=0;i<a.length;i++)
			{
				if(a[i]==n)
				{
					
					count++;
				}
			}
			System.out.println("occurance  of number is.."+count);
		}

	}



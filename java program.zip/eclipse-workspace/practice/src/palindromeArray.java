/*
 *check number is palindrome or not if it is palindrome convert it into array and 
 *find its maximum number in array And if number is not palindrome then swap its
 *first and last number.
 */
import java.util.*;
public class palindromeArray {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter number");
		int n=sc.nextInt();
		
		int temp=n;
		int rem,rev=0;
		int c=0;
		while(temp!=0)
		{
			c++;
			rem=temp%10;
			rev= rev*10+rem;
			temp=temp/10;
	 	}
		System.out.println("convert in new Array");
	 
		if(rev==n)
			{
				int b[]= new int[c];
				int j=0;
				while(rev!=0)
				{
					rem=rev%10;
					b[j]=rem;
					j++;
					 rev=rev/10; 
				}
				
				
				for (int i = 0; i < b.length; i++) {
				
					System.out.println(b[i]);
				}
					
				 
				
				}
		
		else {
			
			
		}
		
		

	}

}

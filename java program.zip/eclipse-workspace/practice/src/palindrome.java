import java.util.Scanner;
/*
 *check number is palindrome or not if it is palindrome convert it into array and 
 *find its maximum number in array And if number is not palindrome then swap its
 *first and last number.
 */
public class palindrome
{

	
	  public int palindrom(int a)
	  {
		int rev=0,rem,temp,temp1;
		int count=0;
	    temp=a;
	    temp1=a;
	    while(temp!=0)
	    {
	    	rem=temp%10;
	    	rev=rev*10+rem;
	    	temp=temp/10;
	    	count++;
	    }
	    temp=a;
    	int max=0;
	    if(rev==a) 
	    {
	    	int b[]=new int[count];
	    	for (int i = 0; i < b.length; i++)
	    	{
	    		rem=temp%10;
		    	b[i]=rem;
		    	temp=temp/10;	
			}
	    	
	    	for (int i = 0; i < b.length; i++)
	    	{
				if(b[i]>max)
				{
					max=b[i];
				}	
	    	}
  	    	System.out.println("Element is Palindrom Max Number");
	    	return max;
	    }
		
		else
		{
			int b[]=new int[count];
	    	for (int i=b.length-1;i>=0;i--)
	    	{
	    		rem=temp1%10;
		    	b[i]=rem;
		    	temp1=temp1/10;	
			}
	    	int t;
	    	t=b[0];
	    	b[0]=b[b.length-1];
	    	b[b.length-1]=t;
	    	System.out.println("Not palindrom to Swaping Element");
	    	for (int i = 0; i < b.length; i++) 
	    	{
				System.out.println(b  [i]);
			}
		}
	    return 0;
	}
	

public static void main(String[] args)
{
	palindrome obj=new palindrome();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter The Element");
	int a=sc.nextInt();
	int k=obj.palindrom(a);
	System.out.println(k);
}
 
}

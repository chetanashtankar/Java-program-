
public class Arrayconvertin2
{
int i,j;
	public void array()
	{
		
		int a[]= {58,24,13,15,63,9,8,81,1,78};
		int b[]=new int [a.length/2];
		int c[]=new int[a.length];
		System.out.println("array element ");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		for(i=0;i<a.length/2;i++)
		{
			b[i]=a[i];
		}
		for(i=a.length/2;i<a.length;i++)
		{
			c[i]=a[i];
		}
		
		System.out.println("first araray");
		for(i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		System.out.println("second array");
		
		for(i=0;i<c.length;i++)
		{
			if(c[i]!=0)
			{
				System.out.println(c[i]);
				
			}
				}
		
		
		
		
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Arrayconvertin2 ob= new Arrayconvertin2();
		ob.array();
	}

}

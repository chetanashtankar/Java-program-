
public class one 
{
	public static void main(String[] args) {
		
		String a = "1100100011101";

        int max = 0;
        int maxIndex = 0;
        int prevIndex = -1;
        int prev2Index = -1;

        for (int i = 0; i < a.length(); i++) {
            if (a.charAt(i) == '0') {
                if (i - prev2Index > max) {
                    max = i - prev2Index;
                    maxIndex = prevIndex;
                }
                prev2Index = prevIndex;
                prevIndex = i;
            }
        }
        if (a.length() - prev2Index > max) {
            maxIndex = prevIndex;
        }

        // Find the index of the 0 after the maximum consecutive 1s
        int indexOfZeroAfterMaxOnes = maxIndex + max + 1;

        System.out.println("Original string: " + a);
        System.out.println("Index of the 0 after the maximum consecutive 1s: " + indexOfZeroAfterMaxOnes);
    }

	}



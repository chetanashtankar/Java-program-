package holopattern;
/*
 * Q21.
*
* *
*   *
*     *
*       *
*         *
* * * * * * *
 */
public class holo3 
{
	int i,j;
	int n=7;
	public void input()
	{
 
		for(i=1;i<=n;i++)
		{
				for(j=1;j<=n;j++)
			{
					if(j==1||i==7||j==i)
					{
				System.out.print("*");
					}
					else {
						
						System.out.print(" ");
					}
				 
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		
		holo3 o= new holo3();
		o.input();
	}

}

package holopattern;
/*
 *    Q24.

********
*      *
*      *
*      *
*      *
*      *
*      *
********
 */
public class holo1 
{
	int i,j;
	int n=8;
	public void input()
	{
 
		for(i=1;i<=n;i++)
		{
				for(j=1;j<=n;j++)
			{
					if(i==1|| j==1||i==8||j==8)
					{
				System.out.print("*");
					}
					else {
						
						System.out.print(" ");
					}
				 
			}
			System.out.println();
		}
	}

	public static void main(String[] args)
	{
		
		holo1 ob= new holo1();
		ob.input();
		 
	}

}

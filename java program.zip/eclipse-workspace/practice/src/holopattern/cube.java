package holopattern;
import java.util.Scanner;
public class cube
{
	 	   public static void main(String[] args) {
			     Scanner sc = new Scanner(System.in);

			    System.out.print("Input number ");
			     int x = sc.nextInt();

			     System.out.println("OUTPUT:");

			     for (int i = 1; i <= x; i++) {
			      int cube = i * i * i;
			System.out.println("Number is: " + i + "  cube of " + i + " is: " + cube);
			        }
			    }
	}


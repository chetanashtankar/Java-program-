package holopattern;
/*\
1
2 3
4 5 6
7 8 9 10
11 12 13 14 15
 */
public class pttrn1
{
	
	int i,j;
	int n=5;
	public void disp()
	{
		int temp=1;
		
		for(i=1;i<=n;i++)
		{
				for(j=1;j<=i;j++)
			{
				System.out.print(temp+" ");
				temp++;
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		
		pttrn1 ob= new pttrn1();
		ob.disp();
	}

}

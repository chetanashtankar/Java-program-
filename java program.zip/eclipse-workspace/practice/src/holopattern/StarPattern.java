package holopattern;

public class StarPattern
{
	public static void main(String[] args) {
		
		int i,j;
		
		for (i = 1; i<=5; i++) {
			
			for (j = i; j <=5; j++) 
			{
				System.out.print(" ");
				
			}
			for (int j2 = 0; j2 <i; j2++) {
				
				System.out.print("*");
			}
			System.out.println();
			
		}
	}

}

package holopattern;

public class number {

	public static void main(String[] args) {
	 
		
		int n=5;
		
		int i,j;
		for(i=1;i<=n;i++)
		{
			int a=0;
			int b=1;
			int c;
			for(j=1;j<=i;j++)
			{
				c=a+b;
				System.out.print(c+" ");
			  a=b;
			  b=c;
			
			 		
			}
			System.out.println();
		}
	}

}

package interviewQuestion;
import java.util.Scanner;

public class Strong_number
{

	public int input(int n)
	{
		int fact;
		int original=n;
		int sum=0;
		while(n>0)
		{
			int rem=n%10;
			fact=1;
			for(int i=1;i<=rem;i++)
			{
				fact=fact*i;
			}
			sum=sum+fact;
			n=n/10;
			
			
		}
		
		if(sum==original)
		{
			System.out.println("it is strong number");
		}
		else {
			System.out.println("not strong number");

		}
		return original;
		
		
	}
	public static void main(String[] args)
	{
	 Scanner sc= new Scanner(System.in);
	 
	 System.out.println("enter number");
	 int n=sc.nextInt();
	 Strong_number ob= new Strong_number();
	 System.out.println(ob.input(n));
		
	}

}

package interviewQuestion;
/*
 * 2. How u print second last element in array

 */
public class PrintSec_last {

	public static void main(String[] args) {

		int a[]= {10,20,30,40,50,60};
		
		System.out.println("Array element");
		
		for (int i = 0; i < a.length; i++) {
			
			System.out.println(a[i]);
		}
		int b=a.length;
		 		System.out.println("Second last element : "+a[b-2]);
		 

	}

}

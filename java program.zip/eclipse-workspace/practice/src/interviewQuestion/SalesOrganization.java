package interviewQuestion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class SalesExecutive1 {
    String employeeID;
    double salesHandled;
    int numSubordinates;

    public SalesExecutive1(String employeeID, double salesHandled, int numSubordinates) {
        this.employeeID = employeeID;
        this.salesHandled = salesHandled;
        this.numSubordinates = numSubordinates;
    }
}

public class SalesOrganization {

    public static List<String> lineWithHighestSales(List<SalesExecutive1> salesExecutives, double bonusAmount) {
        Map<String, Double> budgetEfficiencyReward = new HashMap<>();
        Map<String, Double> salesEfficiencyReward = new HashMap<>();

        for (SalesExecutive1 exec : salesExecutives) {
            double share = (bonusAmount * 0.25) / (exec.numSubordinates + 1);
            budgetEfficiencyReward.put(exec.employeeID, share);
        }

        double totalSales = salesExecutives.stream().mapToDouble(exec -> exec.salesHandled).sum();
        for (SalesExecutive1 exec : salesExecutives) {
            double share = (bonusAmount * 0.75) * (exec.salesHandled / totalSales);
            salesEfficiencyReward.put(exec.employeeID, share);
        }

        List<String> result = new ArrayList<>();
        for (SalesExecutive1 exec : salesExecutives) {
            double totalBonus = budgetEfficiencyReward.get(exec.employeeID) + salesEfficiencyReward.get(exec.employeeID);
            result.add(exec.employeeID + "\nBonus\n" + (int) totalBonus);
        }

        return result;
    }

    public static void main(String[] args) {
        List<SalesExecutive1> salesExecutives = List.of(
                new SalesExecutive1("SE1", 5.5, 2),
                new SalesExecutive1("SE2", 5.6, 1),
                
                new SalesExecutive1("SE5", 7.7, 3),
                new SalesExecutive1("SE9", 4.4, 2),
                new SalesExecutive1("SE16", 5.2, 1),
                new SalesExecutive1("SE17", 9.9, 0)
        );

        double bonusAmount = 3000000;

        List<String> result = lineWithHighestSales(salesExecutives, bonusAmount);

        for (String line : result) {
            System.out.println(line);
        }
    }
}

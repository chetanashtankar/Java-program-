package interviewQuestion;
/*
 * 1. Write a program that creates two threads, 
 * one of which counts up to 100 and the other counts down from 100.
 *  Print out the values each thread counts to.

2
 */
class abf extends Thread{

	@Override
	public void run() {
		System.out.println("counts upto 100");
		
		for(int i=1;i<=100;i++)
		{
			System.out.print(i+" ");
		}
		 
	}
	
	
	
}

public class TwoThread extends Thread{
	public void run() {
		System.out.println();
		System.out.println("counts down  from 100");
		for(int i=100;i>=1;i--)
		{
			System.out.print(i+" ");
		}
	}

	public static void main(String[] args) {

		
abf t1= new abf();
t1.start();
try {
	t1.join();
}catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}

TwoThread t2= new TwoThread();
t2.start();
try {
	t2.join();
}catch (Exception e) {
	e.printStackTrace();
	}
	}

}

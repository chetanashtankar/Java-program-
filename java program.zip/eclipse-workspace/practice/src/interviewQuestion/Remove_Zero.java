package interviewQuestion;
/*
 * 5) Remove Leading Zeros From String in Java

Input : 00000123569
Output: 123569

Input: 000012356090
Output: 12356090
 */
public class Remove_Zero {

	public static void main(String[] args) {
		
		
		String s="00000123569";
		System.out.println("String :-"+s);
		
		char a[]=s.toCharArray();
		
		System.out.println("remove Zero from string");
		for (int i = 0; i < a.length; i++) {
			int  c=0;
			if(a[i]=='0')
			{
				c++;
			}
			
			
		if(c==0)
		{
			System.out.print(a[i]);
		}
		}
	}

}

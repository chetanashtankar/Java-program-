package interviewQuestion;

public class maxNumbdigit 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=12497;
		
		int lastTwoDigit=n%100;
		int reversedLastTwoDigit=(lastTwoDigit%10)*10+(lastTwoDigit/10);
		
		int restOfnumber= n/100;
		int allnumb=restOfnumber*100+reversedLastTwoDigit;
		
	
		System.out.println(allnumb);
		
	}

}

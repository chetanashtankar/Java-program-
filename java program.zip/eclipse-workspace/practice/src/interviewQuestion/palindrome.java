package interviewQuestion;
/*
 * WAP to check palindrom number using return type 
 * with arguments method
 */
import java.util.Scanner;
public class palindrome 
{
	
	
	
	public int input(int n)
	{
		
		int rem;
		int rev=0;
		int temp=n;
		
		while(temp!=0)
		{
			rem=temp%10;
			rev=(rev*10)+rem;
			temp=temp/10;
			
		}
		if(rev==n)
		{
			System.out.println("it is palindrome number");
		}
		
		else {
			System.out.println("it is not palindrome number");
			
			
		}
		
		return n;
		
	}

	public static void main(String[] args) {

		
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		palindrome ob= new palindrome();
		System.out.println(ob.input(n));
		
		
	}
	
	

}

package interviewQuestion;
/*
 * Write a Java program to find the sum of the prime numbers
 *  between 100 and 200, but only consider the prime numbers
 *   that have a digit sum greater than 10. Print the sum 
 *   of those prime numbers.
 */
import java.util.Scanner;

public class primenumber_sum10
{
	
public void input()
{
   int f=100;
   int l=200;
   
   int i=f;
   int c=0;
   int d=0;
   
   int sum=0;
   int x=0;
   int p[]=new int[f];
   
   while(i<l)
   {
	   int j=2;
	   c=0;
	   
	   while(j<i)
	   {
		   if(i%j==0)
		   {
			   c++;
			   d++;
			   break;
			   
		   }
		   j++;
		   
	   }
	   
	   if(c==0 && i!=1)
	   {
		   p[x++]=i;
		   
	   }
	   i++;
   }
   
   
   for(int j=0;j<p.length;j++)
   {
	   if(p[j]!=0)
	   {
		   System.out.print(p[j]+" ");
	   }
   }
System.out.println();

for(i=0;i<p.length;i++)
{
   int rem=0;
   int temp=p[i];
   while(temp!=0)
   {
	   rem=temp%10;
	   sum=sum+rem;
	   temp=temp/10;
   }
   
   if(sum>10)
   {
	   if(p[i]!=0)
	   {
		   System.out.println(p[i]);
	   }
   }
   
   sum=0;

}
}

	public static void main(String[] args)
	{
	 
		primenumber_sum10 ob= new primenumber_sum10();
		ob.input();
	}

}

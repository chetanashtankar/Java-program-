package interviewQuestion;
/*
 * Write a program to find the largest palindrome number 
 * that is a product of two 3-digit numbers.
 */
import java.util.Scanner;
public class largestPalindrome_product
{
 Scanner sc= new Scanner(System.in);
 
	public void input()
	{
		
	int n=sc.nextInt();
	
	int rem,rev=0;
	
	int temp=n;
	
	
	while(temp!=0)
	{
		rem=temp%10;
		rev=rev*10+rem;
		temp=temp/10;
	}
	if(rev==n)
	{
		System.out.println(n);
	}
	}
	public static void main(String[] args) 
	{
	 
		largestPalindrome_product ob= new largestPalindrome_product();
		ob.input();
	}

}

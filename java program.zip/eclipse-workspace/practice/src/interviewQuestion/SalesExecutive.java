package interviewQuestion;

public class SalesExecutive {

}

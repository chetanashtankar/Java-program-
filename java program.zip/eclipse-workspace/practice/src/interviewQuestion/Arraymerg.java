package interviewQuestion;

import java.util.Arrays;

/*
 * arr1[]={1,2,3,4,5}
arr2[]={10,11,12,13,14}

output: {1,14,2,13,3,12,4,11,5,10}
 */
public class Arraymerg {
	
	public void disp()
	{
		int a[]= {1,2,3,4,5};
		int b[]= {10,11,12,13,14};
		System.out.println("First array");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("Second  array");
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
		int c[]=new int[a.length+b.length];
		
		int l=0,m=b.length-1;
		System.out.println("merge two array");
		for(int i=0;i<a.length;i++)
		{
			 c[l++]=a[i];
			 c[l++]=b[m];
			 m--;
			 
		 
			 		}
		
	
	for(int i=0;i<c.length;i++) {
		
		System.out.println(c[i]);
	}	}
	public static void main(String[] args) {

		Arraymerg ob= new Arraymerg();
		
		ob.disp();
	}

}

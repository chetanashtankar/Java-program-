package interviewQuestion;
/*
 * Write a program to calculate the sum of the digits of a
 *  given number until the sum becomes a single digit.

Enter a number: 12345
Sum of digits until a single digit: 6
 */
import java.util.Scanner;
public class sumOfDigit_single
{
	public void sum()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		
		long n=sc.nextInt();
       long sum=0,rem;
       
       while(n!=0)
       {
    	  rem=n%10;
    	  sum=sum+rem;
    	  n=n/10;
       }
	System.out.println(sum);
	long sum1=0,rem1;
	while(sum != 0)
	{
		rem1= sum % 10;
		sum1=sum1+rem1;
		sum= sum/10;
	}
	if(sum1 > 9)
	{
		long sum2=0,rem2;
		while(sum1 != 0)
		{
			rem2= sum1 % 10;
			sum2=sum2+rem2;
			sum1= sum1/10;
		}
		System.out.println("Final Sum Of  Single Digit : "+sum2);
	}
	
	System.out.println("Final Sum Of  Single Digit : "+sum1);
	}

	public static void main(String[] args)
	{
		sumOfDigit_single ob= new sumOfDigit_single();
		ob.sum();
		
	}

}

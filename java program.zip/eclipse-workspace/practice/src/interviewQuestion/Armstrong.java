package interviewQuestion;

import java.util.Scanner;

public class Armstrong
{
	int rem;
	int rev=0;
	public int input(int n)
	{
		
	int temp=n;
	while(temp!=0)
	{
		 
	rem=temp%10;
	rev=rev+rem*rem*rem;
	temp=temp/10;
	
	}
	if(n==rev)
	{
		System.out.println("Armstrong number");
	}
	else {
		System.out.println("not Armstrong number");
	}
	 
	return n;
	
	}
	public static void main(String[] args) {
	 
		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		Armstrong ob= new Armstrong();
		System.out.println(ob.input(n));
		
	}

}

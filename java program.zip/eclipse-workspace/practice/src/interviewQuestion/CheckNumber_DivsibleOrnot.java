package interviewQuestion;

import java.util.Scanner;

/*
 * 3. Check whether number is Divisible by 2 and 5,

 */
public class CheckNumber_DivsibleOrnot {

	public static void main(String[] args) {

Scanner sc= new Scanner(System.in);

System.out.println("enter number");

int a= sc.nextInt();

if(a%2==0 && a%5==0)
{
  System.out.println("Number is divisible by 2 and 5");	


}
else {
	
	System.out.println("it is not divisible by 2 and 5");
}

	
	}

}

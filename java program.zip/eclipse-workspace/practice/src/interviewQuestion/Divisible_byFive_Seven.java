package interviewQuestion;
/*
 * Divisible by 5 & 7
 */
import java.util.Scanner;

public class Divisible_byFive_Seven {
	public void disp()
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter number");
		
		 
		for(int i=1;i<=100;i++)
		{ 
			if(i%5==0)
			{
				System.out.println("boo="+i);
				}
			if(i%3==0) 
			{
				System.out.println("foo="+i);
				
			}
			
		else if(i%5==0 && i%7==0)
		{ 
			System.out.println("FooooBoo:"+i);
		}
		 
	}
	}
	public static void main(String[] args) {
	
		Divisible_byFive_Seven ob= new Divisible_byFive_Seven();
		ob.disp();
		
	}

}

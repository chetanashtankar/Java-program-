package interviewQuestion;
 
import java.util.Scanner;

public class WithoutMult {
/*
 * 1. Multiplication of two number without using * operator

 */
	public static void main(String[] args) {

Scanner sc= new Scanner(System.in);

System.out.println("enter first number");
int a=sc.nextInt();

System.out.println("enter second number");
int b=sc.nextInt();
int sum=0;
for(int i=1;i<=a;i++)
{
	sum=sum+b;


}
System.out.println("Multiplication of two number without * is : "+sum);

	}

}

package interviewQuestion;

import java.util.Scanner;

public class prime_number 
{
	public int input(int n)
	{ 
		 
		int i=2;
		int c=0;
		while(i<n)
			{
				if(n%i==0)
				{
					c++;	
				}
			i++;
			}
	if(c==0 && i!=0)
		{    
			System.out.println("number is prime");
		}
		else {
			System.out.println("not prime");
		}
		return n;
		}
		 

	public static void main(String[] args)
	{

		Scanner sc= new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		prime_number ob= new prime_number();
		System.out.println(ob.input(n));
		
	 
	}

}

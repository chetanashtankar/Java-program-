package interviewQuestion;
/*
 * 
2. Write a program that uses multiple threads to calculate the sum of an array of numbers.
 Each thread should sum a portion of the array, and then the main thread should add up the 
 individual sums to get the total sum.
*/

class thread1 extends Thread{
	
	int a[]= {11,12,13,14,15};
	static int sum=0;
	static int sum1=0;
	
	public void run()
	{
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];
		}
		System.out.println("first thread sum:-"+sum);
	}
	
}

class thread2 extends thread1{
	
	public void run() {
	
		for(int i=a.length/2;i<a.length;i++)
		{
			sum1=sum1+a[i];
		}
		System.out.println("second thread sum:-"+sum1);
	
	
	}
}
public class SumOftwoThread {

	
	public static void main(String[] args) {
		thread1 t1=new thread1();
		thread2 t2= new thread2();
		
try{
	t1.start();
	t1.join();
	t2.start();
	t2.join();
}catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
finally {
	
	System.out.println("total sum of two thread:"+(thread1.sum+thread2.sum1));
	}

}
}

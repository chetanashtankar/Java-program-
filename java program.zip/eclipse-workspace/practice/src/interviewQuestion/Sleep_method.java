package interviewQuestion;
 
public class Sleep_method   extends Thread{

	public void run() {
		System.out.println("using sleep method prints hello world");
		for (int i = 1; i<=5; i++) {
			
			
			try
			{
				
				Thread.sleep(1000);
				System.out.println("Hello World");
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		
	}
	
	public static void main(String[] args) {
		Sleep_method t1= new Sleep_method();
		t1.start();

	}

}

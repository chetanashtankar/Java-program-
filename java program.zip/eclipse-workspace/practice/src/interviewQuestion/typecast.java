package interviewQuestion;

public class typecast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12345;
		System.out.println("given number :"+n);
		
		int rev=0;
		int rem;
		while(n!=0)
		{
			rem=n%10;
			float a=(float)rem;
		//	System.out.println(a);
		    rev=rev*10+rem;
			n=n/10;
			
			
		}
		
		while(rev!=0)
		{
			rem=rev%10;
			float a=(float)rem;
			System.out.println(a);
		   
			rev=rev/10;
			
			
		}
		
	

	}

}

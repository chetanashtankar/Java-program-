/*
 * Q1.Write a Java program to find the frequency of each number in an array and check if the frequency
 *  is greater than three. If the frequency is greater than three, 
 *  create a new array containing only those elements

1) WAP to print the palindrom series between 100 to 500 and store into an array now remove all the element from array who's sum of the number above 10.
 */
import java.util.Scanner;
import java.util.*;
public class freq 
{
	
	 public static int[] filterNumbersByFrequency(int[] arr) {
		 
		 for(int i=0;i<arr.length;i++)
		 {
			 System.out.println(arr[i]);
		 }
	        int[] frequency = new int[arr.length];
	        int uniqueCount = 0;

	        // Count the frequency of each number
	        for (int i = 0; i < arr.length; i++) {
	            int count = 1;
	            for (int j = i + 1; j < arr.length; j++) {
	                if (arr[i] == arr[j]) {
	                    count++;
	                    // Mark the repeated element as visited
	                    frequency[j] = -1;
	                }
	            }
	            // Mark the unique element's frequency
	            if (frequency[i] != -1) {
	                frequency[i] = count;
	                uniqueCount++;
	            }
	        }

	      
	        // Create a new array to store elements with frequency greater than three
	        int[] filteredArray = new int[uniqueCount];
	        int index = 0;
	        for (int i = 0; i < arr.length; i++) {
	            if (frequency[i] > 3) {
	                filteredArray[index] = arr[i];
	                index++;
	            }
	        }

	        return filteredArray;
	    }

	    public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 2, 3, 3, 3, 5, 5, 5, 5, 6, 6, 6, 6, 6};
	        int[] filteredArray = filterNumbersByFrequency(arr);

	        // Print the filtered array
	        System.out.println(" new  Array store in  with Frequency Greater Than Three:");
	        for(int a:filteredArray)
	        {
	        	if(a!=0)
	        	System.out.println(a);
	        }
	    }
}
	 

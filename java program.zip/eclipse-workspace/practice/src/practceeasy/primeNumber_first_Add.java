package practceeasy;
import java.util.Scanner;
/*
 * 3. Write a Java program to find the sum of the prime numbers between 30 and 50, 
 * but only consider the first three prime numbers in the range. Print the sum of those
 *  three prime numbers.

 */
public class primeNumber_first_Add
{

	public static void main(String[] args)
	{
		 
Scanner sc= new Scanner(System.in);
		
		System.out.println("enter first number");
		int f= sc.nextInt();
		
		System.out.println("enter second number");
		int l= sc.nextInt();
		int c1=0;
		int sum=0;
		System.out.println("first three prime numbers ");
		for(int i=f;i<l;i++)
		{
			 
			int c=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					c++;
					break;
				}
			}
				if(c==0 && i!=0)
				{
					System.out.println(i);
					  sum=sum+i;
					c1++;
				}
				if(c1==3)
				{
					break;
				}
			
			
			
		}
		
		System.out.println("prime series first three number sum="+sum);
		
		
	}

}

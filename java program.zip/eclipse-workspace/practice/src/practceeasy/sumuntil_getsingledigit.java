package practceeasy;
/*
 * Write a program to calculate the sum of the digits of a given 
 * number until the sum becomes a single digit.

Enter a number: 12345
Sum of digits until a single digit: 6

Explanation:

In this case, the input number is 12345. 
The program calculates the sum of its digits (1 + 2 + 3 + 4 + 5 = 15)
, which is not a single digit. It then calculates the sum of the digits of 15 (1 + 5 = 6), which is a single digit. Therefore, the output is 6.

 */
import java.util.Scanner;
public class sumuntil_getsingledigit {

	public static void main(String[] args)
	{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The number");
		long a = sc.nextLong();
		long sum=0,rem;
		while(a != 0)
		{
			rem= a % 10;
			sum=sum+rem;
			a= a/10;
		}
		System.out.println(sum);
		long sum1=0,rem1;
		while(sum != 0)
		{
			rem1= sum % 10;
			sum1=sum1+rem1;
			sum= sum/10;
		}
		if(sum1 > 9)
		{
			long sum2=0,rem2;
			while(sum1 != 0)
			{
				rem2= sum1 % 10;
				sum2=sum2+rem2;
				sum1= sum1/10;
			}
			System.out.println("Final Sum Of  Single Digit : "+sum2);
		}
		
		System.out.println("Final Sum Of  Single Digit : "+sum1);
	}
}

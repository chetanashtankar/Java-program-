package practceeasy;

class xyz {
	
	
	
	  void disp()
	{
		System.out.println("hii ");
	}
	  
	  void show()
	  {
		  
		  System.out.println("heloo");
	  }
}


class yxz extends xyz
{

	@Override
	void disp() {
		 System.out.println("by");
	}

	@Override
	void show() {
		System.out.println("    no byr");
	}
	



}




public class method_overriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		yxz ob = new yxz();
		ob.disp();
		ob.show();

	}

}

package practceeasy;
/*
 * WAP to check palindrom number using return type 
 * with arguments method
 */
public class practice
{

	public static void main(String[] args)
	{
		
	}

}

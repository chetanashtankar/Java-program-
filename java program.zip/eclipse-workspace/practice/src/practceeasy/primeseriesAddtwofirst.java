package practceeasy;
import java.util.Scanner;
/*
 * 2. Wap to print the prime series between 10-20, but only till two two digit
 *  from starting and find the sum of those two numbers.
  
   input : a=10 , b=20;

   output: 11, 13 
          Sum= 24
 */
public class primeseriesAddtwofirst
{
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter first number");
		int f= sc.nextInt();
		
		System.out.println("enter second number");
		int l= sc.nextInt();
		
		int c1=0;
		int sum=0;
		
		for(int i=f;i<l;i++)
		{
			 
			int c=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					c++;
					break;
				}
			}
				if(c==0 && i!=0)
				{
					System.out.println(i);
					  sum=sum+i;
					c1++;
				}
				if(c1==2)
				{
					break;
				}
			
			
			
		}
		
		System.out.println("prime series first and second number sum="+sum);
		
		
	}

}

package practceeasy;
/*
 * Write a program that takes in an array of integers and removes all the duplicates in the array, 
 * returning a new array with only the unique values.
 */
 import java.util.Scanner;
public class duplicateArrayele_innewArray
{
	
	public void input()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		int i,j;
		System.out.println("enter Array");
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					a[i]=0;
				}
			}	 
		}
		
		System.out.println("remove duplicate  ");
		
		int b[]=new int[a.length];
		
		for(i=0;i<a.length;i++)
		{
			if(a[i]==0)
			{
				continue;
			}
			b[i]=a[i];
			System.out.println(a[i]);
		}
		System.out.println("store in new Array");
		for(i=0;i<b.length;i++)
		{
			if(b[i]!=0)
			{
			System.out.println(b[i]);
			}
		}
		
	}

	public static void main(String[] args)
	{
		
		duplicateArrayele_innewArray ob= new duplicateArrayele_innewArray();
		ob.input();
	}

}

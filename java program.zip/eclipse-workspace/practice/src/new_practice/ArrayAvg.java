package new_practice;

import java.util.Scanner;

public class ArrayAvg {

	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter the size");
		
		int size=sc.nextInt();
		
		int a[]= new int[size];
		
		System.out.println("enter the Array");
		
		for (int i = 0; i < a.length; i++) {
			
			a[i]=sc.nextInt();
			
		}
		int sum=0;
		int avg=0;
		
		for (int i = 0; i < a.length; i++) {
		
			sum= sum+a[i];
			avg=sum/a.length;
			
		}
		
		System.out.println("sum="+sum);
		System.out.println("avg="+avg);
		
		
	}
}

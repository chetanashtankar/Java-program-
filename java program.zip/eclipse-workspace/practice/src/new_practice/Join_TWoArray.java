package new_practice;

import java.util.Iterator;
import java.util.Scanner;

public class Join_TWoArray {

	public static void main(String[] args) {


		Scanner sc= new Scanner(System.in);
		
		int size= sc.nextInt();
		
		int a[]= new int[size];
		int b[]= new int[size];
		System.out.println("enter array element");
		
		for (int i = 0; i < a.length; i++) {
			
			a[i]=sc.nextInt();
		}
		
		System.out.println("enter secnd Array");
		
		
		for(int i=0;i<b.length;i++)
		{
			b[i]=sc.nextInt();
		}
		
		int c[]= new int[a.length+b.length];
		System.out.println("join two array ");
		
		for (int i = 0; i < a.length; i++) {
			
			c[i]=a[i];
		}
		
		
	for (int i = 0;i<b.length;i++) {
			
			c[a.length+i]=b[i];
		}
	
	
	
	for (int i = 0; i < c.length; i++) {
		
		
		System.out.println(c[i]);
	}
		
		
		
		
	}
	

}

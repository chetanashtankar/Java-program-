package new_practice;

public class FibonacciTriangle {
	     public static void main(String[] args) {
	        int n = 10; 
        int a = 0, b = 1, c;

	        for (int i = 0; i < n; i++) {
	            a = 0;
	            b = 1;
	            System.out.printf("%" + (n - i) * 2 + "s", ""); 

	            for (int j = 0; j <= i; j++) {
	                System.out.printf("%4d", a);

	                c = a + b;
	                a = b;
	                b = c;
	            }

	            System.out.println();
	        }
	    }
	}




package new_practice;

import java.util.Scanner;

public class palindromeNumb {

	public static void main(String[] args) {

 Scanner sc= new Scanner(System.in);
  System.out.println("emter number");
  
  int n=sc.nextInt();
  
  int rem;
  int rev=0;
  int temp=n;
  while(temp!=0)
  {
	  
	  rem=temp%10;    
	  rev= rev*10+rem;
	  temp=temp/10;
	  
  }
  
  if(n==rev)
  {
	  System.out.println("String is palindrome");
  }
  


	}

}

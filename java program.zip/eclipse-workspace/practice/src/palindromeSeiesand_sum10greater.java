
public class palindromeSeiesand_sum10greater {

}

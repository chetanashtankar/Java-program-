
public class Assgnment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {8, 3, 1, 2};
		int i,temp,j,mul,sum=0,max=0;
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("Multiplying element by there index");
		temp=a[0];
		for(i=1;i<=4;i++)
		{
		  for(i=0;i<a.length-1;i++)
		  {
			a[i]=a[i+1];
		  }
		   a[a.length-1]=temp;
		    for(i=0;i<a.length;i++)
		     {
			  mul=a[i]*i;
			  sum=sum+mul;
			   if(sum>max)
			   {
			   	max=sum;
			   }
		   }
		}
	
		System.out.println("Multiplication and sum="+max);
	}
	
	}



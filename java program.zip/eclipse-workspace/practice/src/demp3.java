import java.util.Scanner;
public class demp3
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int i=sc.nextInt();
		System.out.println("enter a second");
		int n=sc.nextInt();
		int sum=1;
		int sum1=0;
		int rem=0;
		
		int tem=i;
		while(i<n)
		{
			
			int count=0;
			int j=2;
			while(j<i)
			{
				if(i%j==0)
				{
					
					count++;
					
				}
				j++;
			}
			if(count==0)
			{
				
				System.out.println(i);
				int rev=0;
				while(i!=0)
				{
					int rem1=i%10;
					  rev=rev*10+rem1;
						
					i=i/10;
					sum1=sum1+rem1;
					
					 
				}
				
			 
			}
			i++;
		
			
			
					
		}
		System.out.println(sum1);
		
		
	 	
		
		
	}

}



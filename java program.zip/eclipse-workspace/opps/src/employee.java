/*
 * Create a class Employee with private attributes name, id, and
 *  salary. 
 *  Implement getter and setter methods to access and modify these 
 *  attributes.

 */
class emp{
	
	private int id;
	private String name;
	private double salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
}
public class employee {

	public static void main(String[] args) {
		 
	
		emp ob= new emp();
		   ob.setId(1);
	       
	     ob.setName("Nehal");
	     	
	     ob.setSalary(120000);
	     System.out.println("Employee details");
	       
	     System.out.println("emp id-"+ob.getId());
	     System.out.println("emp name -"+ob.getName());
	     System.out.println("emp salary -"+ob.getSalary());
	     
	
	
	}

}

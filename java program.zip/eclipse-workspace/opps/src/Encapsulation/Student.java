package Encapsulation;

class student1
{
private int Roll_numb;
private String Name;
private int marks;
private String city;


public int getRoll_numb() {
	return Roll_numb;
}
public void setRoll_numb(int roll_numb) {
	Roll_numb = roll_numb;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
  



}



public class Student 
{

	public static void main(String[] args) 
	{
		student1 ob= new student1();
		ob.setRoll_numb(123);
		ob.setName("Nehal Dafre");
		ob.setMarks(230);
		ob.setCity("pune");
		
		
		System.out.print(ob.getRoll_numb() +"   b "+ob.getName());
	//	System.out.println(ob.getName());
		System.out.println(ob.getMarks());
		System.out.println(ob.getCity());
		
		System.out.println();
		student1 ob2= new student1();
		ob2.setRoll_numb(124);
		ob2.setName("chetan");
		ob2.setMarks(240);
		ob2.setCity("Nagpur");
		
		
		System.out.println(ob2.getRoll_numb());
		System.out.println(ob2.getName());
		System.out.println(ob2.getMarks());
		System.out.println(ob2.getCity());
		
		System.out.println();
		
		student1 ob3= new student1();
		ob3.setRoll_numb(125);
		ob3.setName(" prakash");
		ob3.setMarks(235);
		ob3.setCity("wardha");
		
		
		System.out.println(ob3.getRoll_numb());
		System.out.println(ob3.getName());
		System.out.println(ob3.getMarks());
		System.out.println(ob3.getCity());
		
		
		System.out.println();
		
		student1 ob4= new student1();
		ob4.setRoll_numb(123);
		ob4.setName("akash");
		ob4.setMarks(223);
		ob4.setCity("XYZ");
		
		
		System.out.println(ob4.getRoll_numb());
		System.out.println(ob4.getName());
		System.out.println(ob4.getMarks());
		System.out.println(ob4.getCity());
		
	}

}

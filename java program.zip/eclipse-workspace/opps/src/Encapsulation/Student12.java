package Encapsulation;

class Employee
{
	private int  id;
	private String name;
	private int salary;
	private String city;
	
	public Employee(int id, String name, int salary, String city) 
	{
		 
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.city = city;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getSalary() {
		return salary;
	}

	public String getCity() {
		return city;
	}
}
public class Student12
{

	public static void main(String[] args)
	{ 
		Employee ob= new Employee(1,"Nehal",40000,"pune");
		 System.out.println(ob.getId()+" \t"+ ob.getName()+"\t"+ob.getSalary()+"\t"+ob.getCity());
	
		 Employee ob1= new Employee(2,"Chetan",50000,"Mumbai");
		 
			System.out.println(ob1.getId()+" \t"+ ob1.getName()+"\t"+ob1.getSalary()+"\t"+ob1.getCity());
			
			Employee ob2= new Employee(3,"Manthan",45000,"Nagpur");
			 
			System.out.println(ob2.getId()+" \t"+ ob2.getName()+"\t"+ob2.getSalary()+"\t"+ob2.getCity());

			Employee ob3= new Employee(4,"Shubham",60000,"Delhi");
			 
			System.out.println(ob3.getId()+" \t"+ ob3.getName()+"\t"+ob3.getSalary()+"\t"+ob3.getCity());

			Employee ob4= new Employee(5,"akash",55000,"Wardha");
			 
			System.out.println(ob4.getId()+" \t"+ ob4.getName()+"\t"+ob4.getSalary()+"\t"+ob4.getCity());

	}
	

}

package polymorphism;

public class method_overloading 


{
	
	public void disp(int a,int b)
	{
		System.out.println(a+"\t"+b);
		
	}
    
	public void disp( int a,int b,int c)
	{
		
		System.out.println(a+"\t"+b+"\t"+c);
		
	}
	
	public void disp(double a)
	{
		this.disp(10, 17, 19);
		this.disp(10, 20);
		System.out.println(a );
		
	}
}

class overriiding extends method_overloading
{

	@Override
	public void disp(int a, int b) {
		System.out.println("parent class");
	 
	}

	@Override
	public void disp(int a, int b, int c) {
	 
		System.out.println("parent class 1");
		
	}

	@Override
	public void disp(double a) {
		 
		
		System.out.println("parent class 3");
		
	}
	 
	}

class main_method{
	public static void main(String[]args)
	{
		overriiding ob= new overriiding();
		ob.disp(1.3);
		ob.disp(12, 13);
		ob.disp(1, 10, 20);
	}
}

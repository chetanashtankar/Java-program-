package polymorphism;

import java.util.Scanner;


class B 
{
  Scanner sc= new Scanner(System.in);

  public void show()
  {
	 int  n=2;
	 int table=1;
	 System.out.println(" 2 table");
	  for(int i=1;i<=10;i++)
	  {
		  
		  table =i*n;
		  System.out.println(table);
		  
	  }
	   
	  
  }
}


class c extends B
{
	
	 public void show()
	  {
		 super.show();
		 int  n=3;
		 int table=1;
		 System.out.println(" 3 table");
			
		  for(int i=1;i<=10;i++)
		  {
			  
			  table =i*n;
			  System.out.println(table);
				 
			  
		  }
		  
		  
	  }


}
public class print_table

{
	public static void main(String[] args) {
		
	 
	c ob= new c();
	ob.show();
	
	
	}
	

}

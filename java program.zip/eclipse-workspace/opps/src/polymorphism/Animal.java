package polymorphism;
/*
 * 1. Write a Java program to create a base class Animal (Animal Family) with a method called Sound().
 *  Create two subclasses Bird and Cat. Override the Sound() method in each subclass to make a specific 
 *  sound for each animal.


 */


 class Animal12
{
  public void sound()
  {
	  
	  System.out.println("The animal makes a sound");
	  
  }
}

class Bird extends Animal12
{
	
	public void sound()
	  {
		  
		System.out.println("the birds is chikchik");  
		  
	  }
	
}

class  Cat extends Animal12
{
	
	public void sound()
	  {
		  
		System.out.println("the cat is myav");  
		  
	  }
}

public class Animal
{
	public static void main(String[] args)
	{
		Animal12 animal=new Animal12();
		animal.sound();
		
		Bird b= new Bird();
		b.sound();
		
		Cat ob= new Cat();
		ob.sound();
	}

}

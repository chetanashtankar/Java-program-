package polymorphism;

public class main_methodOvrloading


{
	 
	public static void main(String name)
	{
		
		System.out.println(name);
	}
	
	public static void main(int a)
	{
		
		System.out.println(a);
	}
	
	
	
	
	 public static void main(String[] args)
	 {
    
		 
		 System.out.println("its main method");
		 main_methodOvrloading.main("pune");
          main(20);
          
	 }
   
}

package abstraction;

public class demo1 extends calculator_1

{

	 
	public void sum()
	{
		 int a=30;
		 int b=20;
		 System.out.println(a+ " +"+b+"="+ (a+b));
	}

	 
	public void sub()
	{
		 int a=30;
		 int b=20;
		 System.out.println(a+" - " +b+" ="+(a-b));
	
	}

	@Override
	public void multiply() {
		 int a=30;
		 int b=20;
		 System.out.println(a+ " * "+b+"="+ (a*b));
	}

	@Override
	public void divide() {
		 int a=30;
		 int b=10;
		 System.out.println(a+ " / "+b+"="+ (a/b));
	
	}
	
	

}

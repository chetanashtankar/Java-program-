package abstraction;
import java.util.Scanner;
abstract public class calculator_1 
{

	 
		  abstract public void sum();
		 	abstract public void sub();
		 	abstract public void multiply();
		 	abstract public void divide();
		 	
		
	public static void main(String[] args) {
		 
		demo1 ob= new demo1();
		ob.sum();
		ob.sub();
		ob.multiply();
		ob.divide();
	}

}

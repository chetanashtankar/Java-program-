package abstraction;
/*
 * 1. Write a Java program to create an abstract class Animal with an abstract
 *  method called sound(). Create subclasses Lion and Tiger that extend
 *   the Animal class and implement the sound() method to make a specific 
 *   sound for each animal.

 */
abstract class Animal1{
	 
	abstract void sound();
	
}
	class lion extends Animal1{

		@Override
		void sound() {
			 
			System.out.println("lion roar");
		}
		
	}
	
	class Tiger extends Animal1{

		 
		void sound() {
			 
			System.out.println("tiger grawls");
			
		}
		
		
		
	}
	abstract public class Animal 
	{

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		lion ob= new lion();
		ob.sound();
		Tiger ob1=new Tiger();
		ob1.sound();
		
	}

}

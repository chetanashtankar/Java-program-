package abstraction;
import java.util.*;
abstract public class abstractcheckpal 

{
	
	 abstract public void palcheck();
	 	abstract public void armstrongcheck();
	 	abstract public void palseries();
	 	abstract public void armstormSeries();
	 	abstract public void primeseries();
	 	
	 	abstractcheckpal(){
	 		
	 	}
	 	
	 	public static void main(String[] args) {
	 		
	 		Scanner sc=new Scanner(System.in);
			char ch;
			do
			{
				allseries ob= new allseries();
		 		ob.menu();
				 
			System.out.println("enter your choice  no=");
			int n=sc.nextInt();
			
			if(n==1)
				ob.palcheck();
			
			else if(n==2)
				ob.armstrongcheck();
			
			else if(n==3)
				ob.palseries();
			
			else if(n==4)
				ob.armstormSeries();
			
			else if(n==5)
				
				ob.primeseries();
			else
			{
				System.out.println("please input valid option......");
			}
			System.out.println("DO YOU WANT TO CONTINUE, PLEASE PRESS Y");
			 ch=sc.next().charAt(0);
			
			
			
			}while(ch=='y');
	 		 
		}
	

}



package abstraction;

import java.util.Scanner;

public class interface_callling {

	public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
		char ch;
		do
		{
		
			interface_implements ob= new interface_implements();
				ob.menu();
		
		System.out.println("enter your choice  no=");
		int n=sc.nextInt();
		
		if(n==1)
		ob.palindrome();
		
		else if(n==2)
		ob.prime();
		
		 
		
		else
		{
			System.out.println("please input valid option......");
		}
		System.out.println("DO YOU WANT TO CONTINUE, PLEASE PRESS Z");
		 ch=sc.next().charAt(0);
		
		}while(ch=='z');
	}

}



package abstraction;
import java.util.*;
 abstract public class calculator_april
{
	  abstract public void sum();
	 	abstract public void sub();
	 	abstract public void multiply();
	 	abstract public void divide();
	 	
	
	public static void main(String[] args) 
	
	{
		Scanner sc=new Scanner(System.in);
		char ch;
		do
		{
		
			abstractclass ob=new abstractclass();
		ob.menu();
		
		System.out.println("enter your choice  no=");
		int n=sc.nextInt();
		
		if(n==1)
		ob.sum();
		
		else if(n==2)
		ob.sub();
		
		else if(n==3)
		ob.multiply();
		
		else if(n==4)
		ob.divide();
		
		else
		{
			System.out.println("please input valid option......");
		}
		System.out.println("DO YOU WANT TO CONTINUE, PLEASE PRESS Y");
		 ch=sc.next().charAt(0);
		
		
		
		}while(ch=='y');
		
	}

}


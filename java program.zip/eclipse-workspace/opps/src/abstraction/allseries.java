package abstraction;
import java.util.Scanner;
public class allseries extends abstractcheckpal
{

	@Override
	public void palcheck() {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter number");
	 int n=sc.nextInt();
	 int temp=n;
		int rev=0;
		while(temp!=0)
		{
			
			int rem;
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
		}
		
		if(rev==n)
		{
			System.out.println("number is palindrome");
		}
		else {
			System.out.println("number is not palindrome");
			
		}
		
	 
	}

	@Override
	public void armstrongcheck() {
	  
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter number");
		 int n=sc.nextInt();
		 
		int a=n;
		int rem,rev=0;
		 
		while(n!=0)
		{
			
			rem=n%10;
			rev=rev+rem*rem*rem;
			n=n/10;
		}
		
		
		if(a==rev)
		{
			System.out.println("armstorm number");
		}
		
		else {
		
			System.out.println("not armstorm number");
			
		
	
	}
	}

	@Override
	public void palseries() {
		 
		
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter first and last number");
		 int f=sc.nextInt();
		 int l=sc.nextInt();
		 	
			while(f<=l)
			{
				int temp=f;
				
				int rev=0;
			while(temp!=0)
			{
				
				int rem;
				rem=temp%10;
				rev=rev*10+rem;
				temp=temp/10;
			}
			
			if(rev==f)
			{
				System.out.println(f);
			}
			f++;
	}
	}

	@Override
	public void armstormSeries() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first and lastnumber");
		int f=sc.nextInt();
		int l=sc.nextInt();

		int sum,rem,temp;

 	 System.out.println("Armstrong number series is:-");
		 while(f<=l)
		 {
		   sum=0;
		   rem=0;
		   
		   
		  int j=f;
		  while(j!=0)
		   {
		     rem=j%10;
		     sum=sum+(rem*rem*rem);
		     j=j/10;
		 }  

		  
		  if(sum==f)
		   {
		      
		        System.out.print(f+" ");
		  }
		 f++;
		 }

		}	
	

	@Override
	public void primeseries() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first and lastnumber");
		int f=sc.nextInt();
		System.out.println("Enter the Frist No:-");
		 int l=sc.nextInt();
		System.out.println("priem No sum");
		for(int i=f;i<l;i++) {
			int count=0;
			for(int j=2;j<i;j++) {
				if(i%j==0) {
					count++;
					break;
				}
			}
			if(count==0 && i!=1) {
				System.out.println(i);
			}
		}
	}
	public void menu()
	
	{
		System.out.println("1.check palindrome");
		System.out.println("2.Armstrong check");
		System.out.println("3.palindrome series");
		System.out.println("4.Armstrong series");
		System.out.println("4.Prime Series");

	
	}

	
	

}

package abstraction;
import java.util.*;

public class abstractclass  extends calculator_april
{
	
	 	Scanner sc=new Scanner(System.in);
		
		public void sum()
		{
			System.out.println("enter two no=");
			int a=sc.nextInt();
			int b=sc.nextInt();
			
			System.out.println("sum="+(a+b));
			
		}

		
		public void sub() {
			System.out.println("enter two no=");
			int a=sc.nextInt();
			int b=sc.nextInt();
			
			System.out.println("sub="+(a-b));
			
		}

		
		public void multiply() {
			System.out.println("enter two no=");
			int a=sc.nextInt();
			int b=sc.nextInt();
			
			System.out.println("multiply="+(a*b));
			
		}

		
		public void divide() {
			System.out.println("enter two no=");
			int a=sc.nextInt();
			int b=sc.nextInt();
			
			System.out.println("divide="+(a/b));
			
		}
		
		public void menu()
		{
			System.out.println("1.ADDITION");
			System.out.println("2.SUBSTRACT");
			System.out.println("3.MULTIPLICATION");
			System.out.println("4.DIVISION");
		
		}

		public static void main(String[] args) 
		{
			
			
		}

	}
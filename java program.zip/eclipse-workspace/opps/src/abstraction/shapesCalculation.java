package abstraction;
/*
 * 2. Write a Java program to create an abstract class Shape with abstract methods 
 * calculateArea() and calculatePerimeter(). Create subclasses Circle and Triangle
 *  that extend the Shape class and implement the respective methods to calculate the area 
 *  and perimeter of each shape.


 */
abstract class shape
{
	abstract  void  calculateArea();
	abstract void calculatePerimeter();
	

}

class circle extends shape
{

	 
	void calculateArea()
	{
		
		double r=23.5;
		double circle=3.14*(r*r);
		 
		System.out.println("Area of circle="+circle);
	}

	 
	void calculatePerimeter() 
	{
		
		double r=12;
		double peri=2*3.14*r;
		System.out.println("perimeter of circle="+peri);
		 	
	}
	

}

class triangle extends shape
{

	 
	void calculateArea()
	{
		int b=20;
		int  h=10;
		
		double Area=1/2*b*h;
		 
		System.out.println("area of triangle ="+Area);
		
	}

	 
	void calculatePerimeter() {
		 
		
		int a=8;
		int b=7;
		int c=10;
		double peri=a+b+c;
		
		System.out.println("perimeter of triangle="+(a+b+c));
	}
	
}

public class shapesCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		circle ob= new circle();
		ob.calculateArea();
		ob.calculatePerimeter();
		
		triangle ob1=new triangle();
		ob1.calculateArea();
		ob1.calculatePerimeter();

	}

}

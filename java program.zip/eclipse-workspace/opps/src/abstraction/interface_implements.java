package abstraction;

import java.util.Scanner;

public class interface_implements implements I1
{

	@Override
	public void palindrome()
	{
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter number");
		 int n=sc.nextInt();
		 int temp=n;
			int rev=0;
			while(temp!=0)
			{
				
				int rem;
				rem=temp%10;
				rev=rev*10+rem;
				temp=temp/10;
			}
			
			if(rev==n)
			{
				System.out.println("number is palindrome");
			}
			else {
				System.out.println("number is not palindrome");
				
			}
		 
	}

	@Override
	public void prime()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		int i=2;
		int c=0;
		while(i<n)
			{
				if(n%i==0)
				{
					c++;	
				}
			i++;
			}
	if(c==0)
		{
			System.out.println("number is prime");
		}
		else
		{
			System.out.println("number is not prime");
		}
		 	
	}
	public void menu()
	{
		
		System.out.println( "====MENU=====");
		
		 
			System.out.println("1.CHECK NUMBER IS PALINDROME OR NOT");
			System.out.println("2.CHECK NUMBER IS PRIME OR NOT");
			 
		 

	}

}

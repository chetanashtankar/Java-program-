package abstraction;

interface I1{
	
	public void palindrome();
	public void prime();
	
}
public class interface_1class
{

}

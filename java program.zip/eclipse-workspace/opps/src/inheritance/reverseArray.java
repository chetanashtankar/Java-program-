package inheritance;
import java.util.Scanner;



class emplement
{
	Scanner sc=new Scanner(System.in); 
	int i,j,size;
	int a[];
	public void input()
	{
		
		size=sc.nextInt();
		 a=new int[size];
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
				
		
		
	}
	public void disp()
	{
		System.out.println();
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}
	
	
}
class emp2 extends emplement
{
	public void reverce()
	{
		System.out.println("reverse array");
		
	for(i=a.length-1;i>=0;i--)
	{
		System.out.println(a[i]);
	}
	}
}
public class reverseArray
{


 	public static void main(String[] args)
	{
		emp2 obj=new emp2();
		obj.input();
		obj.disp();
		obj.reverce();
	}

}
	



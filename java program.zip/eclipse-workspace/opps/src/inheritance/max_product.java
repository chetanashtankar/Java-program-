package inheritance;
/*
 * Write a program to find the maximum product of two integers in an array.

 */

import java.util.Scanner;

class maxpro
{
	int a[],b[];
	  int size,i,j;
	  Scanner sc= new Scanner(System.in);
		
	  public void input()
	  {
		  System.out.println("enter the size ");
		  
		   size=sc.nextInt();
		   a=new int[size];
		   b=new int[a.length];
		     System.out.println("enter the 1st array ");
			  
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }

}
	  
}
class product extends maxpro
{
  public void maxproduct()
  {
	  int total=1;
	  for(int i=0;i<a.length;i++)
	  {
		  total=total*a[i];
	  }
	  System.out.println("total="+total);

	  for(int i=0;i<a.length;i++)
	  {
		  b[i]=(total/a[i]);
	  }
	  
	  for(int i=0;i<b.length;i++)
	  {
		  System.out.print(b[i]+" ");
	  }
	}
	  
	  
  }


public class max_product {
	
	public static void main(String[]args)
	{
		product ob= new product();
		ob.input();
		ob.maxproduct();
	}

}

package inheritance;
import java.util.Scanner;
/*
 * Write a Java program to find the frequency of a given element in an array.

 */

class d{
	int a[];
	  int size,i,j;
	  Scanner sc= new Scanner(System.in);
		
	  public void input()
	  {
		  System.out.println("enter the size ");
		  
		   size=sc.nextInt();
		   a=new int[size];
		   System.out.println("enter array element ");
			 
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	   
	
	
}

class c extends d
{
	public void display()
	
	{
		  int b[]= new int[a.length];
			 
		 System.out.println("freq ");
		 
		 for(i=0;i<a.length;i++)
		 {
			 int c=1;
			 for(j=i+1;j<a.length;j++)
			 {
				 if(a[i]==a[j])
				 {
					 b[j]=-1;
					 c++;
					 
				 }
			 }
			 
			 if(b[i]!=1)
			 {
				 b[i]=c;
			 }
		 }
		 
		 System.out.println("elements    count");
		
		 System.out.println();
	
		 for(i=0;i<a.length;i++)
		 {
			 if(b[i]!=-1)
			 {
				 System.out.println(a[i]+ "   "+b[i]);
			 }
		 }
	
	}
	
	
		

}
public class freqfind 
{
	public static void main(String[]args)
	{
	c ob= new c();
	ob.input();
	ob.display();
	

}
}

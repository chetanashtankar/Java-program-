package inheritance;
/*
 * Q8.WAP to replace all the 0’s with 1’s in your array. Your array is [26, 0, 67, 45, 0, 78, 
    54, 34, 10, 0, 34] 
 */
import java.util.Scanner;

class Replace
{
	int i,j,size;
	int a[];
	Scanner sc= new Scanner(System.in);
	public void input()
	{
		System.out.println("enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("enter element");
		
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
	}
}
class zero extends Replace
{
	public void print()
	{
	for(i=0;i<a.length;i++)
	{
		if(a[i]==0)
		{
			a[i]=1;
		}
		
	}
	System.out.println("replace 0's element to 1");
	
	
	for(i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
		
	}
	}
}
public class replace0_to1 

{
	public static void main(String[]args)
   
	{
		zero ob= new zero();
		   ob.input();
		   ob.print();
	}
}

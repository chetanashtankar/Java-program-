package inheritance;
import java.util.Scanner;
/*
 * 
 */

class mmin1
{
	 
	
  int i,j,size;
  int a[];
  Scanner sc= new Scanner(System.in);
 
  public void input()
  {
	  System.out.println("enter size");
	  size=sc.nextInt();
	  a=new int[size];
	 for(i=0;i<a.length;i++)
	 {
		 a[i]=sc.nextInt();
		 
	 }
  }	
}

class displayele extends mmin1
{
   public void disp()
   {
	   for(i=0;i<a.length;i++)
		 {
			System.out.println(a[i]); 
		 }
   }
}

class secmax12 extends displayele
{
	public void maximum()
	{
	 int min =a[0];
		int sec_min=a[0];
		
	
	for(int i=0;i<a.length;i++)
	{
		if(a[i]<min)
		{
			sec_min=min;
			min=a[i];
		}
		else if(a[i]<sec_min && a[i]!=min)
		{
			sec_min=a[i];
		}
	}
	 System.out.println("min element ="+min);
	 System.out.println("second min element ="+sec_min);
					
	
	 
	}
	
	
	}
public class Secmin_multilevel {

	public static void main(String[]args)
	{
		secmax12 ob= new secmax12();
		ob.input();
		ob.disp();
		ob.maximum();
	}
}

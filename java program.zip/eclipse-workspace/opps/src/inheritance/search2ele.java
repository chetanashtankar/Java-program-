package inheritance;
import java.util.Scanner;
/*
 * Q10.WAP to check if an array of integers contains two specified elements.
 */


class found 
{
	int num[]=new int[6];
	int search;
	int flag;
	Scanner sc=new Scanner(System.in);
	public void name() 
	{
		System.out.println("Enter the Element");
		for (int i = 0; i < num.length; i++) 
		{
			num[i]=sc.nextInt();
		}
		System.out.println("Found the Element");
		search=sc.nextInt();
	}
}
class book extends found{
	public void dis() {
		System.out.println("");
		for (int i = 0; i < num.length; i++) {
			if(num[i]==search) {
			flag=1;
			break;
			}
			else {
				flag=0;
			}
		}
		if(flag==1) {
			System.out.println("Element Found in Array");
		}
		else {
			System.out.println("Elements Not Found in Array");
		}
	}
}
 


public class search2ele {
	
	public static void main(String[] args) {
		book obj=new book();
		obj.name();
		obj.dis();
	}

}

package inheritance;
/*
 * Write a Java program to find the leaders in an array 
 * (elements that are greater than all elements to their right).
 */
import java.util.Scanner;
class leadin
{
	int a[]= {23,13,4,3,5,2};
	int n=a.length;
	public void name()
	{
	 	for (int i = 0; i < a.length; i++)
		{
	 		
	 		System.out.println(a[i]);
		 
	}
}
}

class element1 extends leadin
{
	public void inputing() 
	{
	System.out.println("Leader Elment");
	for (int i = 0; i <a.length; i++)
	{
		int j;
		for (j = i+1; j <a.length; j++) 
		{
			if(a[i]<=a[j]) 
				break;
			
		}
		if(j==n)
		{
			System.out.print(a[i]+" ");
		}
	}
		
	}
	}
public class leaderElement {
	public static void main(String[]args)
	{
		element1 ob= new element1();
		ob.name();
		ob.inputing();
	}

}

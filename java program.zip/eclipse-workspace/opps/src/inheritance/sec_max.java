package inheritance;
import java.util.Scanner;


class secmax
{
	int i,j,size;
	int a[];
	Scanner sc= new Scanner(System.in);
	public void input()
	{
		System.out.println("enter size");
		size=sc.nextInt();
		a=new int[size];
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
	}
}
class max1 extends secmax
{
   public void maxnum() {
		for(i=0;i<a.length;i++)
		{
			int temp;
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
				}
		
		System.out.println("2nd max number="+a[1]);
    	
		
	}
	

}

public class sec_max
{
	public static void main(String[]args)
	{
		max1 ob=new max1();
		ob.input();
		ob.maxnum();
	}

}

package inheritance;
/*
 * Given an array of integers, write a program to find the majority element (element that appears more than n/2 times).

 */
import java.util.Scanner;

class majority23
{
	int i,j;
	int a[],size;
	 Scanner sc= new Scanner(System.in);
	   public void input()
	   {
		   System.out.println("enter size");
			  size=sc.nextInt();
			  a= new int[size];
			  System.out.println("enter  array element");
				
			 for(i=0;i<a.length;i++)
			 {
				 a[i]=sc.nextInt();
				 
			 }
	   }
	  
	}

    class element3 extends majority23
    {
    	public int majority1()
    	{
    		int count=0;
			int maxcount=0;
			int index=-1;
    		for(int i=0;i<a.length;i++)
			{
			 for(int j=i+1;j<a.length;j++)
			 {
				 if(a[i]==a[j])
					 count++;
			 }
			 if(count > maxcount)
				{
					maxcount=count;
					index=i;
				}
			}
			   System.out.println("majority element :-");
			if(maxcount > a.length/2)
			{
				
			}
			return a[index];
			
		}
    	}
    

public class majority_ele
{
	public static void main(String[]args)
	{
		element3 ob= new element3();
		ob.input();
		System.out.println(ob.majority1());
		
	}
}

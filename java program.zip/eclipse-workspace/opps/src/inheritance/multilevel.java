package inheritance;

class Animal126
{
	public void animal()
	{
  System.out.println("Animal");	
	}

}

class dog1 extends Animal126
{
 public void dog()
 {
	 System.out.println("barking");	

 }
}

class cat extends dog1
{
	public void dog3()
	 {
	 System.out.println("sleeeping");	
	 }
}
public class multilevel
{
 public static void main(String[]args)
 {
	 cat ob=new cat();
	 ob.animal();
	 ob.dog();
	 ob.dog3();
 }
}

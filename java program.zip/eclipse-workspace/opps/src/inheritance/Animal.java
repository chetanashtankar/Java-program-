package inheritance;
/*
 * Create a class Animal with attributes name and sound.
 *  Then create two subclasses Dog and Cat that inherit from 
 *  Animal. Implement a method in each subclass that prints
 *   the sound of the respective animal.

 */

class Animal12
{

	public void sound()
	{
	   System.out.println("making sound");	
	}


}

class dog123 extends Animal12
{
	

	public void sound()
	{
	   System.out.println("dog sound = bhoo bhoo");	
	}
 
}
class cat1 extends Animal12{
	
	public void sound()
	{
	   System.out.println("cat  sound = myav myav");	
	}
	
}
public class Animal {

	public static void main(String[] args) {
		 
		dog123 Animal= new dog123();
		Animal.sound();
		
		cat1 cat= new cat1();
		cat.sound();
	}

}

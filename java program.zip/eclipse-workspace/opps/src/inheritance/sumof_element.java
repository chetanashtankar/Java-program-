package inheritance;
import java.util.Scanner;
/*
 * Write a program to find the sum of all elements in an array.

 */

class sum
{
  int i,j;
  int size,a[];
  Scanner sc= new Scanner(System.in);
  
  public void input()
  {
	  System.out.println("enter array size");
		
	  size=sc.nextInt();
	  a=new int[size];
	  System.out.println("enter array element");
	  for(i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
	  }
	  
  }
  

}

class display12 extends sum
{
   public void disp()
   {
	   System.out.println(" array element are");
		  for(i=0;i<a.length;i++)
		  {
			  System.out.println(a[i]);
		  }
   }

}

class sumele extends display12
{
	public void sumele()
	{
    int sum=0;
    for(i=0;i<a.length;i++)
    {
    	sum=sum+a[i];
    }
    
    System.out.println("sum of array element="+sum);
	
 
}
}
public class sumof_element
{
	public static void main(String[]args)
	{
		sumele ob= new sumele();
		ob.input();
		ob.disp();
		ob.sumele();
	}

}












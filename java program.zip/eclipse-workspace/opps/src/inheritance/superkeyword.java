package inheritance;

class Abc1
{
	Abc1(int id,String name)
	{
	  System.out.println("parent class constructor");
	  
	  
	}

}

class bita3 extends Abc1
{
	bita3()
	{
		super(13,"ND");
		System.out.println("child class constructor");
		
	}

}




public class superkeyword {
  
	public static void main(String[]args)
	{
		bita3 ob= new bita3();
		 
	}

}

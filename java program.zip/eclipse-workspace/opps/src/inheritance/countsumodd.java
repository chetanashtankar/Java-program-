package inheritance;
/*
 * Write a program to count the number of even and odd elements in an array.

 */
import java.util.Scanner;

class input23
{
	int i,j;
	  int size,a[];
	  Scanner sc= new Scanner(System.in);
	  	public void input()
	  	{
	  		 System.out.println("enter array size");
	 		
	  		  size=sc.nextInt();
	  		  a=new int[size];
	  		  System.out.println("enter array element");
	  for(i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
		  
	  }
	  	}

}
class even extends input23
{  
	int c;
	 public void even() 
	 {
		 c=0;
		 System.out.println("even number");

		 for(i=0;i<a.length;i++)
		 {
			 if(a[i]%2==0)
			 {
				 System.out.println(a[i]);
			 }
			 
			 
			 
		 }
		
		 
		 
	 }
	
 

}

class odd12 extends even{
	int c;
	public void odd()
	{
		 c=0;
		 System.out.println("odd number");

		 for(i=0;i<a.length;i++)
		 {
			 if(a[i]%2!=0)
			 {
				 System.out.println(a[i]);
			 }
			 
			 
		 }
		
		 
		 
		 
	 }
	}
	

public class countsumodd
{

	public static void main(String[]args)
	{
		odd12 ob= new odd12();
		ob.input();
		ob.even();
		ob.odd();
	}
}













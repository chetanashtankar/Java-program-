package inheritance;

class studentde
{
  String name;
  int roll_numb;
  studentde(String name,int roll_numb)
  {
	  this.name=name;
	  this.roll_numb=roll_numb;
	  
  }
  public void disp()
  {
	  System.out.println(name+"  "+roll_numb);
  }

}


class details extends studentde
{
    String Addrss;
    String college;
    details(String Addrss ,String college)
    {
    	super("Nehal",25);
    	this.Addrss=Addrss;
    	this.college=college;
    	
    }
    
    public void disp1()
    {
    	System.out.println(name+" "+roll_numb+"  "+Addrss+"  "+college);
    }

}
public class studentDetailsuperthis 
{
	
	public static void main(String[]args)
	{
	details ob= new details("Nagpur","DMIETR");
	ob.disp1();
	
	}

}

package inheritance;
/*
 * Write a program to find the intersection of two arrays.

 */import java.util.Scanner;
 
 class abc 
 {
	 int a[],b[],c[];
	  int size,i,j;
	  Scanner sc= new Scanner(System.in);
		
	  public void input()
	  {
		  System.out.println("enter the size ");
		  
		   size=sc.nextInt();
		   a=new int[size];
		   b=new int[size];
		   c= new int[a.length+b.length];
		   System.out.println("enter the 1st array ");
			  
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
		   System.out.println("enter the 2nd array ");
			
		   for(i=0;i<b.length;i++)
		   {
			   b[i]=sc.nextInt();
		   }
	  }
	   
	}
 class intersection12 extends abc
 {
	 public void intsec()
	 {
		 for(int i=0;i<a.length;i++)
			{
				c[i]=a[i];
			}
			
			for(int i=0;i<b.length;i++)
			{
				c[a.length+i]=b[i];
			}
			
			System.out.println("Intersection Elements are : ");
			
			int n=c.length,k;
			for(int i=0;i<n;i++)
			{
				for(int j=i+1;j<n;j++)
				{
					if(c[i]==c[j])
					{
						System.out.print(c[i]+" ");
						for(k=j;k<n-1;k++)
						{
							c[k]=c[k+1];
						}
					n--;
					}
				}
			}
			
			 
	 }
 }
 
public class intersection
{
   public static void main(String[]args)
   {
	   intersection12 ob=new intersection12();
	   ob.input();
	   ob.intsec();
   }
}

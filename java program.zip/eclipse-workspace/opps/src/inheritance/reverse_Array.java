package inheritance;
import java.util.Scanner;
/*
  
How can you reverse an array in-place without using any additional space?

 */

class Abc
{
   int i,j,size;
   int a[];
   Scanner sc= new Scanner(System.in);
   public void input()
   {
	   System.out.println("enter size");
		  size=sc.nextInt();
		  a= new int[size];
		  System.out.println("enter  array element");
			
		 for(i=0;i<a.length;i++)
		 {
			 a[i]=sc.nextInt();
			 
		 }
   }
  
}

class reverse extends Abc
{

	public void reverse()
	{
	   System.out.println("reverse array element");
		
	   for(i=a.length-1;i>=0;i--)
	   {
		   System.out.println(a[i]);
	   }
   	
	}
}
public class reverse_Array
{
	public static void main(String[]args)
	{
		reverse ob= new reverse();
		ob.input();
		ob.reverse();
	}
}

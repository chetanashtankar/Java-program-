package inheritance;
/*
 * 
 * Q4. How do you find the largest and smallest number in an unsorted integer array size 10. 
 input in constructor and final result through the method. 
 */
import java.util.Scanner;

class max
{
	int i,j,size;
	int a[];
	Scanner sc= new Scanner(System.in);
	public void input()
	{
		System.out.println("enter size");
		size=sc.nextInt();
		a=new int[size];
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
	}
   public void maxnum() {
		for(i=0;i<a.length;i++)
		{
			int temp;
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
				}
		
		System.out.println("max number="+a[0]);
    	
		
	}
	
	
}

class min extends max
{
    public void input1()
    {
    	for(i=0;i<a.length;i++)
		{
			int temp;
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
				}
    	System.out.println("min number="+a[0]);
    	
    
    }
    
}





public class max_min 
{
	
public static void main(String[]args)
{
	min ob= new min();
	ob.input();
	
	ob.maxnum();
	ob.input1();
	
}
}

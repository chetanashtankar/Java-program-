package inheritance;
import java.util.Scanner;
/*
 * Q1. Write a Java program to get the difference between the largest
 *  and smallest values in an array of integers.
 *   The length of the array must be 2 and above.

 */


class Maxxnew
{
	  int max=0;
	  int min=Integer.MAX_VALUE;
	Scanner sc=new Scanner(System.in);
	public void input(int a[])
	{
	
	System.out.println("enter a element ");
	for(int i=0;i<a.length;i++)
	{
		a[i]=sc.nextInt();
		
	}
	}
}
	
	
	class display extends Maxxnew
	{
		public void  disp(int a[])
		{
			
			for(int i=0;i<a.length;i++)
			{
			if(max<a[i])
			{
				max=a[i];
			}
			}
			System.out.println("max="+max);
		}
		
	
	
		public void  show(int a[])
		{
			
			for(int i=0;i<a.length;i++)
			{
			if(min>a[i])
			{
				min=a[i];
			}
			}
			System.out.println("Min="+min);
			
		}
		public void Ans(int a[] )
		{
			int diff=max-min;
			System.out.println(diff);
		}
		
	}
	
	
	
	
	 
public class max_min_diff 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[]=new int [size];
		display d=new display();
		d.input(a);
		d.disp(a);
		d.show(a);
		d.Ans(a);
	}
}

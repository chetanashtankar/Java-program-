package inheritance;

class Alpha1
{
   public void eat()
   {
	   
	   System.out.println("animals are eating");
   }

}

class dog extends Alpha1
{

	public void eat()
	{
		super.eat();
		   System.out.println("dogs are eating");

	}
 
}




public class invokeparent_super {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog ob= new dog();
		ob.eat();
		
	}

}

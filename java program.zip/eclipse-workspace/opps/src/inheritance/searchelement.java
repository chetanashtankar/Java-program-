package inheritance;
import java.util.Scanner;
/*
 * Q9.Wap enter an array and search any particular element and find the count.

 */
class search
{
	int i,j,size;
	int a[];
	Scanner sc= new Scanner(System.in);
	public void input()
	{
		System.out.println("enter size");
		size=sc.nextInt();
		a=new int[size];
		System.out.println("enter element");
		
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		 
	}
}
class element extends search
{
  public void disp()
  {
	  System.out.println("enter element you want to search");
		
	  
	  int ele=sc.nextInt();
	  int c=0;
   for(i=0;i<a.length;i++)
	{
	   if(a[i]==ele)
	   { 
		   c++;
			
	   }
	  	
	   }
   
      if(c>0)
      {
    	  
   	    
   		   System.out.println("element  found");
   		
      }
      
	   else {
		   System.out.println("element not found");
		
	}
	}
	
}



public class searchelement {
	
	public static void main(String[]args)
	{
	element ob= new element();
	ob.input();
	ob.disp();
	}
	

}















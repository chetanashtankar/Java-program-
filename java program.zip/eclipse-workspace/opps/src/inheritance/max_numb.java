package inheritance;
import java.util.Scanner;
/*
 * Q13. Write a Java program to find max number in an array.

 */
class inp
{
	 Scanner sc= new Scanner(System.in);
		int a[];
		  void input()
   {
    	System.out.println("enter the size of an array");
		int size =sc.nextInt();
		System.out.println("enter the Elements");
		a=new int[size];
  
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}

   }
}


class disp extends inp
{
	
    void display()
   {
    	int max=0;
    	
      	  for(int i=0;i<a.length;i++) 
      	  {
		  if(a[i]>max)
		  {
			  max=a[i];
		  }
		  }
      	  
      	  System.out.println("largest number in array is="+max);
		   
   }
}
public class max_numb
{
	 
	public static void main(String[]args)
	{
		
		disp ob= new disp();
	     ob.input();
	     ob.display();
	}

}

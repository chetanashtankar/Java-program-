package inheritance;
/*
 * Given an array of integers, write a program to rearrange the elements in such a way that all the even numbers come before the odd numbers.

 */
import java.util.Scanner;
class rearange
{  int i,j;
    Scanner sc= new Scanner(System.in);
  public void input(int a[])
  {
	  System.out.println("enter array");
	  for(i=0;i<a.length;i++)
	  {
		  a[i]=sc.nextInt();
	  }
	  
  }


}


class odd extends rearange
{
   public void displa(int a[])
   {
	   System.out.println("odd before even ");
		 
	   int temp;
	   for(i=0;i<a.length;i++)
	   {
		   for(j=i+1;j<a.length;j++)
		   {
			   if(a[j]%2!=0)
			   {
				   temp=a[i];
				   a[i]=a[j];
				   a[j]=temp;
			   }
		   }
	   }
	   for(i=0;i<a.length;i++)
		  {
			 System.out.println(a[i]);
		  }
		  
   }



}
public class rearrangeoddbefore_even {
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter size");
		int size=sc.nextInt();
		int a[]=new int[size];
		odd ob= new odd();
		ob.input(a);
		ob.displa(a);
	}

}

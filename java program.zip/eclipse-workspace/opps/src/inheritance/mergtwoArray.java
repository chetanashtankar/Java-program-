package inheritance;
/*
 * Write a Java program to merge two sorted arrays into a single sorted array.
 */
import java.util.Scanner;


	
	
	class abcd 
	{
		int i,j;
		int a[];
		int b[];
		int c[];
		Scanner sc= new Scanner(System.in);
		public void input()
		{
	    System.out.println("enter size");
	    int size=sc.nextInt();
	     a=new int[size];
	     b=new int[size];
	     c=new int[a.length+a.length];
	    
	    System.out.println("enter first array element ");
		 
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
		   
		   System.out.println("enter 2nd  array element ");
			 
		   for(i=0;i<b.length;i++)
		   {
			   b[i]=sc.nextInt();
		   }
	}
	}
	class merge2 extends abcd
	{
		public void merge21()
		{
		 for(i=0;i<a.length;i++)
		   {
			  c[i]=a[i];
		   }
		 for(i=0;i<b.length;i++)
		   {
			   c[a.length+i]=b[i];
		   }
		 System.out.println("merge two  array element ");
			
		 for(i=0;i<c.length;i++)
		   {
			  System.out.println(c[i]);
		   }
		}
		
	}
	public class mergtwoArray 
	{
		public static void main(String[]args)
		{
			merge2 ob= new merge2();
			ob.input();
			ob.merge21();
		}

}

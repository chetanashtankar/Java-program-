package inheritance;
import java.util.Scanner;
/*
 * Q5.Wap replace 0's from the square of  the next element of array using constructor.
   your array is-{2,0,4,8,0,5,0,5,8};
 */

	class input123
	{
		int i,j,size;
		int a[];
		Scanner sc= new Scanner(System.in);
		public void input()
		{
			System.out.println("enter size");
			size=sc.nextInt();
			a=new int[size];
			System.out.println("enter element");
			
			for(i=0;i<a.length;i++)
			{
				a[i]=sc.nextInt();
				
			}
		}
	}
	
	class replace extends input123
	{
		public void replace()
		{
			for(i=0;i<a.length;i++)
			{
				if(a[i]==0)
				{
					a[i]=a[i+1]*a[i+1];
				}
			}
			System.out.println("replace 0's to square of next element ");
			
			for(i=0;i<a.length;i++)
			{
				System.out.println(a[i]);
			}
		}
	}
	
	
	
	public class zerosquare 
	{
	
	
	public static void main(String[]args)
	{
		replace ob= new replace();
		ob.input();
		ob.replace();
	}
	
	
	 

}

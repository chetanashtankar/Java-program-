package inheritance;
import java.util.Scanner;
/*
 * Q3..Find the duplicate from the elements Size of array will be 10; 
 input in constructor and final result through the method. 

 */


class input 
{
  int a[];
  int size,i,j;
  Scanner sc= new Scanner(System.in);
	
  public void input()
  {
	  System.out.println("enter the size ");
	  
	   size=sc.nextInt();
	   a=new int[size];
	   
	   for(i=0;i<a.length;i++)
	   {
		   a[i]=sc.nextInt();
	   }
  }
   
}
class duplicate extends input
{
  public void disp()
  {
	      
	   for(i=0;i<a.length;i++)
	   { 
		   for(j=i+1;j<a.length;j++)
		   {
			   if(a[i]==a[j])
			   {
				    a[i]=0;
			   }
		   }
	   }

		  System.out.println(" after removing duplicate array element");
		
	   for(i=0;i<a.length;i++)
	   {
		  if(a[i]==0)
		  {
			  
			  continue;
			  
		  }
		  System.out.println(a[i]+" ");
	   }
  }
 
}
public class duplicate_array 
{
	public static void main(String[]args)
	{
		duplicate ob= new duplicate();
		ob.input();
		ob.disp();
	}
	

}

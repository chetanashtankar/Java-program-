package inheritance;
/*
 
Write a program to find the kth smallest element in an unsorted array.

 */
import java.util.Scanner;

class kthsmall
{
int a[],b[];
int size,i,j;
Scanner sc= new Scanner(System.in);
	
public void input()
{
	  System.out.println("enter the size ");
	  
	   size=sc.nextInt();
	   a=new int[size];
	      System.out.println("enter the 1st array ");
		  
	   for(i=0;i<a.length;i++)
	   {
		   a[i]=sc.nextInt();
	   }

}}

class smallestele extends kthsmall
{
   public void small1()
   {
	 int  temp=0;
		int k=3;
			for(i=0;i<a.length;i++)
			{
			System.out.println(a[i]+" ");
			}
				
				for(i=0;i<a.length;i++)
				{
					for(j=i+1;j<a.length;j++)
					{
						if(a[i]>a[j])
						{
							temp= a[i];
							a[i] = a[j];
							a[j]= temp;
						}
					}
				
				if(i==(k-1))
				{
					System.out.println("Kth Smallest Element is "+a[i] + " At position "+k);
						break;
				}
				}
				
				for(i=0;i<a.length;i++)
				{
					System.out.println(a[i]+" ");
				}
   }
}

public class kthsmallest {
	public static void main(String[]args)
	{
		smallestele ob=new smallestele();
		ob.input();
		ob.small1();
	}

}

package inheritance;


class Alpha
{
	
  int id=11;
  String name="Nehal";
  
  public void inp()
  {
	  System.out.println(id+" "+name);
  }
}

class b extends Alpha
{
  int id=13;
  String name="Nd";
  
  public void disp()
  {
	  System.out.println(id+" "+name);
	  System.out.println(super.id+" "+super.name);//it refers to parent class instantiation
	  
  }
}

 
public class superKeywordusing 
{
	
	
	public static void main(String[]args)
	{
		b ob=new b();
		ob.disp();
	}

}

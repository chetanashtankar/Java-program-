package inheritance;
import java.util.Scanner;
/*
   Write a program to find the second largest element in an array 
   without sorting it.


 */

class max3
{
	 
	
  int i,j,size;
  int a[];
  Scanner sc= new Scanner(System.in);
 
  public void input()
  {
	  System.out.println("enter size");
	  size=sc.nextInt();
	  a=new int[size];
	 for(i=0;i<a.length;i++)
	 {
		 a[i]=sc.nextInt();
		 
	 }
	 System.out.println("array elements are");
	 for(int i : a)
	 {
		 System.out.println(i);
			
	 }
  }	
}

class secmax1 extends max3
{
	public void maximum()
	{
	 int max =a[0];
		int sec_max=a[0];
		
	
	for(int i=0;i<a.length;i++)
	{
		if(a[i]>max)
		{
			sec_max=max;
			max=a[i];
		}
		else if(a[i]>sec_max && a[i]!=max)
		{
			sec_max=a[i];
		}
	}
	 System.out.println("max element ="+max);
	 System.out.println("second max element ="+sec_max);
					
	
	 
	}
	
	
	}
	
public class Sec_largest
{
	public static void main(String[]args)
	{
		secmax1 ob= new secmax1();
		ob.input();
		ob.maximum();
	}
}

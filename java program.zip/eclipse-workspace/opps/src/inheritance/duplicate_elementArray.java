package inheritance;

import java.util.Scanner;

/*
 * Write a Java program to remove duplicates from an array.

 */

	
	class input1 
	{
	  int a[];
	  int size,i,j;
	  Scanner sc= new Scanner(System.in);
		
	  public void input()
	  {
		  System.out.println("enter the size ");
		  
		   size=sc.nextInt();
		   a=new int[size];
		   System.out.println("enter array element ");
			 
		   for(i=0;i<a.length;i++)
		   {
			   a[i]=sc.nextInt();
		   }
	  }
	   
	}
	class duplicate1 extends input1
	{
	  public void disp()
	  {
		      
		   for(i=0;i<a.length;i++)
		   { 
			   for(j=i+1;j<a.length;j++)
			   {
				   if(a[i]==a[j])
				   {
					    a[i]=0;
				   }
			   }
		   }

			  System.out.println(" after removing duplicate array element");
			
		   for(i=0;i<a.length;i++)
		   {
			  if(a[i]==0)
			  {
				  
				  continue;
				  
			  }
			  System.out.println(a[i]+" ");
		   }
	  }
	}
	public class duplicate_elementArray
	{
	  public static void main(String[]args)
	  {
		  duplicate1 ob= new duplicate1();
		  ob.input();
		  ob.disp();
		  
		  }
	  

}

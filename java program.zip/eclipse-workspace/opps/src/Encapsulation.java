
public class Encapsulation {

}

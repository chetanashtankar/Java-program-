package interface1;
/*
 * Create an interface Playable with a method playSound(). 
 * Then create two classes Guitar and Piano, 
 * each implementing the Playable interface. 
 * Implement the playSound() method differently in each class.
 */

interface playable{
	
	public void playsound();
	}

class giuitar1 implements playable{
	
	public void playsound() {
		
		
		System.out.println("guitar sound ");
	}
	
	
}


class piano implements playable{
	
public void playsound() {
		
		
		System.out.println("piano sound  ");
	}
	
}
public class guitar
{

	public static void main(String[] args) {
		giuitar1 o= new giuitar1();
		o.playsound();
		piano ob= new piano();
		ob.playsound();
		
		
	}

}

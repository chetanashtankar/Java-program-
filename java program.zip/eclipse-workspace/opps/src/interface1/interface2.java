package interface1;

public class interface2 implements I1,I2 
{

	@Override
	public void disp() {
	 
		System.out.println("hello");
	}

	@Override
	public void disp2() {
		 
		System.out.println("hiii");
		
	}

	@Override
	public void disp(int a) {
		 
		System.out.println(a);
	}

	@Override
	public void disp2(String c) {
		// TODO Auto-generated method stub
		
		System.out.println(c);
	}

}

package interface1;

interface I1 {
	
	public void disp();
	public void disp2();
	 
}

interface I2 {
	
	public void disp(int a);
	public void disp2(String c);
	 
}
public class interface_1 
{
	
	public static void main(String[] args) {
		
		interface2 ob= new interface2();
		ob.disp();
		ob.disp2();
		ob.disp(10);
		ob.disp2("XYZ");
		
	}

}

/*
 * Write a Java program that calculates the area of a rectangle. 
 * The program should take the length and width of the 
 * rectangle as input from the user. 
 * If either the length or width entered by
 *  the user is negative, throw a custom exception 
 *  called NegativeDimensionException. 
 *  The NegativeDimensionException should be a 
 *  checked exception that includes an appropriate error 
 *  message.
 */
import java.util.Scanner;
public class rectangle_exception 
{
	Scanner sc= new Scanner(System.in);
	public void disp()
	{
		
			System.out.println("enter length");
		int a=sc.nextInt();
		System.out.println("enter width");
		
		int b=sc.nextInt();
		if(a>0)
		{
			try {
		double area =a*b;
		System.out.println(area);
		}
			catch (Exception e) {

				System.out.println(e);
	}
		}
		 
		 
	}

	public static void main(String[] args) {
		 
		rectangle_exception ob= new rectangle_exception();
		ob.disp();
	}

}

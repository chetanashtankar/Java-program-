/*
 * Q1.Create a custom exception class in Java called "NegativeNumberException.
 * " Write a program that takes an integer as input and throws the custom exception 
 * when a negative number is provided.
 */
import java.util.Scanner;
		class NegativeNumberException extends Exception {
		    public NegativeNumberException(String message) {
		        super(message);
		    }
		}
public class custom_Exception
{
	public void disp()
	{
	 	        Scanner scanner = new Scanner(System.in);

		        try 
		        {
		            System.out.print("Enter  number: ");
		            int a = scanner.nextInt();
		            if (a < 0) 
		            {
		                throw new NegativeNumberException("Negative numbers are not allowed.");
		            }

		            
		        }
		        catch (NegativeNumberException e)
		        {
		            System.out.println("you enter wrong input: " + e);
		        }
		        catch (Exception e)
		        {
		            System.out.println("Error: Invalid input");
		        } 
		    }
		

	

	public static void main(String[] args) {
		custom_Exception ob= new custom_Exception();
		ob.disp();
	}

}

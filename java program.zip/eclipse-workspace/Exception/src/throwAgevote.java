class notEligible extends Exception
{
	
	notEligible(String s)
	{
		super(s);
	}
	
}
public class throwAgevote {
	
	public void vote() throws notEligible 
	{
		int age =17;
		if(age<18)
		{
			throw new notEligible("not eligible");
		}
		
		else {
			
			System.out.println("eligible");
		}
	}

	public static void main(String[] args) {

		throwAgevote ob= new throwAgevote();
		try{
			ob.vote();
		}
		catch (Exception e) {
     System.out.println("not eligible");
       e.printStackTrace();

		}
		
	}

}

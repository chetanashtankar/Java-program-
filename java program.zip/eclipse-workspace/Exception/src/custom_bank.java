/*
 * Q2.Write a Java program that simulates a bank account.
 Create a custom exception 
 * class called "InsufficientBalanceException" and raise it whenever 
 * a withdrawal is 
 * attempted with an amount higher than the account balance. 
 * Handle the custom exception and
 *  display an error message.
 */
import java.util.Scanner;
class InsufficientBalanceException extends Exception 
{
		    public InsufficientBalanceException(String message)
		    {
		        super(message);
		    }
		}
public class custom_bank
{
	public void checkbal(int b,int bal)throws InsufficientBalanceException
	{
		if(bal<b)
		{
		 throw new InsufficientBalanceException("insufficient balance");	
		}
		else
		{
			bal=bal-b;
			System.out.println("your ramaing  balance is " + bal);
		}
		
	}
	
	
	public static void main(String[] args)throws Exception
	{
		
		custom_bank s=new custom_bank();
		Scanner sc=new Scanner(System.in);
		int bal=2000;
		System.out.println("your account bal is:"+bal);
		System.out.println("enter a money you want to withdraw");
		int b=sc.nextInt();
		try
		{
			s.checkbal(b, bal);
		}
		catch(Exception e)
		{
			System.out.println("error " +e);
			
		}
	}
}
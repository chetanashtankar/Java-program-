/*
 * Write a Java program to divide two numbers provided by the
 *  user. Handle the ArithmeticException that may occur if the 
 *  divisor is zero and display an error message instead of 
 *  crashing the program.

 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class exception_Arithmetic
{
	Scanner sc= new Scanner(System.in);
	
	public void arith()
	{ 
		try {
		 	System.out.println("enter number");
			int a=sc.nextInt();
			int b=sc.nextInt();
			System.out.println(a/b);
		}
		catch (Exception e) {
			 System.out.println("invalid number enter="+e);
		}
		 
			
		}
	  
		 
 
		
	  
	

	public static void main(String[] args) {
		exception_Arithmetic ob= new exception_Arithmetic();
		ob.arith();
	}

}

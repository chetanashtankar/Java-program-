import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class throws_exception {

	public void disp() throws FileNotFoundException
	{
		FileInputStream file= new FileInputStream("D://abc.txt");
	    throw new FileNotFoundException();
	}
	public static void main(String[] args) {
	 
		throws_exception ob= new throws_exception();
		try{
			ob.disp();
			
		}
		catch (Exception e) {
		System.out.println("file not found"); 
		
		}
	}

}

//exception propogation is a exception occur in all method if we  handle one method exception so that is all method handle.
public class exception_propogation 
{

	public void disp()
	{
		try {
		int a=10,b=0;
		System.out.print(a/b);//exception generated
	}
		catch (Exception e) {
		 System.out.println(e);
		}
	}
	public void disp1()
	{
		disp();
		System.out.println("disp1 method");
		
		
	}
	
	public void disp2()
	{
		 
		disp1();
			 
		System.out.println("disp2 method");
		
		
	}
	public static void main(String[] args) {

		exception_propogation ob=new exception_propogation();
		ob.disp2();
	}

}

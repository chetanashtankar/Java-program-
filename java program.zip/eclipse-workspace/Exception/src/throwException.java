
class YougerAgeException extends  Exception{
	
	YougerAgeException(String msg)
	{
		super(msg);
	}
	
	
}
public class throwException {

	public static void main(String[] args) {

			int age =17;
			try {
			if(age<18)
			{
	
				throw new YougerAgeException("you are not eligible to vote");
	      }
			
			else {
				System.out.println("vote successfull");
			}
			}
			catch (Exception e) {
			e.printStackTrace();	 
			
			}
			
			System.out.println("hello");
		
       	}

}

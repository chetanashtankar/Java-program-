 
/*
 * 4.Write a Java program to handle an array index out-of-bounds exception.

 */
public class ArrayIndexoutofbond {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,5,6};
		
		try {
		 System.out.println(a[6]);
		}
		catch (Exception e) {
			 
			 System.out.println(e);
		}

	}

}


public class practice
{
	
	public static void main(String[] args) {
		
		
		int a[]= {12,4,85,63,1};
	
		System.out.println("Array element ");
		
		int min=a[0];
		
		int max=a[0];
		for (int i = 0; i < a.length; i++) {
	 		
			System.out.println(a[i]);
			if(a[i]<min)
			{
				min=a[i];
			}
			
			
		 
			
		}
		
		for (int i = 0; i < a.length; i++) {
			
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		
		
		
		
		System.out.println("max element= "+max);
		System.out.println("Min element ="+min);
	
	
	}

}

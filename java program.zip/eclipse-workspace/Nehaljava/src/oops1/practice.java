package oops1;
/*
 * Write a Java method called findPairSum that takes an array of integers and a target sum as input and returns a pair of elements from
 *  the array that add up to the target sum. If there are multiple valid pairs, you can return any one of them. If no such pair exists,
 *   the method should return null.
 */
import java.util.Scanner;

public class practice

{
	int i,j;
 
 
	Scanner sc= new Scanner(System.in);
	public int input(int a[],int size)
	{
		
		for(i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the sum");
		int sum=sc.nextInt();
		int c=0;
		
		for(i=0;i<a.length;i++)
		{
			for(j=i+1;j<a.length;j++)
			{
				if(a[i]+a[j]==sum)
				{
					System.out.println(a[i]+" "+a[j] +" ="+sum);
					c++;
				}
			}
		}
		System.out.println("count "+c);
		if(c>0)
		{
			System.out.println("pair of sum found");
			
		}
		else {
			System.out.println("pair of sum not found");
			
			
		}
		return c;
		
		 
	}
	  
	public static void main(String[]args)
	{
		Scanner sc= new Scanner(System.in);
		 System.out.println("enter size");
		 int  size=sc.nextInt();
		 int a[]=new int[size];
		 practice ob= new practice();
		 ob.input(a, size);
		 
		 
	    
	}

}

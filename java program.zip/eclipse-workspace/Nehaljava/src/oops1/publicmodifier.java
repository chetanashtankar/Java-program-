package oops1;

import starpattern.protectedmodifier;

class amsb
	{
		  private void disp() 
		  {
			  System.out.println("private in another class");// is not ACCessible .
 
			}
	}

public class publicmodifier extends protectedmodifier
{
	private void show()
	{
		System.out.println("private in class");
	}

	public static void main(String[]args)
	{
		publicmodifier ob= new publicmodifier();
		 ob.show();
		 amsb obj= new amsb();//you can not get the private method in the another class only accessible in the class
	
		 protectedmodifier abc=new protectedmodifier();
		 ob.disp();
		 //call the outside the package starpattern
		 
	
	}
	

}

package starpattern;

public class pascalTriangl 
{
	public static void main(String[]args)
	{
	int n=5;
	int i,j;
	int temp=1;;
	
	for(i=1;i<=n;i++)
	{	
		for(j=1;j<=i;j++)
		{
			System.out.print(temp+" ");
		temp++;	
		}
		System.out.println();
		}
	}

}

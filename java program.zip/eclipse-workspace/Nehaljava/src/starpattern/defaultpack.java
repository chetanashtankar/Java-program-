package starpattern;

public class defaultpack
{
	
	void input2()
	{
		System.out.println("default package");
	}
     public static void main(String[]args)
     {
    	 defaultpack ob= new defaultpack();
    	 ob.input2();
     }
}

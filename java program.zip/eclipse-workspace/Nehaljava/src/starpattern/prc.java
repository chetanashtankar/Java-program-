package starpattern;

import java.util.Scanner;


public class prc {
	
		int i,j;
	 
	 
		Scanner sc= new Scanner(System.in);
		public void input(int a[],int size)
		{
			
			for(i=0;i<a.length;i++)
			{
				a[i]=sc.nextInt();
			}
			System.out.println("enter the sum");
			int sum=sc.nextInt();
			int c=0;
			
			for(i=0;i<a.length;i++)
			{
				for(j=i+1;j<a.length;j++)
				{
					if(a[i]+a[j]==sum)
					{
						System.out.println(a[i]+" "+a[j] +" ="+sum);
						c++;
					}
				}
			}
			System.out.println("count "+c);
			if(c>0)
			{
				System.out.println("pair of sum found");
				
			}
			else {
				System.out.println("pair of sum not found");
				
				
			}
			
			 
		}	  
		
		
	    
		public static void main(String[]args)
		{
			Scanner sc= new Scanner(System.in);
			 System.out.println("enter size");
			 int  size=sc.nextInt();
			 int a[]=new int[size];
			 prc ob= new prc();
			 ob.input(a, size);
			 
			 
		    
		}


}

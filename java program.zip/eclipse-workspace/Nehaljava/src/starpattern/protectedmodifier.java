package starpattern;

public class protectedmodifier
{

	 protected void disp()
	 {
		 System.out.println("protected is call outside the package ");
	 }
	 
	 public static void main(String[]args)
	 {
		 protectedmodifier ob= new protectedmodifier();
		 ob.disp();
		 defaultpack def= new defaultpack();
		 def.input2();  // default   call in only inside the package
	 }
	 
}

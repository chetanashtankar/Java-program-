package starpattern;
import java.util.Scanner;
public class revrse_array

{
	public static void main(String[]args)
	{
		int i,j;
   Scanner sc=new Scanner(System.in);
   System.out.println("enter size");
   int size=sc.nextInt();
   int a[]=new int[size];
   
   System.out.println("enter enter array element");
   
   for(i=0;i<a.length;i++)
   {
	   a[i]=sc.nextInt();
   }

   System.out.println("Ascending array element");
   
   for(i=0;i<a.length;i++)
   {
	   int temp;
	   for(j=i+1;j<a.length;j++)
	   {
		   if(a[i]<a[j])
		   {
			   temp=a[i];
			   a[i]=a[j];
			   a[j]=temp;
		   }
	   }
	   
	   System.out.println(a[i]);
   }
	
	}
	
	
}
